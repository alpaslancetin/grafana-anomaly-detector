# Grafana Anomaly Detector Paket Ozeti - v1.3.0

Bu klasordeki guncel paket seti `Grafana Anomaly Detector v1.3.0` icindir.

## Paketler

- `grafana-anomaly-detector-plugin.zip`
  - Grafana panel plugin paketidir.
  - Plugin ID: `alpas-anomalydetector-panel`
  - Plugin version: `1.3.0`
  - Minimum Grafana: `11.6.7`
  - Test edilen Grafana surumleri: `11.6.7`, `12.4.0`

- `grafana-anomaly-exporter-bundle-1.3.0.zip`
  - Anomaly score feed exporter paketidir.
  - Exporter version: `1.3.0`
  - Minimum Python: `3.9`
  - Onerilen Python: `3.9.x`
  - Portable calistirma ve RHEL systemd kurulum dosyalari icerir.

## v1.3.0 ile Gelen Ana Degisiklikler

- Grafana panel ile exporter arasinda ayni canonical score mantigi saglandi.
- Panel acikken hesaplanan anomaly score, exporter'a gonderilip Prometheus metric veya secilen sink hedeflerine yazilabilir hale geldi.
- Panel kapali olsa bile exporter range mode ile source datasource'u okuyup ayni score mantigiyla 7/24 feed uretebilir.
- Source reader destegi eklendi: Prometheus, Loki, InfluxDB, PostgreSQL, ClickHouse, Elasticsearch.
- Sink destegi eklendi: Loki, InfluxDB, PostgreSQL, ClickHouse, Elasticsearch.
- `Score feed target` ile hedef secilebilir:
  - Prometheus metrics
  - All configured sinks
  - Tekil sink hedefi
- Source ve target ayrimi desteklenir. Ornek: PostgreSQL panel verisinden hesaplanan anomaly score Elasticsearch sink'e yazilabilir.
- Alert query butonlari artik score'un yazildigi hedefe gore query uretir:
  - Prometheus hedefi icin PromQL
  - Loki hedefi icin LogQL
  - InfluxDB hedefi icin Flux
  - PostgreSQL ve ClickHouse hedefleri icin SQL
  - Elasticsearch hedefi icin Elasticsearch query spec
- Incident timeline/detail, annotation butonlari, score feed butonlari, synced rule query ve alert export ciktilari 6 demo datasource akisi icin UI uzerinden dogrulandi.
- Loki stream label kardinalitesi dusuruldu; dinamik `severity_label` ve `is_anomaly` alanlari label yerine JSON payload icinde korunur.
- Loki dashboard/alert unwrap query'leri scoped JSON ve rule filtresi ile daraltildi; 30 dk aralikta `maximum of series (500) reached` hatasi engellendi.
- Varsayilan threshold degerleri daha az false-positive uretecek sekilde sikilastirildi.
- Panel `PEAK SCORE` karti raw skor yerine 0-100 normalize severity score gosterir.
- `grafana_anomaly_sink_*` health metric'leri ve `grafana_anomaly_build_info{version="1.3.0"}` eklendi.
- Sink queue/backpressure metric'leri eklendi: `grafana_anomaly_sink_queue_depth`, `grafana_anomaly_sink_queue_capacity`, `grafana_anomaly_sink_dropped_batches_total`, `grafana_anomaly_sink_last_drop_timestamp_seconds`.
- PostgreSQL sink backend restart sonrasi exporter restart gerektirmeden yeniden baglanacak sekilde duzeltildi.
- Non-Prometheus feed target'larda sink queue dolarsa artik sessiz drop yerine HTTP `429` doner.
- Varsayilan sink queue kapasitesi normal multi-sink burst'lerini tasimasi icin `128` yapildi.
- Canonical scorer NaN/Inf veri noktalarini atlayacak sekilde guclendirildi.
- `level_shift` algoritmasi uzun suren kaymalari rolling baseline'a hizla yedirmemek icin eski stabil baseline referansi kullanir.
- R3 retest sonrasi `level_shift` referans pencere hesabi optimize edildi; throughput yeniden 10k nokta/sn benchmark hedefinin uzerine cikti.
- Panel legend `max` degeri artik raw detector skoru degil, 0-100 normalize severity score gosterir. Gorsel teyit: `max 100`, `max 51`, `max 0`.
- Parity testi eklendi: `scripts/parity_check.py`

## Parity Notu

Panelde gorulen score ile exporter tarafindan feed edilen score ayni canonical algoritmadan uretilir.

Kanıt testi:

```text
[OK] parity points compared: 1080
[OK] 2026-04-10 12:00 UTC panel_score=10 fed_score=10
```

## Kurulum Notlari

Plugin kurulumu icin zip Grafana plugin dizinine acilir ve unsigned plugin izinleri mevcut Grafana konfigurasyonunda korunur.

Exporter portable calistirma icin genel kullanim:

```bash
ANOMALY_PYTHON_BIN=$(command -v python3.9) \
ANOMALY_LISTEN_HOST=0.0.0.0 \
ANOMALY_LISTEN_PORT=9110 \
./portable-exporter.sh start http://127.0.0.1:9090
```

Prometheus scrape icin exporter endpoint'i:

```text
http://<exporter-host>:9110/metrics
```

Grafana panel tarafinda exporter endpoint:

```text
http://<exporter-host>:9110
```

Panel butonlari ve datasource hedeflerine gore alert query dogrulamasi icin:

```bash
node scripts/verify_multi_sink_panel_buttons.mjs
```

Beklenen sonuc: Prometheus, Loki, InfluxDB, PostgreSQL, ClickHouse ve Elasticsearch panellerinin tamaminda incident detail, annotation action, score feed sync, synced rule query ve alert export alanlari OK doner.

## R3 Retest Notu

`RETEST_R3_REPORT.md` sonucuna gore kabul kriterlerinde blokan acik kalmamistir. `level_shift` artik sustained-change kurallari icin daha kalici ve sifir gecikmeli davranir; dusuk false-positive oncelikli genel kurallarda daha yuksek esik veya ayri rule kullanimi onerilir.

## Ek Dokumanlar

- `README_v1.3.0.md`: Release paket klasoru aciklamasi
- `GITHUB_RELEASE_NOTES_v1.3.0.md`: GitHub release notlari
- `EXPORTER_SINK_KULLANIM_KILAVUZU_TR.md`: Exporter, sink, source reader ve panel kapali feed kullanimi
- `ARCHITECTURE_v1.3.0.md`: Mimari ve akis detaylari
- `MULTI_SINK_DEMO_README_TR.md`: Lokal multi-sink demo kullanim notlari
