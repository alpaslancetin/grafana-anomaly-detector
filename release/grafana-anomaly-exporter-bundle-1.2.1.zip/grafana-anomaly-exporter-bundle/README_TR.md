# Grafana Anomaly Exporter Bundle

Bu paket yalnizca anomaly exporter kurulumu icindir.
Amaci, panelde uretilen score feed kararini Prometheus metric olarak yayinlamaktir.

## Uyumluluk

- Plugin minimum Grafana surumu: `11.6.7`
- Minimum desteklenen Python surumu: `3.9`
- Onerilen Python surumu: `3.9.x`
- `Python 3.6.8` desteklenmez
- Referans paket: `grafana-anomaly-exporter-bundle-1.2.1.zip`

## Paket ne icerir?

- `exporter/`
- `portable-exporter.sh`
- `install-exporter-rhel.sh`
- `uninstall-exporter-rhel.sh`
- `enable-local-prometheus-scrape-rhel.sh`
- `disable-local-prometheus-scrape-rhel.sh`
- `grafana-anomaly-exporter.service`
- `grafana-anomaly-exporter.env.example`
- `prometheus-scrape-job.yml.snippet`
- `prometheus-scrape-job.remote.yml.snippet`

## 1. Root yoksa portable mod

Portable modda exporter ayni klasorden calisir.
Systemd istemez, `/opt` veya `/etc` altina yazmaz.
Runtime dosyalari `.portable-runtime/` altinda tutulur.

Ornek:

```bash
chmod +x portable-exporter.sh
./portable-exporter.sh foreground http://127.0.0.1:9090
./portable-exporter.sh start http://127.0.0.1:9090
```

Faydali komutlar:

```bash
./portable-exporter.sh status
./portable-exporter.sh logs
./portable-exporter.sh stop
```

Notlar:

- `ANOMALY_PYTHON_BIN` ile interpreter verilebilir
- varsayilan endpoint `0.0.0.0:9110`
- Grafana panelinde `Score feed endpoint` olarak exporter host'u yazilmalidir

## 2. RHEL uzerinde native kurulum

```bash
sudo ./install-exporter-rhel.sh http://127.0.0.1:9090
sudo ./enable-local-prometheus-scrape-rhel.sh
```

Bu kurulum:

- exporter dosyalarini `/opt/grafana-anomaly-exporter` altina koyar
- config'i `/etc/grafana-anomaly-exporter/exporter.env` altina yazar
- state'i `/var/lib/grafana-anomaly-exporter` altina koyar
- loglari `/var/log/grafana-anomaly-exporter` altina yazar
- systemd servisini enable + start eder

## 3. Prometheus scrape job

Local Prometheus icin gereken job:

```yaml
- job_name: grafana-anomaly-exporter
  scrape_interval: 10s
  static_configs:
    - targets:
        - 127.0.0.1:9110
```

Hazir snippet:

- `prometheus-scrape-job.yml.snippet`

Remote Prometheus gerekiyorsa:

- `prometheus-scrape-job.remote.yml.snippet`

## 4. Grafana tarafi

Panelde:

- `Score feed mode = Manual sync` veya `Auto sync`
- `Score feed endpoint = http://EXPORTER_HOST:9110`

Sync sonrasi alert query:

```promql
grafana_anomaly_rule_score{rule="..."}
```

## 5. Servis ve dizinler

- service: `/etc/systemd/system/grafana-anomaly-exporter.service`
- install root: `/opt/grafana-anomaly-exporter`
- config: `/etc/grafana-anomaly-exporter/exporter.env`
- state: `/var/lib/grafana-anomaly-exporter`
- log: `/var/log/grafana-anomaly-exporter/exporter.log`

## 6. Kisa karar notu

- Root yoksa: `portable-exporter.sh`
- RHEL prod kurulumda: `install-exporter-rhel.sh`
- Python icin hedef surum: `3.9.x`

