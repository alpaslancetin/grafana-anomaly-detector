/* [create-plugin] version: 7.0.7 */
/* [create-plugin] plugin: alpas-anomalydetector-panel@1.4.0 */
define(["@emotion/css","@grafana/data","@grafana/runtime","@grafana/ui","react"],(e,t,a,r,n)=>(()=>{"use strict";var i={89(t){t.exports=e},781(e){e.exports=t},531(e){e.exports=a},7(e){e.exports=r},959(e){e.exports=n}},l={};function s(e){var t=l[e];if(void 0!==t)return t.exports;var a=l[e]={exports:{}};return i[e](a,a.exports,s),a.exports}s.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return s.d(t,{a:t}),t},s.d=(e,t)=>{for(var a in t)s.o(t,a)&&!s.o(e,a)&&Object.defineProperty(e,a,{enumerable:!0,get:t[a]})},s.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),s.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var o={};s.r(o),s.d(o,{plugin:()=>na});var c=s(781);const d=.2,m=10,u=4;var p=s(959),h=s.n(p),g=s(89),f=s(7),y=s(531);function b(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}function v(e){for(var t=1;t<arguments.length;t++){var a=null!=arguments[t]?arguments[t]:{},r=Object.keys(a);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(a).filter(function(e){return Object.getOwnPropertyDescriptor(a,e).enumerable}))),r.forEach(function(t){b(e,t,a[t])})}return e}function x(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),a.push.apply(a,r)}return a}(Object(t)).forEach(function(a){Object.defineProperty(e,a,Object.getOwnPropertyDescriptor(t,a))}),e}const w=e=>Math.max(3,Math.floor(Number.isFinite(e)?e:3)),E={"1m":6e4,"5m":3e5,"15m":9e5,"1h":36e5},k=(Object.values(E).sort((e,t)=>e-t),{warning_first:{low:35,medium:55,high:72,critical:88},balanced:{low:40,medium:60,high:75,critical:90},page_first:{low:45,medium:65,high:82,critical:95}}),S=e=>{if(!Number.isFinite(e.time)||!Number.isFinite(e.value))return null;const t=Number.isFinite(e.sampleCount)?Math.max(1,Math.floor(e.sampleCount)):1,a=Number.isFinite(e.minValue)?e.minValue:e.value,r=Number.isFinite(e.maxValue)?e.maxValue:e.value;return x(v({},e),{bucketStart:Number.isFinite(e.bucketStart)?e.bucketStart:e.time,bucketEnd:Number.isFinite(e.bucketEnd)?e.bucketEnd:e.time,sampleCount:t,minValue:Math.min(a,r,e.value),maxValue:Math.max(a,r,e.value)})},F=e=>e.map(S).filter(e=>null!==e).sort((e,t)=>e.time-t.time),N=e=>Number.isFinite(e)?Math.max(0,Math.min(100,e)):0,$=e=>e.reduce((e,t)=>e+t,0)/e.length,M=e=>{const t=[...e].sort((e,t)=>e-t),a=Math.floor(t.length/2);return t.length%2==0?(t[a-1]+t[a])/2:t[a]},L=(e,t)=>{if(0===e.length)return 0;const a=null!=t?t:M(e);return 1.4826*M(e.map(e=>Math.abs(e-a)))},C=(e,t)=>{if(e.length<=1)return 0;const a=null!=t?t:$(e),r=e.reduce((e,t)=>e+Math.pow(t-a,2),0)/e.length;return Math.sqrt(r)},A=(e,t)=>Number.isFinite(e)&&e>1e-9?e:Math.max(.02*Math.abs(t),1e-6),B=e=>{const t=[];for(const a of e){const e=t[t.length-1];if(e&&e.time===a.time){const t=e.sampleCount+a.sampleCount;e.value=(e.value*e.sampleCount+a.value*a.sampleCount)/t,e.sampleCount=t,e.minValue=Math.min(e.minValue,a.minValue),e.maxValue=Math.max(e.maxValue,a.maxValue),e.bucketStart=Math.min(e.bucketStart,a.bucketStart),e.bucketEnd=Math.max(e.bucketEnd,a.bucketEnd);continue}t.push(v({},a))}return t},D=(e,t,a)=>{const r=k[a],n=e/Math.max(t,1e-4);if(n<1)return{severityScore:Math.min(r.low-1,Math.round(n*(r.low-1))),severityLabel:"normal"};const i=Math.min(100,Math.round(r.low+30*(n-1)));return i>=r.critical?{severityScore:i,severityLabel:"critical"}:i>=r.high?{severityScore:i,severityLabel:"high"}:i>=r.medium?{severityScore:i,severityLabel:"medium"}:{severityScore:i,severityLabel:"low"}},T=(e,t,a)=>{const r=e.slice(Math.max(0,t-a),t+1),n=r.map(e=>e.value),i=r.slice(-Math.max(4,Math.min(a,8)));if(n.length<Math.max(3,Math.floor(a/2)))return"thin";if(i.length>=3){const e=i.slice(1).map((e,t)=>e.time-i[t].time).filter(e=>e>0),t=e.length>0?M(e):null,a=e.length>0?Math.min(...e):null,r=e.length>0?Math.max(...e):null;if(t&&e.some(e=>e>2.4*t)||a&&r&&r>1.8*a)return"gappy"}if(i.length>=4){const e=i.map(e=>e.value),t=Math.max(.002*Math.abs($(e)),1e-6);if(Math.max(...e)-Math.min(...e)<=t)return"flatline"}return"healthy"},P=(e,t,a,r,n,i)=>{const l=Math.max(t,1e-6);let s=Math.min(e/l,2.5)/2.5*100;r>a&&(s+=8),n>=8&&(s+=4),"thin"===i?s-=18:"flatline"===i?s-=22:"gappy"===i&&(s-=12);const o=Math.max(5,Math.min(100,Math.round(10*s)/10));return{confidenceScore:o,confidenceLabel:o>=80?"high":o>=55?"medium":"low",dataQualityLabel:i}},_=(e,t,a)=>{const r=D(0,t,a);return x(v(x(v({},e),{expected:null,upper:null,lower:null,score:0,pointScore:0,windowScore:0,scoreDriver:"point",isAnomaly:!1}),r),{confidenceScore:5,confidenceLabel:"low",dataQualityLabel:"thin"})},R=(e,t,a,r)=>{const n=[],i=2/(Math.max(a,2)+1);let l=null;const s=[];return e.forEach((o,c)=>{if(0===c||null===l)return l=o.value,void n.push(_(o,t,r));const d=l,m=A(M(s.slice(-a))||C(e.slice(Math.max(0,c-a),c).map(e=>e.value)),d),u=e.slice(Math.max(0,c-a),c).map(e=>e.value);if(s.push(Math.abs(o.value-d)),l=i*o.value+(1-i)*d,u.length<w(a))return void n.push(_(o,t,r));const p=Math.abs(o.value-d)/m,h=((e,t,a,r,n)=>{const i=Math.min(Math.max(3,Math.floor(n/3)),10),l=[...e.slice(-(i-1)),t];return l.length<3?0:Math.abs($(l)-a)/r})(u,o.value,d,m,a),g=Math.max(p,h),f=D(g,t,r),y=P(g,t,p,h,u.length+1,T(e,c,a));n.push(v(x(v({},o),{expected:d,lower:d-t*m,upper:d+t*m,score:g,pointScore:p,windowScore:h,scoreDriver:h>p?"window":"point",isAnomaly:g>=t}),f,y))}),n},V=(e,t,a,r,n,i)=>{const l=new Map,s=new Map;return e.map((o,c)=>{let d=[];if("cycle"===n)for(let t=c-r;t>=0&&d.length<a;t-=r)d.push(e[t].value);else{var m,u,p,h;const e=(e=>{const t=new Date(e);return{hour_of_day:`hour:${t.getHours()}`,weekday_hour:`weekday:${t.getDay()}-${t.getHours()}`}})(o.time);var g;if(d="hour_of_day"===n?[...null!==(m=l.get(e.hour_of_day))&&void 0!==m?m:[]].slice(-a):[...null!==(u=s.get(e.weekday_hour))&&void 0!==u?u:[]].slice(-a),"weekday_hour"===n&&d.length<3)d=[...null!==(g=l.get(e.hour_of_day))&&void 0!==g?g:[]].slice(-a);const t=null!==(p=l.get(e.hour_of_day))&&void 0!==p?p:[];t.push(o.value),l.set(e.hour_of_day,t);const r=null!==(h=s.get(e.weekday_hour))&&void 0!==h?h:[];r.push(o.value),s.set(e.weekday_hour,r)}if(d.length<3)return _(o,t,i);const f=e.slice(Math.max(0,c-a),c).map(e=>e.value),{expected:y,spread:b}=((e,t)=>{const a=M(e),r=A(L(e,a),a),n=e.slice(1).map((t,a)=>t-e[a]),i=n.length>=2?M(n):0,l=n.length>=2?A(L(n,i),a):0,s=t.length>0?A(L(t),M(t)):0,o=Math.max(r,l,.75*s);return{expected:a+i,spread:A(o,a+i)}})(d,f),w=Math.abs(o.value-y)/b,E=w,k=D(E,t,i),S=P(E,t,w,0,f.length+1,T(e,c,a));return v(x(v({},o),{expected:y,lower:y-t*b,upper:y+t*b,score:E,pointScore:w,windowScore:0,scoreDriver:0>w?"window":"point",isAnomaly:E>=t}),k,S)})},O=(e,t,a,r)=>{const n=e.map(e=>e.value),i=Math.min(Math.max(3,Math.floor(a/3)),12),l=Math.max(1,i-1),s=Math.max(6*a,a+i),o=Math.max(w(a),6,i+3);return e.map((i,c)=>{const d=Math.max(0,c-s);if(c-d<o)return _(i,t,r);const m=c-l;if(m-d<3)return _(i,t,r);const u=((e,t,a,r)=>{const n=Math.min(t+r,a);return n-t>=3?e.slice(t,n):e.slice(Math.max(t,a-r),a)})(n,d,m,a),p=$(u),h=A(C(u,p),p),g=Math.abs(i.value-p)/h,f=Math.max(0,c-l);let y=i.value,b=Math.abs(i.value-p)>h?1:0;for(let e=f;e<c;e+=1){const t=n[e];y+=t,Math.abs(t-p)>h&&(b+=1)}const w=c-f+1,E=y/w,k=b/w,S=Math.abs(E-p)/h*(1+Math.max(0,k-.4)),F=Math.max(.85*g,S),N=D(F,t,r),M=P(F,t,g,S,u.length+1,T(e,c,a));return v(x(v({},i),{expected:p,lower:p-t*h,upper:p+t*h,score:F,pointScore:g,windowScore:S,scoreDriver:S>=.85*g?"window":"point",isAnomaly:F>=t}),N,M)})},I=(e,t)=>{const a=Math.max(t.baselineWindow,3),r=Math.max(t.sensitivity,.2),n=B(F(e));let i;switch(t.algorithm){case"mad":i=((e,t,a,r)=>e.map((n,i)=>{const l=e.slice(Math.max(0,i-a),i).map(e=>e.value);if(l.length<w(a))return _(n,t,r);const s=M(l),o=l.map(e=>Math.abs(e-s)),c=A(1.4826*M(o),s),d=Math.abs(n.value-s)/c,m=d,u=D(m,t,r),p=P(m,t,d,0,l.length+1,T(e,i,a));return v(x(v({},n),{expected:s,lower:s-t*c,upper:s+t*c,score:m,pointScore:d,windowScore:0,scoreDriver:0>d?"window":"point",isAnomaly:m>=t}),u,p)}))(n,r,a,t.severityPreset);break;case"ewma":i=R(n,r,a,t.severityPreset);break;case"level_shift":i=O(n,r,a,t.severityPreset);break;case"seasonal":i=V(n,r,a,Math.max(t.seasonalitySamples,2),t.seasonalRefinement,t.severityPreset);break;default:i=((e,t,a,r)=>e.map((n,i)=>{const l=e.slice(Math.max(0,i-a),i).map(e=>e.value);if(l.length<w(a))return _(n,t,r);const s=$(l),o=A(C(l,s),s),c=Math.abs(n.value-s)/o,d=c,m=D(d,t,r),u=P(d,t,c,0,l.length+1,T(e,i,a));return v(x(v({},n),{expected:s,lower:s-t*o,upper:s+t*o,score:d,pointScore:c,windowScore:0,scoreDriver:0>c?"window":"point",isAnomaly:d>=t}),m,u)}))(n,r,a,t.severityPreset)}return i.map(e=>x(v({},e),{score:N(e.score),pointScore:N(e.pointScore),windowScore:N(e.windowScore)}))};function q(e,t,a,r,n,i,l){try{var s=e[i](l),o=s.value}catch(e){return void a(e)}s.done?t(o):Promise.resolve(o).then(r,n)}function W(e){return function(){var t=this,a=arguments;return new Promise(function(r,n){var i=e.apply(t,a);function l(e){q(i,r,n,l,s,"next",e)}function s(e){q(i,r,n,l,s,"throw",e)}l(void 0)})}}function z(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}function j(e){for(var t=1;t<arguments.length;t++){var a=null!=arguments[t]?arguments[t]:{},r=Object.keys(a);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(a).filter(function(e){return Object.getOwnPropertyDescriptor(a,e).enumerable}))),r.forEach(function(t){z(e,t,a[t])})}return e}function U(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),a.push.apply(a,r)}return a}(Object(t)).forEach(function(a){Object.defineProperty(e,a,Object.getOwnPropertyDescriptor(t,a))}),e}const H=["#7EB26D","#EAB839","#6ED0E0","#EF843C","#E24D42","#1F78C1"],Q=720,G={top:18,right:20,bottom:42,left:64},Y={"1m":6e4,"5m":3e5,"15m":9e5,"1h":36e5},K=Object.values(Y).sort((e,t)=>e-t),Z={recommended:"Recommended",advanced:"Advanced"},J={zscore:"Rolling z-score",mad:"Rolling MAD",ewma:"EWMA baseline",seasonal:"Seasonal baseline",level_shift:"Level shift detector"},X={auto:"Auto",custom:"Custom",traffic:"Traffic / throughput",latency:"Latency / duration",error_rate:"Error rate",resource:"Resource usage",business:"Business KPI",level_shift:"Subtle level shift"},ee={auto:"Auto",raw:"Raw samples","1m":"1 minute","5m":"5 minutes","15m":"15 minutes","1h":"1 hour"},te={traffic:{algorithm:"ewma",sensitivity:4.5,baselineWindow:30,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"warning_first",badge:"Stable default",why:"Traffic and throughput metrics drift with load, so EWMA is usually the safest default for live dashboards."},latency:{algorithm:"mad",sensitivity:4,baselineWindow:12,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"page_first",badge:"Noisy data",why:"Latency metrics are often spiky and outlier-heavy, so MAD is more robust than a mean-based baseline."},error_rate:{algorithm:"mad",sensitivity:4.5,baselineWindow:12,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"page_first",badge:"Burst errors",why:"Error metrics often stay low and then jump sharply, so MAD isolates bursts without letting them poison the baseline."},resource:{algorithm:"ewma",sensitivity:4.5,baselineWindow:24,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Drifting baseline",why:"CPU, memory, and load metrics usually move gradually, so EWMA follows the baseline smoothly without overreacting."},business:{algorithm:"seasonal",sensitivity:4.5,baselineWindow:8,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Seasonal data",why:"Business KPIs often repeat by hour or weekday, so seasonal matching reduces false positives on recurring patterns."},level_shift:{algorithm:"level_shift",sensitivity:6,baselineWindow:30,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Sustained change",why:"When the baseline shifts gradually or steps into a new level, a level-shift detector is better than a pure spike detector."}},ae=["latency","error_rate","level_shift","resource","business","traffic"],re=[{preset:"latency",patterns:[/latency/i,/duration/i,/response/i,/p95/i,/p99/i,/p90/i,/quantile/i,/delay/i,/ms/i,/seconds?/i]},{preset:"error_rate",patterns:[/error/i,/errors/i,/failure/i,/fail/i,/exception/i,/timeout/i,/reject/i,/5xx/i,/4xx/i]},{preset:"resource",patterns:[/cpu/i,/memory/i,/load/i,/utili/i,/usage/i,/heap/i,/rss/i,/disk/i,/iops/i,/saturation/i,/throttle/i]},{preset:"level_shift",patterns:[/queue/i,/backlog/i,/pending/i,/session/i,/connection/i,/thread/i,/pool/i,/worker/i,/lag/i,/offset/i,/buffer/i,/inflight/i,/active/i]},{preset:"business",patterns:[/revenue/i,/order/i,/orders/i,/signup/i,/conversion/i,/checkout/i,/cart/i,/booking/i,/payment/i,/sales/i,/gmv/i]},{preset:"traffic",patterns:[/request/i,/requests/i,/throughput/i,/traffic/i,/volume/i,/events?/i,/rps/i,/qps/i,/ops/i,/hits?/i,/ingress/i,/egress/i,/count/i]}],ne={cycle:"Cycle only",hour_of_day:"Hour of day",weekday_hour:"Weekday + hour"},ie={balanced:"Balanced",warning_first:"Warning first",page_first:"Page first"},le={normal:"Normal",low:"Low",medium:"Medium",high:"High",critical:"Critical"},se={normal:"#94A3B8",low:"#EAB308",medium:"#F59E0B",high:"#F97316",critical:"#DC2626"},oe={low:"Low confidence",medium:"Medium confidence",high:"High confidence"},ce={low:"#F59E0B",medium:"#2563EB",high:"#16A34A"},de={healthy:"Healthy data",thin:"Thin history",flatline:"Flatline risk",gappy:"Gappy sampling"},me=e=>{if("number"==typeof e&&Number.isFinite(e))return e;if("string"==typeof e){const t=Number(e);return Number.isFinite(t)?t:null}return null},ue=(e,t)=>{if(e)return"function"==typeof e.get?e.get(t):e[t]},pe=e=>{const t=[...e].sort((e,t)=>e-t),a=Math.floor(t.length/2);return t.length%2==0?(t[a-1]+t[a])/2:t[a]},he=e=>{if(null===e||!Number.isFinite(e))return"n/a";const t=Math.abs(e);return t>=1e3?e.toLocaleString(void 0,{maximumFractionDigits:1}):t>=10?e.toLocaleString(void 0,{maximumFractionDigits:2}):e.toLocaleString(void 0,{maximumFractionDigits:3})},ge=e=>null!==e&&Number.isFinite(e)?Math.round(e).toLocaleString(void 0,{maximumFractionDigits:0}):"n/a",fe=e=>null!==e&&Number.isFinite(e)?`${e.toLocaleString(void 0,{maximumFractionDigits:1})}%`:"n/a",ye=e=>new Date(e).toLocaleString(void 0,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}),be=(e,t)=>t<=e?ye(e):`${ye(e)} - ${ye(t)}`,ve=(e,t=26)=>e.length<=t?e:`${e.slice(0,Math.max(1,t-1)).trimEnd()}…`,xe=(e,t)=>"auto"!==e?e:t<=216e5?"dense":t<=1296e5?"balanced":"compact",we=(e,t)=>{const a=xe(t,e);return e<=432e5||"dense"===a?"HH:mm":e<=2592e5?"DD/MM HH:mm":"DD/MM"},Ee=(e,t,a,r)=>(0,c.dateTimeFormat)(e,{format:we(t,a),timeZone:r}),ke=(e,t,a)=>(0,c.dateTimeFormat)(e,{format:t<=2592e5?"DD/MM HH:mm":"DD/MM/YYYY HH:mm",timeZone:a}),Se=(e,t)=>{if("classic"===t)return"circle";switch(e){case"medium":return"diamond";case"high":return"triangle";case"critical":return"square";default:return"circle"}},Fe=(e,t,a,r)=>"diamond"===e?`M ${t} ${a-r} L ${t+r} ${a} L ${t} ${a+r} L ${t-r} ${a} Z`:`M ${t} ${a-r} L ${t+.92*r} ${a+.9*r} L ${t-.92*r} ${a+.9*r} Z`,Ne=(e,t,a,r,n,i,l=0,s)=>"circle"===e?h().createElement("circle",{cx:t,cy:a,r,fill:n,stroke:i,strokeWidth:l,opacity:s}):"square"===e?h().createElement("rect",{x:t-r,y:a-r,width:2*r,height:2*r,rx:Math.max(1.5,.32*r),fill:n,stroke:i,strokeWidth:l,opacity:s}):h().createElement("path",{d:Fe(e,t,a,r),fill:n,stroke:i,strokeWidth:l,opacity:s}),$e=(e,t)=>{var a,r;if("advanced"===e.setupMode||"custom"===e.effectiveMetricPreset)return{source:"manual",badge:"Manual tuning",title:"Advanced controls are active",reason:`Algorithm ${J[e.algorithm]} with ${ie[e.severityPreset]} severity mapping is applied directly.`,matchedNames:[],confidence:"matched"};const n=te[e.effectiveMetricPreset],i="auto"===e.metricPreset?"auto":"selected",l="auto"===i?`Auto selected ${X[e.effectiveMetricPreset]}`:`${X[e.effectiveMetricPreset]} preset is active`;return{source:i,badge:n.badge,title:l,reason:n.why,matchedNames:null!==(a=null==t?void 0:t.matchedNames)&&void 0!==a?a:[],confidence:null!==(r=null==t?void 0:t.confidence)&&void 0!==r?r:"matched"}},Me=(e,t)=>{var a,r,n,i,l,s,o;const c=null!==(a=e.setupMode)&&void 0!==a?a:"recommended",d=null!==(r=e.metricPreset)&&void 0!==r?r:"auto",m=Math.max(3,Math.min(20,Math.round(null!==(n=e.maxAnomalies)&&void 0!==n?n:8))),u=e.bucketSpan||"auto";if("advanced"===c||"custom"===d){var p,h,g,f,y,b,v,x,w,E;const t={setupMode:c,metricPreset:d,effectiveMetricPreset:"custom",detectionMode:null!==(p=e.detectionMode)&&void 0!==p?p:"single",algorithm:null!==(h=e.algorithm)&&void 0!==h?h:"zscore",sensitivity:Math.max(.2,null!==(g=e.sensitivity)&&void 0!==g?g:4),baselineWindow:Math.max(3,Math.round(null!==(f=e.baselineWindow)&&void 0!==f?f:12)),seasonalitySamples:Math.max(2,Math.round(null!==(y=e.seasonalitySamples)&&void 0!==y?y:24)),seasonalRefinement:null!==(b=e.seasonalRefinement)&&void 0!==b?b:"cycle",severityPreset:null!==(v=e.severityPreset)&&void 0!==v?v:"balanced",bucketSpan:u,showExpectedLine:!1!==e.showExpectedLine,showInlineSeriesLabels:!1!==e.showInlineSeriesLabels,showFocusBand:!0===e.showFocusBand,timeAxisDensity:null!==(x=e.timeAxisDensity)&&void 0!==x?x:"auto",timeAxisPlacement:null!==(w=e.timeAxisPlacement)&&void 0!==w?w:"top_and_bottom",markerShapeMode:null!==(E=e.markerShapeMode)&&void 0!==E?E:"severity",maxAnomalies:m};return U(j({},t),{recommendation:$e(t,null)})}const k="auto"===d?(e=>{const t=new Map;for(const r of e)for(const e of re)if(e.patterns.some(e=>e.test(r))){var a;const n=null!==(a=t.get(e.preset))&&void 0!==a?a:[];n.push(r),t.set(e.preset,n)}for(const e of ae){var r;const a=null!==(r=t.get(e))&&void 0!==r?r:[];if(a.length>0)return{preset:e,matchedNames:a,confidence:a.length>=2?"matched":"weak"}}return{preset:"traffic",matchedNames:[],confidence:"fallback"}})(t):null,S="auto"===d?null==k?void 0:k.preset:d,F=te[S],N={setupMode:c,metricPreset:d,effectiveMetricPreset:S,detectionMode:null!==(i=e.detectionMode)&&void 0!==i?i:"single",algorithm:F.algorithm,sensitivity:F.sensitivity,baselineWindow:F.baselineWindow,seasonalitySamples:F.seasonalitySamples,seasonalRefinement:F.seasonalRefinement,severityPreset:F.severityPreset,bucketSpan:u,showExpectedLine:!1!==e.showExpectedLine,showInlineSeriesLabels:!1!==e.showInlineSeriesLabels,showFocusBand:!0===e.showFocusBand,timeAxisDensity:null!==(l=e.timeAxisDensity)&&void 0!==l?l:"auto",timeAxisPlacement:null!==(s=e.timeAxisPlacement)&&void 0!==s?s:"top_and_bottom",markerShapeMode:null!==(o=e.markerShapeMode)&&void 0!==o?o:"severity",maxAnomalies:m};return U(j({},N),{recommendation:$e(N,k)})},Le=e=>e?"point"===e.kind?`point:${e.seriesKey}:${e.time}`:`event:${e.time}`:"none",Ce=e=>["normal","low","medium","high","critical"].indexOf(e),Ae=(e,t)=>Ce(t.severityLabel)>Ce(e.severityLabel)||Ce(t.severityLabel)===Ce(e.severityLabel)&&t.severityScore>e.severityScore?t:e,Be=(e,t)=>"level_shift"===t?"window"===e?"Sustained baseline shift":"Fresh step change":"seasonal"===t?"Seasonal pattern break":"window"===e?"ewma"===t?"Short sustained drift":"Sustained deviation":"Sharp point deviation",De=(e,t)=>{const a="warning_first"===t?"Warning-first preset surfaces operator-visible severity earlier.":"page_first"===t?"Page-first preset keeps high and critical stricter for paging workflows.":"Balanced preset aims to work for both dashboards and alert handoff.",r="low"===e.confidenceLabel?" Confidence is still low, so verify with nearby metrics before paging.":"thin"===e.dataQualityLabel?" History is still thin, so treat this as early signal rather than hard evidence.":"flatline"===e.dataQualityLabel?" The series looks nearly flat, so verify the metric is still reporting healthy samples.":"gappy"===e.dataQualityLabel?" Recent samples are gappy, so confirm the data source timing before escalating.":"";return"critical"===e.severityLabel||"high"===e.severityLabel?`${a} This anomaly is already in the investigate-now range.${r}`:"medium"===e.severityLabel?`${a} This anomaly looks strong enough for triage or warning workflows.${r}`:`${a} This anomaly is currently better suited to watchlists or dashboard review.${r}`},Te=e=>{const t=[];for(const a of e){const e=t[t.length-1];if(e&&e.time===a.time){const t=e.sampleCount+a.sampleCount;e.value=(e.value*e.sampleCount+a.value*a.sampleCount)/t,e.sampleCount=t,e.minValue=Math.min(e.minValue,a.minValue),e.maxValue=Math.max(e.maxValue,a.maxValue),e.bucketStart=Math.min(e.bucketStart,a.bucketStart),e.bucketEnd=Math.max(e.bucketEnd,a.bucketEnd);continue}t.push(j({},a))}return t},Pe=(e,t)=>{if("raw"===t)return null;if("auto"!==t)return Y[t];const a=e.map(e=>e.rawPoints.length).filter(e=>e>0);if(0===a.length)return null;const r=Math.max(...a),n=e.flatMap(e=>e.rawPoints.map(e=>e.time)),i=Math.min(...n),l=Math.max(...n),s=Math.max(l-i,0),o=e.map(e=>(e=>{if(e.length<2)return null;const t=[];for(let a=1;a<e.length&&t.length<120;a+=1){const r=e[a].time-e[a-1].time;r>0&&t.push(r)}return t.length>0?pe(t):null})(e.rawPoints)).filter(e=>null!==e),c=o.length>0?pe(o):null;if(r<=640||s<=0)return null;const d=Math.ceil(s/640),m=c?Math.max(1.5*c,d):d,u=K.find(e=>e>=m);return null!=u?u:K[K.length-1]},_e=(e,t)=>({time:e,value:t,bucketStart:e,bucketEnd:e,sampleCount:1,minValue:t,maxValue:t}),Re=e=>"string"!=typeof e?null:e.trim().length>0?e:null,Ve=(e,t,a="Series")=>{var r,n,i,l,s,o,c,d;return null!==(r=null!==(n=null!==(i=null!==(l=null!==(s=Re(null===(o=e.config)||void 0===o?void 0:o.displayNameFromDS))&&void 0!==s?s:Re(null===(c=e.config)||void 0===c?void 0:c.displayName))&&void 0!==l?l:Re(null===(d=e.state)||void 0===d?void 0:d.displayName))&&void 0!==i?i:Re(e.name))&&void 0!==n?n:Re(t))&&void 0!==r?r:a},Oe=e=>{var t,a,r,n,i;return Boolean(null!==(t=null!==(a=Re(null===(r=e.config)||void 0===r?void 0:r.displayNameFromDS))&&void 0!==a?a:Re(null===(n=e.config)||void 0===n?void 0:n.displayName))&&void 0!==t?t:Re(null===(i=e.state)||void 0===i?void 0:i.displayName))},Ie=e=>{const t=!1!==e.showSummary;return{initialLabels:!1!==e.showInitialLabels,statistics:!1!==e.showStatistics,mainChart:!1!==e.showMainChart,inspector:!1!==e.showInspector,anomalyFeed:t&&!1!==e.showAnomalyFeed,seriesSummary:!1!==e.showSeriesSummary,scoreFeed:!1!==e.showScoreFeed,detectionProfile:t&&!1!==e.showDetectionProfile,exports:t&&!1!==e.showExports}},qe=e=>{const t=[];e.forEach((e,a)=>{const r=e.fields.find(e=>e.type===c.FieldType.time);if(!r)return;e.fields.filter(e=>e.type===c.FieldType.number).forEach((n,i)=>{var l,s,o,c,d;const m=[],u=Math.min(null!==(l=r.values.length)&&void 0!==l?l:0,null!==(s=n.values.length)&&void 0!==s?s:0);for(let e=0;e<u;e+=1){const t=me(ue(r.values,e)),a=me(ue(n.values,e));null!==t&&null!==a&&m.push(_e(t,a))}if(0===m.length)return;m.sort((e,t)=>e.time-t.time);const p=Ve(n,e.name,`Series ${t.length+1}`),h=null===(d=n.config.color)||void 0===d?void 0:d.fixedColor;t.push({key:`${null!==(o=e.name)&&void 0!==o?o:a}-${null!==(c=n.name)&&void 0!==c?c:i}-${a}-${i}`,label:p,preservesGrafanaDisplayName:Oe(n),color:h||H[t.length%H.length],rawPoints:Te(m)})})});const a=new Map;t.forEach(e=>{var t;a.set(e.label,(null!==(t=a.get(e.label))&&void 0!==t?t:0)+1)});const r=new Map;return t.map(e=>{var t,n;if((null!==(t=a.get(e.label))&&void 0!==t?t:1)<=1||e.preservesGrafanaDisplayName)return e;const i=(null!==(n=r.get(e.label))&&void 0!==n?n:0)+1;return r.set(e.label,i),U(j({},e),{label:`${e.label} (${i})`})})},We=(e,t)=>{const a=Pe(e,t.bucketSpan),r=e.map(e=>{const r=((e,t)=>{if(!t||0===e.length)return Te(e.map(e=>j({},e)));const a=new Map;for(const n of e){var r;const e=Math.floor(n.time/t)*t,i=null!==(r=a.get(e))&&void 0!==r?r:{sum:0,count:0,min:Number.POSITIVE_INFINITY,max:Number.NEGATIVE_INFINITY,end:e+t};i.sum+=n.value,i.count+=n.sampleCount,i.min=Math.min(i.min,n.minValue),i.max=Math.max(i.max,n.maxValue),a.set(e,i)}return[...a.entries()].sort((e,t)=>e[0]-t[0]).map(([e,a])=>({time:e+Math.round(t/2),value:a.sum/a.count,bucketStart:e,bucketEnd:a.end,sampleCount:a.count,minValue:a.min,maxValue:a.max}))})(e.rawPoints,a),n=((e,t)=>I(e,{algorithm:t.algorithm,sensitivity:t.sensitivity,baselineWindow:t.baselineWindow,seasonalitySamples:t.seasonalitySamples,seasonalRefinement:t.seasonalRefinement,severityPreset:t.severityPreset}))(r,t),i=(e=>{if(e.length<=Q)return e;const t=new Set,a=(e.length-1)/719;for(let e=0;e<Q;e+=1)t.add(Math.round(e*a));return e.forEach((e,a)=>{e.isAnomaly&&t.add(a)}),[...t].sort((e,t)=>e-t).slice(0,Q+Math.min(60,e.filter(e=>e.isAnomaly).length)).map(t=>e[t])})(n),l=n.filter(e=>e.isAnomaly),s=l.reduce((e,t)=>Ae(e,t),{severityLabel:"normal",severityScore:0});return{key:e.key,label:e.label,color:e.color,points:i,allPoints:n,anomalyCount:l.length,maxScore:l.reduce((e,t)=>Math.max(e,t.score),0),maxSeverityScore:s.severityScore,maxSeverityLabel:s.severityLabel,sourcePointCount:e.rawPoints.length,aggregatedPointCount:r.length,processedPointCount:n.length}});return{analyses:r,effectiveBucketSpanMs:a}},ze=(e,t)=>"raw"===e?ee.raw:"auto"!==e?ee[e]:t?`Auto -> ${(e=>{const t=Math.round(e/6e4);if(t<60)return`${t}m`;const a=Math.round(e/36e5*10)/10;return a<24?`${a}h`:Math.round(e/864e5*10)/10+"d"})(t)}`:"Auto -> raw",je=(e,t,a,r)=>{let n="";return e.forEach(e=>{const i=r(e);if(null===i||!Number.isFinite(i))return;const l=0===n.length?"M":"L";n+=`${l}${t(e.time).toFixed(2)},${a(i).toFixed(2)} `}),n.trim()},Ue=(e,t,a)=>Number.isFinite(e)&&Number.isFinite(t)?a<=1||t===e?[e]:Array.from({length:a},(r,n)=>e+(t-e)*n/(a-1)):[],He=(e,t,a,r=null)=>{if(e.length<=1)return e;const n=[];let i=[],l=Number.NEGATIVE_INFINITY;const s=()=>{if(0===i.length)return;let e=i[0];for(const t of i){if(null!==r&&t.time===r){e=t;break}t.score>e.score&&(e=t)}n.push(e),i=[]};for(const r of e){const e=t(r.time);0!==i.length?e-l<a?i.push(r):(s(),i=[r],l=e):(i=[r],l=e)}if(s(),null!==r&&!n.some(e=>e.time===r)){const t=e.find(e=>e.time===r);t&&(n.push(t),n.sort((e,t)=>e.time-t.time))}return n},Qe=(e,t)=>{if(0===e.length)return-1;let a=0,r=Math.abs(e[0]-t);for(let n=1;n<e.length;n+=1){const i=Math.abs(e[n]-t);i<r&&(r=i,a=n)}return a},Ge=(e,t,a=null)=>{var r;if(e.length<=t)return e;const n=null!==a&&null!==(r=e.find(e=>e.time===a))&&void 0!==r?r:null,i=[...e].sort((e,t)=>t.score-e.score||e.time-t.time),l=[];n&&l.push(n);for(const e of i){if(l.length>=t)break;l.some(t=>t.time===e.time)||l.push(e)}return l.sort((e,t)=>e.time-t.time)},Ye=(e,t,a)=>"multi"===a.detectionMode?t.filter(e=>e.isAnomaly).sort((e,t)=>t.score-e.score).slice(0,a.maxAnomalies).map((e,t)=>({key:`event-${e.time}-${t}`,time:e.time,title:`Cross-metric incident at ${ye(e.time)}`,subtitle:`${e.activeSeries} metric${1===e.activeSeries?"":"s"} aligned${e.contributors.length>0?` | ${e.contributors.join(", ")}`:""}`,detail:`${le[e.severityLabel]} ${e.severityScore} | ${oe[e.confidenceLabel]} | ${de[e.dataQualityLabel]}`,score:e.score,severityLabel:e.severityLabel,severityScore:e.severityScore,confidenceScore:e.confidenceScore,confidenceLabel:e.confidenceLabel,dataQualityLabel:e.dataQualityLabel,selection:{kind:"event",time:e.time}})):e.flatMap(e=>(e=>{const t=e.filter(e=>e.isAnomaly).sort((e,t)=>e.time-t.time);if(0===t.length)return[];const a=[];let r=[t[0]];for(let e=1;e<t.length;e+=1){const n=r[r.length-1],i=t[e],l=Math.max(n.bucketEnd-n.bucketStart,1),s=Math.max(i.bucketEnd-i.bucketStart,1),o=1.25*Math.max(l,s);i.bucketStart<=n.bucketEnd+o?r.push(i):(a.push(r),r=[i])}return a.push(r),a})(e.allPoints).map((t,r)=>{const n=t.reduce((e,t)=>t.score>e.score?t:e),i=t[0].bucketStart,l=t[t.length-1].bucketEnd;return{key:`${e.key}-${n.time}-${r}`,time:n.time,title:(s=e.label,o=a.algorithm,c=n.scoreDriver,`${Be(c,o)} in ${s}`),subtitle:t.length>1?`${t.length} consecutive buckets | ${be(i,l)}`:be(i,l),detail:`${le[n.severityLabel]} ${n.severityScore} | ${oe[n.confidenceLabel]} | Current ${he(n.value)} vs expected ${he(n.expected)}`,score:n.score,severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel,selection:{kind:"point",seriesKey:e.key,time:n.time}};var s,o,c})).sort((e,t)=>t.score-e.score).slice(0,a.maxAnomalies),Ke=(e,t,a)=>{if(!e)return null;if("point"===e.kind){const a=((e,t)=>{var a;const r=null!==(a=t.find(t=>t.key===e.seriesKey))&&void 0!==a?a:null,n=r?[r,...t.filter(e=>e.key!==r.key)]:t;for(const t of n){const a=t.allPoints.find(t=>t.time===e.time);if(a)return{analysis:t,point:a}}let i=null,l=null;for(const t of n)for(const a of t.allPoints){const r=Math.max(a.bucketEnd-a.bucketStart,1),n=Math.abs(a.time-e.time);a.isAnomaly&&(!l||n<l.distance)&&(l={analysis:t,point:a,distance:n}),n<=1.5*r&&(!i||n<i.distance)&&(i={analysis:t,point:a,distance:n})}const s=null!=i?i:l;return s?{analysis:s.analysis,point:s.point}:null})(e,t);if(!a)return null;const{analysis:r,point:n}=a,i=null===n.expected?null:n.value-n.expected,l=n.expected&&Math.abs(n.expected)>1e-9?i/n.expected*100:null;return{kind:"point",title:`${"window"===n.scoreDriver?"Sustained change":"Sharp change"} in ${r.label}`,subtitle:be(n.bucketStart,n.bucketEnd),seriesKey:r.key,seriesLabel:r.label,color:r.color,time:n.time,bucketStart:n.bucketStart,bucketEnd:n.bucketEnd,actual:n.value,expected:n.expected,deviation:i,deviationPercent:l,rangeLower:n.lower,rangeUpper:n.upper,sampleCount:n.sampleCount,minValue:n.minValue,maxValue:n.maxValue,score:n.score,pointScore:n.pointScore,windowScore:n.windowScore,scoreDriver:n.scoreDriver,severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel}}const r=a.find(t=>t.time===e.time);if(!r)return null;const n=t.map(e=>{const t=e.allPoints.find(e=>e.time===r.time);return t?{label:e.label,color:e.color,actual:t.value,expected:t.expected,deviation:null===t.expected?null:t.value-t.expected,rangeLower:t.lower,rangeUpper:t.upper,score:t.score,pointScore:t.pointScore,windowScore:t.windowScore,scoreDriver:t.scoreDriver,severityLabel:t.severityLabel,severityScore:t.severityScore,confidenceScore:t.confidenceScore,confidenceLabel:t.confidenceLabel,dataQualityLabel:t.dataQualityLabel}:null}).filter(e=>null!==e).sort((e,t)=>t.score-e.score);return{kind:"event",title:`Cross-metric incident at ${ye(r.time)}`,subtitle:be(r.bucketStart,r.bucketEnd),time:r.time,bucketStart:r.bucketStart,bucketEnd:r.bucketEnd,score:r.score,activeSeries:r.activeSeries,contributors:r.contributors,breakdown:n,severityLabel:r.severityLabel,severityScore:r.severityScore,confidenceScore:r.confidenceScore,confidenceLabel:r.confidenceLabel,dataQualityLabel:r.dataQualityLabel}},Ze=e=>{const t=new Set;return e.map(e=>(null!=e?e:"").trim()).filter(e=>!(!e||t.has(e))&&(t.add(e),!0))},Je=e=>{switch(e){case"warning_first":return 60;case"page_first":return 75;default:return 70}},Xe=e=>Object.entries(e).filter(([,e])=>e.length>0).map(([e,t])=>`${e}=${t}`).join("\n"),et=(e,t,a)=>{const r=e.document.querySelector(t);if(!r)return!1;const n=r.tagName.toLowerCase();if("input"!==n&&"textarea"!==n)return!1;return r.value=a,r.dispatchEvent(new Event("input",{bubbles:!0})),r.dispatchEvent(new Event("change",{bubbles:!0})),!0},tt=e=>{if("undefined"==typeof window)return!1;const t=new URL("/alerting/new",window.location.origin),a=new URLSearchParams(window.location.search).get("orgId");a&&t.searchParams.set("orgId",a),e.dashboardUid&&t.searchParams.set("dashboardUid",e.dashboardUid),e.panelId>0&&t.searchParams.set("panelId",String(e.panelId)),t.searchParams.set("title",e.ruleName),t.searchParams.set("ruleName",e.ruleName),e.folderTitle&&t.searchParams.set("folderTitle",e.folderTitle),t.searchParams.set("dashboardTitle",e.dashboardTitle),t.searchParams.set("panelTitle",e.panelTitle),t.searchParams.set("queryLanguage",e.queryLanguage),t.searchParams.set("threshold",String(e.threshold)),t.searchParams.set("for","10m"),t.searchParams.set("evaluateEvery","3m"),t.searchParams.set("labels",Xe(e.labels)),Object.entries(e.labels).forEach(([e,a])=>{a&&t.searchParams.set(`label_${e}`,a)}),e.alertQuery&&e.alertQuery.length<=1400&&t.searchParams.set("query",e.alertQuery),t.searchParams.set("returnTo",`${window.location.pathname}${window.location.search}`);try{window.sessionStorage.setItem("grafana-anomaly-alert-draft",JSON.stringify(e))}catch(e){}const r=window.open(t.toString(),"_blank");return!!r&&(((e,t)=>{let a=0;const r=()=>{a+=1;try{var n,i;const r=e.document;if(!r||e.closed)return;if(et(e,'[data-testid="data-testid alert-rule name-field"], input[name="name"], input[placeholder="Give your alert rule a name"]',t.ruleName),et(e,'input[type="number"]',String(t.threshold)),et(e,'[data-testid="annotation-value-0"], textarea[name="annotations.0.value"]',null!==(n=t.annotations.summary)&&void 0!==n?n:t.ruleName),et(e,'[data-testid="annotation-value-1"], textarea[name="annotations.1.value"]',null!==(i=t.annotations.description)&&void 0!==i?i:""),"promql"===t.queryLanguage.toLowerCase()){const n=r.querySelector('input[id^="option-code-radiogroup"]');n&&a<=2&&"function"==typeof n.click&&n.click();const i=['textarea[placeholder*="PromQL"]','textarea[aria-label*="Query"]','textarea[aria-label*="Editor content"]','input[placeholder*="PromQL"]','input[aria-label*="Query"]','textarea[name*="expr"]','input[name*="expr"]'].join(",");et(e,i,t.alertQuery)}}catch(e){}a<18&&!e.closed&&e.setTimeout(r,450)};e.setTimeout(r,450)})(r,e),!0)},at=e=>{var t,a;const r=(null!==(t=e.queryLanguage)&&void 0!==t?t:"").toLowerCase(),n=(null!==(a=e.target)&&void 0!==a?a:"").toLowerCase();return"promql"===r||"prometheus"===n||!r&&e.query.includes("grafana_anomaly_rule_score")},rt=e=>{if(0===e.length)return"";if(1===e.length)return e[0].query;if(!e.every(at))return e.map(e=>e.query).join("\n\n");return`max(max_over_time(grafana_anomaly_rule_score{rule=~"${e.map(e=>e.rule.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")}"}[5m]))`},nt=e=>{if(0===e.length)return"query";const t=Array.from(new Set(e.map(e=>e.queryLanguage).filter(e=>Boolean(e))));return 1===t.length?t[0]:e.every(at)?"PromQL":"target-specific query"},it=["prometheus","loki","influxdb","postgresql","clickhouse","elasticsearch"],lt=e=>{const t=String(null!=e?e:"").toLowerCase();return it.includes(t)?t:"prometheus"},st=e=>{const t=lt(e.target);return`${ft[t]}${e.queryLanguage?` (${e.queryLanguage})`:""}`},ot=(e,t)=>e?"point"===e.kind?`${e.title}. Raw detection score ${he(e.score)}; alert score ${e.severityScore}/100 (${le[e.severityLabel]}). Current ${he(e.actual)} vs expected ${he(e.expected)}.`:`${e.title}. Raw detection score ${he(e.score)} across ${e.activeSeries} active series; alert score ${e.severityScore}/100 (${le[e.severityLabel]}): ${e.contributors.slice(0,4).join(", ")}.`:`Anomaly score alert for ${t}.`,ct=e=>e.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"")||"metric",dt=(e,t,a,r)=>{if(!e)return null;const n=Ze(["anomaly-detector",e.severityLabel,e.confidenceLabel,e.dataQualityLabel,ct(r),e.kind]),i={time:e.bucketStart,tags:n,text:""};if(a&&(i.dashboardUID=a,i.dashboardUid=a),t>0&&(i.panelId=t),e.bucketEnd>e.bucketStart&&(i.timeEnd=e.bucketEnd,i.isRegion=!0),"point"===e.kind){const t=ct(e.seriesLabel);return n.includes(t)||n.push(t),i.text=[e.title,`Window: ${be(e.bucketStart,e.bucketEnd)}`,`Raw detection score: ${he(e.score)}`,`Alert score (0-100): ${le[e.severityLabel]} ${e.severityScore}`,`Confidence: ${oe[e.confidenceLabel]} (${he(e.confidenceScore)})`,`Data quality: ${de[e.dataQualityLabel]}`,`Actual: ${he(e.actual)} | Expected: ${he(e.expected)}`,`Deviation: ${he(e.deviation)}${null===e.deviationPercent?"":` (${he(e.deviationPercent)}%)`}`,`Expected range: ${he(e.rangeLower)} to ${he(e.rangeUpper)}`].join("\n"),i}return i.text=[e.title,`Window: ${be(e.bucketStart,e.bucketEnd)}`,`Raw detection score: ${he(e.score)}`,`Alert score (0-100): ${le[e.severityLabel]} ${e.severityScore}`,`Confidence: ${oe[e.confidenceLabel]} (${he(e.confidenceScore)})`,`Data quality: ${de[e.dataQualityLabel]}`,`Active series: ${e.activeSeries}`,`Top contributors: ${e.contributors.join(", ")||"No contributors found"}`].join("\n"),i},mt=e=>W(function*(){var t;if("undefined"!=typeof navigator&&(null===(t=navigator.clipboard)||void 0===t?void 0:t.writeText))try{return void(yield Promise.race([navigator.clipboard.writeText(e),new Promise((e,t)=>{("undefined"!=typeof window?window.setTimeout:setTimeout)(()=>t(new Error("Clipboard API timed out.")),900)})]))}catch(e){}if("undefined"==typeof document)throw new Error("Clipboard access is not available in this environment.");const a=document.createElement("textarea");a.value=e,a.setAttribute("readonly","true"),a.style.position="fixed",a.style.opacity="0",document.body.appendChild(a),a.select();const r=document.execCommand("copy");if(document.body.removeChild(a),!r)throw new Error("The browser blocked clipboard access.")})(),ut=(e,t)=>{if(e&&"object"==typeof e){const t=e,a=t.data,r=a&&"object"==typeof a?a:null,n="string"==typeof(null==r?void 0:r.message)&&r.message||"string"==typeof t.statusText&&t.statusText||"string"==typeof t.message&&t.message||"",i="number"!=typeof t.status||String(n).includes(String(t.status))?"":` (HTTP ${t.status})`;if(n)return`${n}${i}`}return e instanceof Error&&e.message?e.message:t},pt=e=>W(function*(){try{yield(0,y.getBackendSrv)().post("/api/annotations",e)}catch(e){throw new Error(ut(e,"Failed to create the Grafana annotation."))}})(),ht="http://127.0.0.1:9110",gt={off:"Off",manual:"Manual sync",auto:"Auto sync"},ft={prometheus:"Prometheus metrics",loki:"Loki",influxdb:"InfluxDB",postgresql:"PostgreSQL",clickhouse:"ClickHouse",elasticsearch:"Elasticsearch"},yt={prometheus:"Prometheus",loki:"Loki",influxdb:"InfluxDB",postgresql:"PostgreSQL",clickhouse:"ClickHouse",elasticsearch:"Elastic"},bt={prometheus:"#94A3B8",loki:"#F59E0B",influxdb:"#3B82F6",postgresql:"#60A5FA",clickhouse:"#FACC15",elasticsearch:"#22D3EE"},vt=e=>yt[lt(e)],xt=({target:e})=>{switch(lt(e)){case"loki":return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("path",{d:"M7 20V7.6l3.3-.9V20H7Z",fill:"#D97706"}),h().createElement("path",{d:"M11.3 20V3.8l3.4-.9V20h-3.4Z",fill:"#F59E0B"}),h().createElement("path",{d:"M15.8 20V10.2l3.2-.86V20h-3.2Z",fill:"#FBBF24"}),h().createElement("path",{d:"M5.2 20.4h15.1",stroke:"#B45309",strokeWidth:"1.8",strokeLinecap:"round"}));case"influxdb":return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("path",{d:"M12 2.8 20 7.3v9.4l-8 4.5-8-4.5V7.3l8-4.5Z",fill:"none",stroke:"#3B82F6",strokeWidth:"1.8"}),h().createElement("path",{d:"m12 2.8 3.9 7.1L12 21.2 8.1 9.9 12 2.8Z",fill:"none",stroke:"#60A5FA",strokeWidth:"1.3"}),h().createElement("path",{d:"M4 7.3 12 12l8-4.7M4 16.7 12 12l8 4.7",fill:"none",stroke:"#2563EB",strokeWidth:"1.2"}));case"postgresql":return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("path",{d:"M6.2 10.6c0-4.4 2.4-7 6.1-7 3.9 0 6.5 2.7 6.5 7 0 2.9-1.2 5.1-3.3 6.3l.3 3.1-2.9-1.8c-.8.15-1.7.15-2.6-.03L7.2 20l.43-3.35c-.95-.7-1.43-2.55-1.43-6.05Z",fill:"#3B82F6",opacity:"0.9"}),h().createElement("path",{d:"M9 10.1c.45-.5 1.25-.5 1.7 0M14 10.1c.45-.5 1.25-.5 1.7 0",stroke:"#DBEAFE",strokeWidth:"1.2",strokeLinecap:"round"}),h().createElement("path",{d:"M12.8 11.3c-.4 1.2-.15 2.1.75 2.7.85.6.95 1.55.15 2.45",fill:"none",stroke:"#DBEAFE",strokeWidth:"1.3",strokeLinecap:"round"}));case"clickhouse":return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("path",{d:"M4 4h3v16H4V4Zm5 0h3v16H9V4Zm5 0h3v16h-3V4Z",fill:"#FACC15"}),h().createElement("path",{d:"M19 4h1.8v16H19V4Z",fill:"#EF4444"}));case"elasticsearch":return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("circle",{cx:"9",cy:"7",r:"4",fill:"#F59E0B"}),h().createElement("circle",{cx:"15.2",cy:"7.7",r:"3.3",fill:"#22C55E"}),h().createElement("circle",{cx:"16.1",cy:"14.8",r:"4",fill:"#06B6D4"}),h().createElement("circle",{cx:"8.2",cy:"15.5",r:"3.5",fill:"#EF4444"}),h().createElement("circle",{cx:"12",cy:"11.5",r:"3.3",fill:"#64748B",opacity:"0.72"}));default:return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("ellipse",{cx:"12",cy:"5.4",rx:"7.2",ry:"3.1",fill:"#64748B"}),h().createElement("path",{d:"M4.8 5.4v4.5c0 1.7 3.2 3.1 7.2 3.1s7.2-1.4 7.2-3.1V5.4",fill:"#475569"}),h().createElement("ellipse",{cx:"12",cy:"9.9",rx:"7.2",ry:"3.1",fill:"#94A3B8"}),h().createElement("path",{d:"M4.8 9.9v4.5c0 1.7 3.2 3.1 7.2 3.1s7.2-1.4 7.2-3.1V9.9",fill:"#475569"}),h().createElement("ellipse",{cx:"12",cy:"14.4",rx:"7.2",ry:"3.1",fill:"#CBD5E1"}))}},wt=e=>h().createElement(xt,{target:e}),Et=e=>(null!=e?e:ht).trim().replace(/\/+$/,"")||ht,kt=e=>e.trim().toLowerCase().replace(/[^a-z0-9_]+/g,"_").replace(/^_+|_+$/g,"")||"anomaly_panel",St=(e,t)=>{const a=kt(e||"anomaly_panel"),r=kt(null!=t?t:"");return r?`${r}_${a}`:a},Ft=()=>{var e;if("undefined"==typeof window)return"";const t=window.location.pathname.match(/\/d\/([^/]+)/);return null!==(e=null==t?void 0:t[1])&&void 0!==e?e:""},Nt=()=>"undefined"==typeof document?"":document.title.replace(/\s+-\s+Grafana$/i,"").replace(/^View panel\s+-\s+/i,"").replace(/^Edit panel\s+-\s+/i,"").replace(/\s+-\s+Dashboards$/i,"").trim(),$t=()=>{if("undefined"==typeof document)return"";const e=Array.from(document.querySelectorAll('nav[aria-label="Breadcrumbs"] a')).map(e=>{var t,a;return null!==(t=null===(a=e.textContent)||void 0===a?void 0:a.trim())&&void 0!==t?t:""}).filter(Boolean);return e.length>=3&&"dashboards"===e[0].toLowerCase()?e[1]:""},Mt=(e,t)=>{const a=e.trim(),r=t.trim().toLowerCase();return a&&("postgres"!==r&&"postgresql"!==r&&!r.includes("postgresql")||/^postgres(?:ql)?:\/\//i.test(a))?a:""},Lt=e=>e.flatMap((e,t)=>{var a,r,n,i,l,s,o,c,d,m,u,p,h,g,f,y,b,v;if(!e||"object"!=typeof e)return[];const x=e;if(!0===x.hide)return[];const w=(e=>{var t,a,r,n;if("string"==typeof e)return{uid:e,type:"",url:""};if(!e||"object"!=typeof e)return{uid:"",type:"",url:""};const i=e;return{uid:String(null!==(t=null!==(a=i.uid)&&void 0!==a?a:i.name)&&void 0!==t?t:""),type:String(null!==(r=i.type)&&void 0!==r?r:""),url:String(null!==(n=i.url)&&void 0!==n?n:"")}})(x.datasource),E=String(null!==(a=null!==(r=x.datasourceUid)&&void 0!==r?r:w.uid)&&void 0!==a?a:"").trim(),k=String(null!==(n=null!==(i=x.datasourceType)&&void 0!==i?i:w.type)&&void 0!==n?n:"").trim().toLowerCase(),S=Mt(String(null!==(l=null!==(s=null!==(o=x.datasourceUrl)&&void 0!==o?o:x.url)&&void 0!==s?s:w.url)&&void 0!==l?l:"").trim(),k),F=String(null!==(c=null!==(d=null!==(m=null!==(u=null!==(p=x.expr)&&void 0!==p?p:x.expression)&&void 0!==u?u:x.query)&&void 0!==m?m:x.rawSql)&&void 0!==d?d:x.rawQuery)&&void 0!==c?c:"").trim(),N="elasticsearch"===k&&(x.metrics||x.bucketAggs||x.timeField)?JSON.stringify({query:F,metrics:null!==(h=x.metrics)&&void 0!==h?h:[],bucketAggs:null!==(g=x.bucketAggs)&&void 0!==g?g:[],timeField:null!==(f=x.timeField)&&void 0!==f?f:"@timestamp"}):F;return N?"__expr__"===E||"__expr__"===k||"expression"===k?[]:[{refId:String(null!==(y=x.refId)&&void 0!==y?y:`Q${t+1}`).trim()||`Q${t+1}`,expr:N,legend:String(null!==(b=null!==(v=x.legendFormat)&&void 0!==v?v:x.legend)&&void 0!==b?b:"").trim(),datasourceUid:E,datasourceType:k,datasourceUrl:S}]:[]}).filter((e,t,a)=>a.findIndex(t=>t.refId===e.refId&&t.expr===e.expr)===t),Ct=(e,t)=>W(function*(){if(!e||"__expr__"===e||"undefined"==typeof fetch)return"";try{var a,r;const n=yield fetch(`/api/datasources/uid/${encodeURIComponent(e)}`,{credentials:"same-origin"});if(!n.ok)return"";const i=yield n.json();return Mt(String(null!==(a=i.url)&&void 0!==a?a:"").trim(),String(null!==(r=i.type)&&void 0!==r?r:t))}catch(e){return""}})(),At=e=>W(function*(){if(0===e.length)return e;const t=Array.from(new Set(e.filter(e=>!e.datasourceUrl&&e.datasourceUid).map(e=>`${e.datasourceUid}:::${e.datasourceType}`))),a=yield Promise.all(t.map(e=>W(function*(){const[t,a]=e.split(":::");return[t,yield Ct(t,a)]})())),r=new Map(a);return e.map(e=>U(j({},e),{datasourceUrl:e.datasourceUrl||r.get(e.datasourceUid)||""}))})(),Bt=e=>{const t=[];return e.forEach(e=>{if(!e||"object"!=typeof e)return;const a=e;void 0!==a.id&&t.push(a),Array.isArray(a.panels)&&t.push(...Bt(a.panels))}),t},Dt=(e,t)=>W(function*(){var a,r,n,i,l,s,o,c;const d=Ft();if(!d||"undefined"==typeof fetch)return null;const m=yield fetch(`/api/dashboards/uid/${encodeURIComponent(d)}`,{credentials:"same-origin"});if(!m.ok)throw new Error(`Could not read the saved dashboard definition (${m.status}).`);const u=yield m.json(),p=null!==(a=u.dashboard)&&void 0!==a?a:{},h=String(null!==(r=null!==(n=null===(c=u.meta)||void 0===c?void 0:c.folderTitle)&&void 0!==n?n:$t())&&void 0!==r?r:"").trim(),g=Bt(Array.isArray(p.panels)?p.panels:[]).find(t=>{var a;return Number(null!==(a=t.id)&&void 0!==a?a:-1)===e});if(!g)return null;const f=yield At(Lt(Array.isArray(g.targets)?g.targets:[]));return{source:"saved",dashboardUid:d,folderTitle:h,dashboardTitle:String(null!==(i=null!==(l=p.title)&&void 0!==l?l:Nt())&&void 0!==i?i:d).trim()||d,panelTitle:String(null!==(s=g.title)&&void 0!==s?s:t).trim()||t,targets:f,panelOptions:null!==(o=g.options)&&void 0!==o?o:{}}})(),Tt=(e,t,a,r)=>{var n,i;return JSON.stringify({dashboardUid:e.dashboardUid,panelTitle:e.panelTitle,source:e.source,ruleNamePrefix:a,target:r,rangeSeconds:null!==(n=e.rangeSeconds)&&void 0!==n?n:0,stepSeconds:null!==(i=e.stepSeconds)&&void 0!==i?i:0,targets:e.targets.map(e=>{var t;return{refId:e.refId,expr:e.expr,datasourceUid:e.datasourceUid,datasourceType:e.datasourceType,datasourceUrl:null!==(t=e.datasourceUrl)&&void 0!==t?t:""}}),resolvedOptions:{setupMode:t.setupMode,metricPreset:t.metricPreset,effectiveMetricPreset:t.effectiveMetricPreset,detectionMode:t.detectionMode,algorithm:t.algorithm,sensitivity:t.sensitivity,baselineWindow:t.baselineWindow,seasonalitySamples:t.seasonalitySamples,seasonalRefinement:t.seasonalRefinement,severityPreset:t.severityPreset}})},Pt=e=>{switch(e){case"1m":return 60;case"5m":return 300;case"15m":return 900;case"1h":return 3600;default:return 0}},_t=(e,t,a,r,n,i)=>{var l,s;const o=e.targets.filter(e=>e.expr.trim().length>0);if(0===o.length)return null;const c=Pt(n.bucketSpan),d=Math.max(0,Math.round(null!==(l=e.stepSeconds)&&void 0!==l?l:0)),m=d>0?d:c>0?Math.max(5,Math.min(c,60)):30,u=Math.max(256,n.baselineWindow*Math.max(n.seasonalitySamples,1)+8,6*n.baselineWindow),p=Math.max(0,Math.round(null!==(s=e.rangeSeconds)&&void 0!==s?s:0)),h=Math.max(3600,u*m);return{dashboardUid:e.dashboardUid,folderTitle:e.folderTitle,dashboardTitle:e.dashboardTitle,panelId:t,panelTitle:e.panelTitle,ruleNamePrefix:St(e.panelTitle,a),target:r,source:e.source,syncHash:i,targets:o.map(e=>{var t;return{refId:e.refId,expr:e.expr,legend:e.legend,datasourceUid:e.datasourceUid,datasourceType:e.datasourceType,datasourceUrl:null!==(t=e.datasourceUrl)&&void 0!==t?t:""}}),resolvedOptions:{setupMode:n.setupMode,metricPreset:n.metricPreset,effectiveMetricPreset:n.effectiveMetricPreset,detectionMode:n.detectionMode,algorithm:n.algorithm,sensitivity:n.sensitivity,baselineWindow:n.baselineWindow,seasonalitySamples:n.seasonalitySamples,seasonalRefinement:n.seasonalRefinement,severityPreset:n.severityPreset,rangeSeconds:p>0?Math.max(4*m,p):h,stepSeconds:m,bucketSpanSeconds:c}}},Rt=e=>"off"===e?{kind:"off",message:"Anomaly score feed is turned off for this panel.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}:"manual"===e?{kind:"idle",message:"Manual sync is ready. Use the button to publish plugin-computed anomaly scores for this panel.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}:{kind:"idle",message:"Auto sync watches this panel and republishes plugin-computed anomaly scores shortly after data is returned.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""},Vt=e=>{switch(e){case"synced":return"Synced";case"syncing":return"Syncing";case"error":return"Error";case"unsupported":return"Action needed";case"off":return"Off";default:return"Ready"}},Ot=({panelId:e,panelTitle:t,options:a,resolvedOptions:r,liveTargets:n,analyses:i,timeRangeSeconds:l,queryStepSeconds:s})=>{var o;const[c,d]=(0,p.useState)(()=>{var e;return Rt(null!==(e=a.scoreFeedMode)&&void 0!==e?e:"auto")}),[m,u]=(0,p.useState)(""),h=null!==(o=a.scoreFeedMode)&&void 0!==o?o:"auto",g=(0,p.useCallback)((o="manual")=>W(function*(){var c;if("off"!==h)try{var p,g,f,y,b,v,x,w;let h=((e,t,a,r,n)=>({source:"live",dashboardUid:Ft()||"local_dashboard",folderTitle:$t(),dashboardTitle:Nt()||"Grafana dashboard",panelTitle:t,targets:a,panelOptions:{},rangeSeconds:r,stepSeconds:n}))(0,t,n,l,s),E=a,k=Et(a.scoreFeedEndpoint);if("auto"===o){const r=yield Dt(e,t).catch(()=>null);r&&(E=j({},a,r.panelOptions),h=U(j({},r),{targets:n.length>0?n:r.targets,source:n.length>0?"live":r.source,rangeSeconds:l,stepSeconds:s}),k=Et(E.scoreFeedEndpoint))}const S=null!==(p="auto"===o?E.scoreFeedRuleNamePrefix:a.scoreFeedRuleNamePrefix)&&void 0!==p?p:"",F=lt("auto"===o?E.scoreFeedTarget:a.scoreFeedTarget);h=U(j({},h),{targets:yield At(h.targets),rangeSeconds:l,stepSeconds:s});const N=Tt(h,r,S,F),$=_t(h,e,S,F,r,N),M=((e,t,a,r,n,i)=>{const l=i.flatMap(e=>{var t;const a=null!==(t=[...e.allPoints].reverse().find(e=>null!==e.expected))&&void 0!==t?t:e.allPoints[e.allPoints.length-1];return a?[{key:e.key,label:e.label,timestamp:a.time/1e3,value:a.value,expected:a.expected,lower:a.lower,upper:a.upper,deviation:null===a.expected?null:a.value-a.expected,rawScore:a.score,pointRawScore:a.pointScore,windowRawScore:a.windowScore,scoreDriver:a.scoreDriver,normalizedScore:a.severityScore,severityLabel:a.severityLabel,isAnomaly:a.isAnomaly,confidenceScore:a.confidenceScore,confidenceLabel:a.confidenceLabel,dataQualityLabel:a.dataQualityLabel,threshold:n.sensitivity}]:[]});if(0===l.length)return null;const s=[...l].sort((e,t)=>t.normalizedScore-e.normalizedScore)[0],o=Array.from(new Map(e.targets.map(e=>[`${e.datasourceUid||"unknown"}:${e.datasourceType||"unknown"}`,{uid:e.datasourceUid||"unknown",type:e.datasourceType||"unknown"}])).values());return{dashboardUid:e.dashboardUid,folderTitle:e.folderTitle,dashboardTitle:e.dashboardTitle,panelId:t,panelTitle:e.panelTitle,ruleName:St(e.panelTitle,a),target:r,source:e.source,sourceDatasources:o,series:l,rule:{timestamp:Math.max(...l.map(e=>e.timestamp)),score:s.normalizedScore,rawScore:s.rawScore,breachCount:l.filter(e=>e.isAnomaly).length,seriesCount:l.length,activeSeries:l.length,severityLabel:s.severityLabel},resolvedOptions:{algorithm:n.algorithm,severityPreset:n.severityPreset,sensitivity:n.sensitivity}}})(h,e,S,F,r,i);if(!$&&!M)return void d((c="This panel has no query target or computed anomaly score points to publish yet. Refresh the panel after data is returned.",{kind:"unsupported",message:c,source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}));const L=JSON.stringify({registrationHash:N,target:F,ruleName:null!==(g=null!==(f=null==M?void 0:M.ruleName)&&void 0!==f?f:null==$?void 0:$.ruleNamePrefix)&&void 0!==g?g:"",ruleScore:null!==(y=null==M?void 0:M.rule.score)&&void 0!==y?y:null,ruleTimestamp:null!==(b=null==M?void 0:M.rule.timestamp)&&void 0!==b?b:null,series:null!==(v=null==M?void 0:M.series.map(e=>[e.key,e.timestamp,e.normalizedScore,e.isAnomaly]))&&void 0!==v?v:[],algorithm:r.algorithm,severityPreset:r.severityPreset});if("auto"===o&&L===m)return void d(e=>U(j({},e),{kind:"error"===e.kind?e.kind:"synced",message:null!==e.lastSyncedAt?e.message:`Auto sync is active. Latest plugin-computed scores are published to ${ft[F]}.`,source:h.source,syncHash:L}));d(e=>{var t;return U(j({},e),{kind:"syncing",message:"auto"===o?`Registering panel score feed and publishing latest scores to ${ft[F]}.`:`Registering panel score feed and publishing scores to ${ft[F]}.`,source:null!==(t=null==h?void 0:h.source)&&void 0!==t?t:e.source})});let C={};if($){const e=yield fetch(`${k}/api/sync/panel`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify($)});if(C=yield e.json(),!e.ok)throw new Error(C.error||`Panel registration failed with status ${e.status}.`)}let A={};if(M){const e=yield fetch(`${k}/api/feed/scores`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(M)});if(A=yield e.json(),!e.ok)throw new Error(A.error||`Sync failed with status ${e.status}.`)}const B=((e,t)=>{const a=new Map;return e.forEach(e=>{var t;return a.set(`${e.rule}:${null!==(t=e.target)&&void 0!==t?t:""}`,e)}),t.forEach(e=>{var t;return a.set(`${e.rule}:${null!==(t=e.target)&&void 0!==t?t:""}`,e)}),Array.from(a.values())})(Array.isArray(A.registered)?A.registered:[],Array.isArray(C.registered)?C.registered:[]),D=[...Array.isArray(C.removed)?C.removed:[],...Array.isArray(A.removed)?A.removed:[]],T="saved"===h.source?"saved dashboard":"live panel",P=Math.max(0,Math.round(null!==(x=null!==(w=A.acceptedSeries)&&void 0!==w?w:null==M?void 0:M.series.length)&&void 0!==x?x:B.length));u(L),d({kind:"synced",message:B.length>0?M?`Published ${P} plugin-computed score series and registered backend recompute from the ${T} to ${ft[F]}.`:`Registered backend recompute from the ${T} to ${ft[F]}; scores will continue while the dashboard is closed.`:D.length>0?`Removed ${D.length} previous score feed registration${1===D.length?"":"s"} because this panel no longer exposes computed score data.`:`Score feed is active for this panel and targets ${ft[F]}.`,source:h.source,registered:B,removed:D,lastSyncedAt:Date.now(),syncHash:L})}catch(e){d(t=>U(j({},t),{kind:"error",message:e instanceof Error?e.message:"Score feed sync failed unexpectedly."}))}else d(Rt("off"))})(),[i,n,m,a,e,t,s,r,h,l]);return(0,p.useEffect)(()=>{if("off"===h)return void d(Rt("off"));if("manual"===h)return void d(e=>j({},"synced"===e.kind?e:U(j({},Rt("manual")),{source:e.source,registered:e.registered,removed:e.removed,lastSyncedAt:e.lastSyncedAt,syncHash:e.syncHash})));if("undefined"==typeof window)return;let e=!1,t=!1;const a=()=>W(function*(){if(!e&&!t){t=!0;try{yield g("auto")}finally{t=!1}}})();a();const r=window.setInterval(()=>{a()},15e3);return()=>{e=!0,window.clearInterval(r)}},[g,h]),U(j({},c),{syncNow:()=>g("manual")})},It=["Configuration"],qt=["Anomaly score feed"],Wt=["Analysis"],zt=["Advanced tuning"],jt=["Display"],Ut=["Visible sections"],Ht=[{label:"Recommended",value:"recommended",description:"Pick the metric type and let the plugin choose the algorithm and severity tuning."},{label:"Advanced",value:"advanced",description:"Expose manual algorithm, threshold, and severity controls."}],Qt=[{label:"Single metric",value:"single"},{label:"Multi metric",value:"multi"}],Gt=[{label:"Auto sync (Recommended)",value:"auto",description:"Continuously publish plugin-computed anomaly scores to the selected score feed target."},{label:"Manual sync",value:"manual",description:"Show a sync button so users can publish the current plugin-computed score snapshot on demand."},{label:"Off",value:"off",description:"Disable anomaly score feed publishing for this panel."}],Yt=[{label:"Prometheus metrics",value:"prometheus",description:"Expose the plugin-computed anomaly scores from the exporter /metrics endpoint."},{label:"Loki",value:"loki",description:"Write plugin-computed anomaly scores to the Loki sink."},{label:"InfluxDB",value:"influxdb",description:"Write plugin-computed anomaly scores to the InfluxDB sink."},{label:"PostgreSQL",value:"postgresql",description:"Write plugin-computed anomaly scores to the PostgreSQL sink."},{label:"ClickHouse",value:"clickhouse",description:"Write plugin-computed anomaly scores to the ClickHouse sink."},{label:"Elasticsearch",value:"elasticsearch",description:"Write plugin-computed anomaly scores to the Elasticsearch sink."}],Kt=[{label:"Auto (Recommended)",value:"auto",description:"Inspect the metric names and choose the safest starting algorithm automatically."},{label:"Traffic / throughput",value:"traffic",description:"Good starting point for request rate, throughput, and volume metrics."},{label:"Latency / duration",value:"latency",description:"Tuned for latency, p95, and response-time style metrics."},{label:"Error rate",value:"error_rate",description:"Tuned for error percentage and error-count spikes."},{label:"Resource usage",value:"resource",description:"Useful for CPU, memory, load, saturation, and host metrics."},{label:"Business KPI",value:"business",description:"Useful for revenue, signups, conversions, and other cyclical business metrics."},{label:"Subtle level shift / drift",value:"level_shift",description:"Best when the baseline changes gradually or steps up/down without a single sharp spike."}],Zt=[{label:"Auto",value:"auto",description:"Choose an efficient pre-aggregation span automatically on dense or live data."},{label:"Raw samples",value:"raw",description:"Analyze every incoming sample without pre-aggregation."},{label:"1 minute",value:"1m",description:"Aggregate close samples into 1-minute buckets before scoring."},{label:"5 minutes",value:"5m",description:"Aggregate samples into 5-minute buckets before scoring."},{label:"15 minutes",value:"15m",description:"Aggregate samples into 15-minute buckets before scoring."},{label:"1 hour",value:"1h",description:"Aggregate samples into 1-hour buckets before scoring."}],Jt=[{label:"Rolling z-score",value:"zscore",description:"Fast default for spikes and dips in streaming metrics."},{label:"Rolling MAD",value:"mad",description:"Robust against noisy outliers and uneven distributions."},{label:"EWMA baseline",value:"ewma",description:"Tracks gradual baseline shifts while still catching sudden jumps."},{label:"Seasonal baseline",value:"seasonal",description:"Compares each point with similar positions from earlier cycles."},{label:"Level shift detector",value:"level_shift",description:"Looks for sustained baseline changes and subtle step-ups that build over several buckets."}],Xt=[{label:"Cycle only",value:"cycle",description:"Uses a fixed sample lag such as 24 or 288 samples."},{label:"Hour of day",value:"hour_of_day",description:"Matches earlier values from the same hour bucket."},{label:"Weekday + hour",value:"weekday_hour",description:"Matches earlier values from the same weekday and hour bucket."}],ea=[{label:"Balanced",value:"balanced",description:"General-purpose default for dashboards and alert handoff."},{label:"Warning first",value:"warning_first",description:"Promotes warning and medium severity earlier for watchlist-heavy teams."},{label:"Page first",value:"page_first",description:"Keeps high and critical severities stricter for paging workflows."}],ta=[{label:"Auto (Recommended)",value:"auto",description:"Choose a readable time tick density automatically from the panel width and visible range."},{label:"Compact",value:"compact",description:"Use fewer time labels for dense dashboards and smaller panels."},{label:"Balanced",value:"balanced",description:"Keep a mid-density time axis for general dashboard use."},{label:"Dense",value:"dense",description:"Show more time labels for close operational tracking."}],aa=[{label:"Bottom only",value:"bottom",description:"Show time labels only on the bottom axis."},{label:"Top + bottom",value:"top_and_bottom",description:"Add a second time guide on top for faster cross-checking during incident review."}],ra=[{label:"Severity shapes (Recommended)",value:"severity",description:"Use different marker shapes for low, medium, high, and critical anomalies."},{label:"Classic circles",value:"classic",description:"Keep the previous circle-style anomaly markers."}],na=new c.PanelPlugin(({id:e,options:t,data:a,width:r,height:n,timeRange:i,timeZone:l})=>{var s,o,d,m,u,y,b,v,x,w,E,k,S,F,N,$;const M=(0,f.useTheme2)(),L=(C=M.isDark,{wrapper:g.css`
    width: 100%;
    height: 100%;
    min-height: 0;
    container-type: inline-size;
    padding: 10px;
    box-sizing: border-box;
    overflow: auto;
    font-family: 'Segoe UI', sans-serif;
    color: ${C?"#F3F4F6":"#111827"};
    background: ${C?"radial-gradient(circle at 8% 0%, rgba(220,38,38,0.12), transparent 26%), linear-gradient(180deg, #060A12 0%, #0B111C 100%)":"linear-gradient(180deg, #F8FAFC 0%, #EEF4FF 100%)"};
  `,operationalCanvas:g.css`
    width: 100%;
    min-height: 100%;
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(300px, 360px);
    gap: 12px;
    align-items: stretch;
    @media (max-width: 1100px) {
      grid-template-columns: 1fr;
    }
    @container (max-width: 1040px) {
      grid-template-columns: 1fr;
    }
  `,workspacePane:g.css`
    min-width: 0;
    min-height: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,inspectorRail:g.css`
    min-width: 0;
    min-height: 0;
    @media (min-width: 1101px) {
      position: sticky;
      top: 0;
      align-self: start;
      max-height: calc(100vh - 24px);
      overflow: auto;
    }
    @container (max-width: 1040px) {
      position: static;
      max-height: none;
      overflow: visible;
    }
  `,header:g.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
  `,statusHeader:g.css`
    position: relative;
    display: grid;
    grid-template-columns: minmax(260px, 0.9fr) minmax(340px, 1.1fr);
    gap: 18px;
    align-items: stretch;
    padding: 14px 16px 14px 22px;
    border-radius: 18px;
    border: 1px solid ${C?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${C?"linear-gradient(135deg, rgba(17,24,39,0.94) 0%, rgba(12,18,29,0.98) 62%, rgba(8,13,22,0.98) 100%)":"linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%)"};
    overflow: hidden;
    box-shadow: ${C?"0 22px 70px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.04)":"0 16px 34px rgba(15,23,42,0.06)"};
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
  `,statusRail:g.css`
    position: absolute;
    inset: 0 auto 0 0;
    width: 5px;
    border-radius: 18px 0 0 18px;
  `,statusMain:g.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 10px;
    padding-left: 48px;
    @media (max-width: 700px) {
      padding-left: 34px;
    }
  `,statusIcon:g.css`
    position: absolute;
    left: 18px;
    top: 50%;
    width: 30px;
    height: 30px;
    transform: translateY(-50%);
    display: grid;
    place-items: center;
    border-radius: 999px;
    color: #FCA5A5;
    border: 1px solid rgba(248,113,113,0.62);
    background: rgba(127,29,29,0.22);
    box-shadow: 0 0 0 5px rgba(220,38,38,0.08);
  `,statusIconSvg:g.css`
    width: 18px;
    height: 18px;
    overflow: visible;
  `,statusTitleRow:g.css`
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
  `,statusBadge:g.css`
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 6px 10px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    border: 1px solid currentColor;
  `,statusDot:g.css`
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: currentColor;
    box-shadow: 0 0 0 3px ${C?"rgba(148,163,184,0.18)":"rgba(15,23,42,0.10)"};
  `,titleBlock:g.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
  `,title:g.css`
    font-size: clamp(22px, 1.65vw, 30px);
    font-weight: 800;
    letter-spacing: 0.01em;
  `,subtitle:g.css`
    font-size: 12px;
    color: ${C?"#94A3B8":"#475569"};
    line-height: 1.5;
  `,headerMetaGrid:g.css`
    display: grid;
    grid-template-columns: repeat(2, minmax(140px, max-content));
    gap: 8px 24px;
    color: ${C?"#C7D2E4":"#334155"};
    font-size: 12px;
    font-weight: 700;
    @media (max-width: 700px) {
      grid-template-columns: 1fr;
    }
  `,metaAccent:g.css`
    color: #F87171;
    font-weight: 900;
  `,recommendationBanner:g.css`
    display: none;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 12px;
    border-radius: 14px;
    border: 1px solid ${C?"#1E293B":"#D7E3F4"};
    background: ${C?"#111827":"#F8FAFC"};
  `,recommendationBadge:g.css`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 78px;
    padding: 6px 10px;
    border-radius: 999px;
    background: ${C?"#172554":"#DBEAFE"};
    color: ${C?"#BFDBFE":"#1D4ED8"};
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
  `,recommendationCopy:g.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  `,recommendationTitle:g.css`
    font-size: 13px;
    font-weight: 700;
    color: ${C?"#F8FAFC":"#0F172A"};
  `,recommendationText:g.css`
    font-size: 12px;
    line-height: 1.55;
    color: ${C?"#CBD5E1":"#334155"};
  `,stats:g.css`
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
  `,statusStats:g.css`
    display: grid;
    grid-template-columns: 1.18fr repeat(3, minmax(82px, 1fr));
    gap: 10px;
    align-content: stretch;
    min-width: 0;
    @media (max-width: 700px) {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  `,statCard:g.css`
    min-width: 0;
    padding: 12px 13px;
    border-radius: 12px;
    border: 1px solid ${C?"rgba(148,163,184,0.12)":"#D7E3F4"};
    background: ${C?"linear-gradient(180deg, rgba(30,41,59,0.62), rgba(15,23,42,0.82))":"#F8FAFC"};
    box-shadow: ${C?"inset 0 1px 0 rgba(255,255,255,0.04)":"none"};
  `,statCardPrimary:g.css`
    border-color: rgba(248,113,113,0.38);
    background: linear-gradient(145deg, #B91C1C 0%, #7F1D1D 100%);
    color: #FFFFFF !important;
    box-shadow: 0 12px 26px rgba(220,38,38,0.22), inset 0 1px 0 rgba(255,255,255,0.12);
  `,statLabel:g.css`
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: ${C?"#94A3B8":"#64748B"};
  `,statValue:g.css`
    margin-top: 6px;
    font-size: clamp(18px, 1.35vw, 22px);
    font-weight: 850;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  `,statCaption:g.css`
    margin-top: 3px;
    font-size: 11px;
    color: ${C?"#94A3B8":"#64748B"};
    font-weight: 800;
  `,chartCard:g.css`
    flex: 1 1 auto;
    min-height: clamp(340px, 45vh, 520px);
    position: relative;
    border-radius: 12px;
    border: 1px solid ${C?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${C?"linear-gradient(180deg, #0A1321 0%, #07101D 100%)":"#FFFFFF"};
    overflow: hidden;
    box-shadow: ${C?"inset 0 1px 0 rgba(255,255,255,0.04), 0 18px 44px rgba(0,0,0,0.22)":"0 14px 28px rgba(15,23,42,0.05)"};
    outline: none;
    &:focus-visible {
      border-color: ${C?"#60A5FA":"#2563EB"};
      box-shadow: ${C?"0 0 0 1px rgba(96,165,250,0.55), inset 0 1px 0 rgba(148,163,184,0.05)":"0 0 0 1px rgba(37,99,235,0.35), 0 14px 28px rgba(15,23,42,0.05)"};
    }
  `,incidentRibbonPanel:g.css`
    position: relative;
    min-height: 34px;
    padding: 5px 10px;
    border-radius: 13px;
    border: 1px solid ${C?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${C?"linear-gradient(180deg, rgba(15,23,42,0.92), rgba(8,13,22,0.98))":"#FFFFFF"};
    box-shadow: ${C?"inset 0 1px 0 rgba(255,255,255,0.035)":"0 10px 22px rgba(15,23,42,0.04)"};
  `,incidentRibbonEmpty:g.css`
    display: flex;
    align-items: center;
    min-height: 24px;
    padding: 0 4px;
    color: ${C?"#94A3B8":"#64748B"};
    font-size: 12px;
    font-weight: 700;
  `,legend:g.css`
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    align-items: center;
  `,legendTable:g.css`
    border-radius: 12px;
    border: 1px solid ${C?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${C?"linear-gradient(180deg, rgba(15,23,42,0.94), rgba(10,16,26,0.98))":"#FFFFFF"};
    overflow: hidden;
    min-width: 0;
  `,legendTableHeader:g.css`
    display: grid;
    grid-template-columns: minmax(180px, 1fr) 96px 84px 104px;
    gap: 10px;
    padding: 8px 12px;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: ${C?"#94A3B8":"#64748B"};
    border-bottom: 1px solid ${C?"#1E293B":"#D7E3F4"};
    @media (max-width: 700px) {
      grid-template-columns: minmax(0, 1fr) 72px 72px;
      & > span:last-child {
        display: none;
      }
    }
  `,legendTableRow:g.css`
    display: grid;
    grid-template-columns: minmax(180px, 1fr) 96px 84px 104px;
    gap: 10px;
    align-items: center;
    padding: 9px 12px;
    border-bottom: 1px solid ${C?"rgba(30,41,59,0.7)":"rgba(215,227,244,0.8)"};
    font-size: 12px;
    &:last-child {
      border-bottom: 0;
    }
    @media (max-width: 700px) {
      grid-template-columns: minmax(0, 1fr) 72px 72px;
      & > span:last-child {
        display: none;
      }
    }
  `,legendTableFooter:g.css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 9px 12px;
    border-top: 1px solid ${C?"rgba(30,41,59,0.8)":"rgba(215,227,244,0.9)"};
    color: ${C?"#94A3B8":"#64748B"};
    font-size: 11px;
    font-weight: 750;
  `,legendSeriesName:g.css`
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 700;
    color: ${C?"#E2E8F0":"#0F172A"};
  `,legendValue:g.css`
    font-variant-numeric: tabular-nums;
    font-weight: 700;
    color: ${C?"#CBD5E1":"#334155"};
  `,legendItem:g.css`
    display: inline-flex;
    align-items: center;
    gap: 8px;
    max-width: 100%;
    min-width: 0;
    font-size: 12px;
    padding: 6px 10px;
    border-radius: 999px;
    background: ${C?"#111827":"#EFF6FF"};
    border: 1px solid ${C?"#1E293B":"#D7E3F4"};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,legendSwatch:g.css`
    width: 10px;
    height: 10px;
    border-radius: 999px;
  `,grid:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
    gap: 12px;
  `,bottomDock:g.css`
    display: grid;
    grid-template-columns: minmax(360px, 1.1fr) minmax(280px, 0.9fr);
    gap: 10px;
    align-items: stretch;
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
  `,secondaryDock:g.css`
    display: grid;
    grid-template-columns: minmax(420px, 1.35fr) minmax(260px, 0.65fr);
    gap: 10px;
    align-items: start;
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
  `,sideUtilityStack:g.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,card:g.css`
    border-radius: 12px;
    border: 1px solid ${C?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${C?"linear-gradient(180deg, rgba(15,23,42,0.94), rgba(10,16,26,0.98))":"#FFFFFF"};
    padding: 14px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    min-height: 0;
    box-shadow: ${C?"inset 0 1px 0 rgba(255,255,255,0.035)":"0 10px 24px rgba(15,23,42,0.045)"};
  `,cardTitle:g.css`
    font-size: 15px;
    font-weight: 700;
    line-height: 1.4;
  `,summaryList:g.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
    max-height: min(360px, 42vh);
    overflow-y: auto;
    padding-right: 4px;
  `,summaryTimeline:g.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 10px 12px 12px;
    border-radius: 14px;
    border: 1px solid ${C?"#1E293B":"#D7E3F4"};
    background: ${C?"#0F172A":"#F8FAFC"};
  `,summaryRow:g.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${C?"#1E293B":"#D7E3F4"};
    background: ${C?"#111827":"#F8FAFC"};
    cursor: pointer;
    transition: transform 120ms ease, border-color 120ms ease;
    &:hover {
      transform: translateY(-1px);
      border-color: ${C?"#334155":"#93C5FD"};
    }
  `,summaryRowSelected:g.css`
    border-color: ${C?"#3B82F6":"#2563EB"};
    box-shadow: inset 0 0 0 1px ${C?"#3B82F6":"#2563EB"};
  `,summaryTitle:g.css`
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
  `,summaryMeta:g.css`
    display: flex;
    justify-content: space-between;
    gap: 8px;
    flex-wrap: wrap;
    font-size: 12px;
    color: ${C?"#94A3B8":"#475569"};
  `,severityBadge:g.css`
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  `,compactHealthStrip:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(118px, 1fr));
    gap: 8px;
  `,scoreFeedTargetGrid:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(168px, 1fr));
    gap: 8px;
  `,scoreFeedTargetCard:g.css`
    min-width: 0;
    min-height: 96px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: 7px;
    padding: 10px;
    border-radius: 12px;
    border: 1px solid ${C?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${C?"linear-gradient(180deg, rgba(15,23,42,0.82) 0%, rgba(8,13,22,0.72) 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,scoreFeedTargetTop:g.css`
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 9px;
  `,scoreFeedTargetIcon:g.css`
    flex: 0 0 auto;
    width: 27px;
    height: 27px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    background: ${C?"rgba(15,23,42,0.92)":"#F8FAFC"};
    border: 1px solid ${C?"rgba(148,163,184,0.16)":"#D7E3F4"};
    font-size: 16px;
    font-weight: 900;
    line-height: 1;

    svg {
      display: block;
      width: 18px;
      height: 18px;
    }
  `,scoreFeedTargetTitle:g.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 12px;
    font-weight: 850;
    color: ${C?"#E2E8F0":"#0F172A"};
  `,scoreFeedTargetStatus:g.css`
    align-self: flex-start;
    min-width: 62px;
    display: inline-flex;
    justify-content: center;
    padding: 5px 10px;
    border-radius: 7px;
    font-size: 11px;
    font-weight: 850;
  `,scoreFeedTargetMeta:g.css`
    font-size: 11px;
    font-weight: 750;
    color: ${C?"#AAB7CA":"#64748B"};
  `,healthChip:g.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: space-between;
    gap: 6px;
    min-height: 68px;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${C?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${C?"linear-gradient(180deg, rgba(15,23,42,0.82) 0%, rgba(8,13,22,0.68) 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,healthChipCompact:g.css`
    min-height: 58px;
    padding: 9px 10px;
  `,healthChipText:g.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  `,healthChipLabel:g.css`
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    color: ${C?"#94A3B8":"#64748B"};
  `,healthChipValue:g.css`
    font-size: 12px;
    font-weight: 800;
    color: ${C?"#E2E8F0":"#0F172A"};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,targetBadge:g.css`
    min-width: 0;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    max-width: 100%;
  `,targetIcon:g.css`
    flex: 0 0 auto;
    width: 28px;
    height: 28px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    background: ${C?"rgba(37,99,235,0.18)":"#EFF6FF"};
    border: 1px solid ${C?"rgba(96,165,250,0.22)":"#BFDBFE"};
    font-size: 15px;
    line-height: 1;

    svg {
      display: block;
      width: 18px;
      height: 18px;
    }
  `,targetText:g.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 1px;
  `,targetName:g.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 12px;
    font-weight: 850;
    color: ${C?"#E2E8F0":"#0F172A"};
  `,targetLanguage:g.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 10px;
    font-weight: 750;
    color: ${C?"#94A3B8":"#64748B"};
  `,labelChipGrid:g.css`
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  `,labelChip:g.css`
    max-width: 100%;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 8px;
    border-radius: 999px;
    border: 1px solid ${C?"rgba(96,165,250,0.24)":"#BFDBFE"};
    background: ${C?"rgba(30,64,175,0.24)":"#EFF6FF"};
    color: ${C?"#DBEAFE":"#1D4ED8"};
    font-size: 11px;
    font-weight: 800;
  `,labelChipKey:g.css`
    opacity: 0.72;
  `,labelChipValue:g.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,staleBanner:g.css`
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 9px 12px;
    border-radius: 14px;
    border: 1px solid ${C?"#92400E":"#FDBA74"};
    background: ${C?"rgba(146,64,14,0.22)":"#FFF7ED"};
    color: ${C?"#FDBA74":"#9A3412"};
    font-size: 12px;
    font-weight: 700;
  `,incidentHeader:g.css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 2px 8px 0;
    flex-wrap: wrap;
  `,severityLegend:g.css`
    display: inline-flex;
    align-items: center;
    gap: 18px;
    flex-wrap: wrap;
    font-size: 12px;
    font-weight: 800;
    color: ${C?"#AAB7CA":"#475569"};
  `,severityLegendItem:g.css`
    display: inline-flex;
    align-items: center;
    gap: 7px;
  `,severityLegendSwatch:g.css`
    width: 10px;
    height: 10px;
    border-radius: 2px;
  `,inlineInspectorLegacy:g.css`
    display: none;
  `,inspectorCard:g.css`
    min-height: 100%;
    border-radius: 16px;
    border: 1px solid ${C?"rgba(148,163,184,0.15)":"#D7E3F4"};
    background: ${C?"linear-gradient(180deg, rgba(15,23,42,0.98), rgba(8,13,22,0.99))":"#FFFFFF"};
    box-shadow: ${C?"0 24px 70px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.045)":"0 18px 34px rgba(15,23,42,0.08)"};
    padding: 18px;
    display: flex;
    flex-direction: column;
    gap: 16px;
  `,inspectorTop:g.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
  `,inspectorTitle:g.css`
    font-size: 20px;
    font-weight: 850;
    letter-spacing: -0.01em;
  `,inspectorClose:g.css`
    width: 28px;
    height: 28px;
    display: grid;
    place-items: center;
    border: 0;
    border-radius: 999px;
    background: transparent;
    color: ${C?"#94A3B8":"#64748B"};
    font-size: 22px;
    cursor: default;
  `,inspectorTimestamp:g.css`
    display: flex;
    align-items: center;
    gap: 8px;
    padding-bottom: 12px;
    border-bottom: 1px solid ${C?"rgba(148,163,184,0.13)":"#E2E8F0"};
    color: ${C?"#D6DEEB":"#334155"};
    font-size: 15px;
    font-weight: 800;
  `,inspectorRows:g.css`
    display: grid;
    gap: 10px;
    padding-bottom: 12px;
    border-bottom: 1px solid ${C?"rgba(148,163,184,0.13)":"#E2E8F0"};
  `,inspectorRow:g.css`
    display: grid;
    grid-template-columns: minmax(110px, 0.72fr) minmax(0, 1fr);
    gap: 12px;
    align-items: baseline;
    font-size: 13px;
  `,inspectorRowLabel:g.css`
    color: ${C?"#94A3B8":"#64748B"};
    font-weight: 750;
  `,inspectorRowValue:g.css`
    min-width: 0;
    color: ${C?"#E2E8F0":"#0F172A"};
    font-weight: 800;
    text-align: right;
    overflow-wrap: anywhere;
  `,inspectorSectionTitle:g.css`
    font-size: 14px;
    font-weight: 850;
    color: ${C?"#EEF2FF":"#0F172A"};
  `,inspectorHealthRow:g.css`
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    gap: 12px;
  `,inspectorPill:g.css`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 5px 9px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 850;
  `,inspectorActionStack:g.css`
    display: grid;
    gap: 8px;
  `,inspectorActionButton:g.css`
    display: inline-flex;
    align-items: center;
    width: 100%;
    min-height: 42px;
    justify-content: center;
    border-radius: 9px;
    font-size: 13px;
    box-shadow: none;
  `,inspectorActionButtonPrimary:g.css`
    border-color: #2563EB;
    background: linear-gradient(180deg, #3B82F6 0%, #2563EB 100%);
    color: #FFFFFF;
  `,inspectorActionButtonSecondary:g.css`
    border-color: ${C?"rgba(148,163,184,0.18)":"#CBD5E1"};
    background: ${C?"rgba(15,23,42,0.72)":"#F8FAFC"};
    color: ${C?"#D6DEEB":"#334155"};
  `,queryPreview:g.css`
    max-height: 170px;
    overflow: auto;
    margin: 0;
    padding: 12px;
    border-radius: 10px;
    border: 1px solid ${C?"rgba(148,163,184,0.14)":"#D7E3F4"};
    background: ${C?"#101820":"#F8FAFC"};
    color: ${C?"#FBBF24":"#92400E"};
    font-family: 'Cascadia Code', Consolas, monospace;
    font-size: 10.5px;
    line-height: 1.5;
    white-space: pre-wrap;
  `,scoreFeedCard:g.css`
    min-width: 0;
    position: relative;
    overflow: hidden;
    &::before {
      content: '';
      position: absolute;
      inset: 0 auto 0 0;
      width: 3px;
      background: ${C?"linear-gradient(180deg, #38BDF8 0%, #2563EB 55%, #22C55E 100%)":"linear-gradient(180deg, #0EA5E9 0%, #2563EB 55%, #16A34A 100%)"};
      opacity: 0.9;
    }
  `,profileCard:g.css`
    gap: 10px;
  `,profileSummary:g.css`
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  `,profileDetailGrid:g.css`
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 8px;
    @media (max-width: 520px) {
      grid-template-columns: 1fr;
    }
  `,handoffCard:g.css`
    padding: 12px;
    gap: 10px;
    background: ${C?"linear-gradient(180deg, rgba(8,13,22,0.88), rgba(6,10,18,0.96))":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,handoffHeader:g.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
  `,detailGrid:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 10px;
  `,detailStat:g.css`
    min-width: 0;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${C?"#1E293B":"#D7E3F4"};
    background: ${C?"#111827":"#F8FAFC"};
  `,detailLabel:g.css`
    font-size: 11px;
    color: ${C?"#94A3B8":"#64748B"};
    text-transform: uppercase;
    letter-spacing: 0.06em;
  `,detailValue:g.css`
    margin-top: 6px;
    font-size: 14px;
    font-weight: 700;
    line-height: 1.4;
    overflow-wrap: anywhere;
  `,detailTable:g.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
  `,metricBreakdownList:g.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,metricBreakdownCard:g.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;
    border-radius: 14px;
    border: 1px solid ${C?"#22314A":"#D7E3F4"};
    background: ${C?"linear-gradient(180deg, #101A2B 0%, #0E1625 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,metricBreakdownHeader:g.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
  `,metricBreakdownTitle:g.css`
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
  `,metricBreakdownReason:g.css`
    margin-top: 4px;
    font-size: 11px;
    line-height: 1.45;
    color: ${C?"#94A3B8":"#64748B"};
  `,metricBreakdownGrid:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(112px, 1fr));
    gap: 8px;
  `,metricBreakdownStat:g.css`
    min-width: 0;
    padding: 8px 10px;
    border-radius: 10px;
    border: 1px solid ${C?"#1E293B":"#E2E8F0"};
    background: ${C?"rgba(2, 6, 23, 0.58)":"rgba(255, 255, 255, 0.82)"};
  `,metricBreakdownStatLabel:g.css`
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: ${C?"#94A3B8":"#64748B"};
  `,metricBreakdownStatValue:g.css`
    margin-top: 5px;
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
    color: ${C?"#F8FAFC":"#0F172A"};
    overflow-wrap: anywhere;
  `,actionRow:g.css`
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    align-items: center;
  `,actionButton:g.css`
    border: 1px solid ${C?"#1D4ED8":"#93C5FD"};
    background: ${C?"#172554":"#EFF6FF"};
    color: ${C?"#DBEAFE":"#1D4ED8"};
    border-radius: 999px;
    padding: 8px 14px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 120ms ease, transform 120ms ease;
    &:hover:enabled {
      transform: translateY(-1px);
    }
    &:disabled {
      cursor: not-allowed;
      opacity: 0.55;
    }
  `,actionButtonSecondary:g.css`
    border: 1px solid ${C?"#334155":"#CBD5E1"};
    background: ${C?"#111827":"#F8FAFC"};
    color: ${C?"#E2E8F0":"#334155"};
    border-radius: 999px;
    padding: 8px 14px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 120ms ease, transform 120ms ease;
    &:hover:enabled {
      transform: translateY(-1px);
    }
    &:disabled {
      cursor: not-allowed;
      opacity: 0.55;
    }
  `,actionNotice:g.css`
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 12px;
    border-radius: 14px;
    border: 1px solid ${C?"#1E293B":"#D7E3F4"};
    background: ${C?"#111827":"#F8FAFC"};
  `,feedRuleList:g.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,wideCard:g.css`
    grid-column: 1 / -1;
  `,feedRuleCard:g.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;
    border-radius: 12px;
    border: 1px solid ${C?"#1E293B":"#D7E3F4"};
    background: ${C?"#111827":"#F8FAFC"};
  `,codeLine:g.css`
    border-radius: 10px;
    border: 1px solid ${C?"#1E293B":"#D7E3F4"};
    background: ${C?"#020617":"#F8FAFC"};
    padding: 10px 12px;
    font-family: 'Cascadia Code', 'Consolas', monospace;
    font-size: 11px;
    line-height: 1.55;
    word-break: break-word;
  `,detailRow:g.css`
    display: grid;
    grid-template-columns: minmax(0, 1.3fr) repeat(4, minmax(0, 1fr));
    gap: 10px;
    align-items: center;
    font-size: 12px;
  `,detailHeaderRow:g.css`
    color: ${C?"#94A3B8":"#64748B"};
    text-transform: uppercase;
    letter-spacing: 0.04em;
    font-size: 11px;
  `,monoBlock:g.css`
    width: 100%;
    min-height: 170px;
    max-height: 320px;
    overflow: auto;
    border-radius: 12px;
    border: 1px solid ${C?"#1E293B":"#D7E3F4"};
    background: ${C?"#020617":"#F8FAFC"};
    padding: 12px;
    box-sizing: border-box;
    font-family: 'Cascadia Code', 'Consolas', monospace;
    font-size: 11px;
    line-height: 1.55;
    white-space: pre-wrap;
    word-break: break-word;
  `,emptyState:g.css`
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 240px;
    border-radius: 16px;
    border: 1px dashed ${C?"#334155":"#CBD5E1"};
    background: ${C?"#020617":"#FFFFFF"};
    color: ${C?"#94A3B8":"#64748B"};
    text-align: center;
    padding: 20px;
    line-height: 1.6;
  `,skeletonShell:g.css`
    display: grid;
    grid-template-rows: auto minmax(240px, 1fr) auto;
    gap: 12px;
  `,skeletonBlock:g.css`
    position: relative;
    overflow: hidden;
    min-height: 20px;
    border-radius: 14px;
    border: 1px solid ${C?"#1E293B":"#D7E3F4"};
    background: ${C?"#111827":"#F8FAFC"};
    &::after {
      content: '';
      position: absolute;
      inset: 0;
      transform: translateX(-100%);
      background: linear-gradient(90deg, transparent, ${C?"rgba(148,163,184,0.12)":"rgba(148,163,184,0.22)"}, transparent);
      animation: anomaly-shimmer 1.45s infinite;
    }
    @keyframes anomaly-shimmer {
      100% {
        transform: translateX(100%);
      }
    }
  `,skeletonHeader:g.css`
    height: 86px;
  `,skeletonChart:g.css`
    min-height: 320px;
  `,skeletonRows:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
  `,skeletonRow:g.css`
    height: 128px;
  `});var C;const A=(0,p.useMemo)(()=>qe(a.series),[a.series]),B=(e=>{const t=String(null!=e?e:"").toLowerCase();return t.includes("loading")||t.includes("streaming")||t.includes("notstarted")})(a.state),[D,T]=(0,p.useState)([]);(0,p.useEffect)(()=>{if(0===A.length||"undefined"==typeof window)return;const e=window.setTimeout(()=>{T(A)},0);return()=>window.clearTimeout(e)},[A]);const P=A.length>0?A:B?D:A,_=B&&0===A.length&&D.length>0,R=B&&0===P.length,V=(0,p.useMemo)(()=>P.map(e=>e.label),[P]),O=(0,p.useMemo)(()=>Me(t,V),[t,V]),I=(0,p.useMemo)(()=>Ie(t),[t]),q=t.title||"Anomaly detector",W=Ft(),[z,H]=(0,p.useState)(null),Q=(0,p.useMemo)(()=>{var e,t;return Lt(null!==(e=null===(t=a.request)||void 0===t?void 0:t.targets)&&void 0!==e?e:[])},[a]);(0,p.useEffect)(()=>{let t=!1;return W?(Dt(null!=e?e:0,q).then(e=>{t||H(e)}).catch(()=>{t||H(null)}),()=>{t=!0}):()=>{t=!0}},[W,e,q]);const{analyses:Y,effectiveBucketSpanMs:K}=(0,p.useMemo)(()=>We(P,O),[P,O]),J=(0,p.useMemo)(()=>"multi"===O.detectionMode?((e,t)=>{const a=new Map;return e.forEach(e=>{e.allPoints.forEach(t=>{var r;if(null===t.expected)return;const n=null!==(r=a.get(t.time))&&void 0!==r?r:[];n.push({point:t,label:e.label}),a.set(t.time,n)})}),[...a.entries()].map(([e,a])=>{var r,n;const i=[...a].sort((e,t)=>t.point.score-e.point.score),l=i.slice(0,Math.min(3,i.length)).reduce((e,t)=>e+t.point.score,0)/Math.min(3,i.length||1),s=i.reduce((e,t)=>Ae(e,t.point),{severityLabel:"normal",severityScore:0}),o=i[0],c=i.slice(0,Math.min(3,i.length)).reduce((e,t)=>e+t.point.confidenceScore,0)/Math.min(3,i.length||1),d=c>=80?"high":c>=55?"medium":"low",m=i.reduce((e,t)=>((e,t)=>{const a=["healthy","gappy","thin","flatline"];return a.indexOf(t)>a.indexOf(e)?t:e})(e,t.point.dataQualityLabel),"healthy");return{time:e,bucketStart:null!==(r=null==o?void 0:o.point.bucketStart)&&void 0!==r?r:e,bucketEnd:null!==(n=null==o?void 0:o.point.bucketEnd)&&void 0!==n?n:e,score:l,contributors:i.filter(e=>e.point.isAnomaly).map(e=>e.label).slice(0,4),activeSeries:a.length,isAnomaly:l>=t.sensitivity||i.some(e=>e.point.isAnomaly),severityLabel:s.severityLabel,severityScore:s.severityScore,confidenceScore:Math.round(10*c)/10,confidenceLabel:d,dataQualityLabel:m}}).sort((e,t)=>e.time-t.time)})(Y,O):[],[Y,O]),ee=(0,p.useMemo)(()=>{var e,t,a,r,n,l;const s=null!==(e=null==i||null===(r=i.from)||void 0===r||null===(a=r.valueOf)||void 0===a?void 0:a.call(r))&&void 0!==e?e:0,o=null!==(t=null==i||null===(l=i.to)||void 0===l||null===(n=l.valueOf)||void 0===n?void 0:n.call(l))&&void 0!==t?t:0;return s>0&&o>s?Math.max(60,Math.round((o-s)/1e3)):0},[i]),te=(0,p.useMemo)(()=>{var e;const t=a.request,r=Number(null!==(e=null==t?void 0:t.intervalMs)&&void 0!==e?e:0);return Number.isFinite(r)&&r>0?Math.max(1,Math.round(r/1e3)):0},[a]),ae=Ot({panelId:null!=e?e:0,panelTitle:q,options:t,resolvedOptions:O,liveTargets:Q,analyses:Y,timeRangeSeconds:ee,queryStepSeconds:te}),re=(0,p.useMemo)(()=>I.anomalyFeed?Ye(Y,J,O):[],[Y,J,O,I.anomalyFeed]),[me,ue]=(0,p.useState)(null),[we,Fe]=(0,p.useState)(null),[$e,Ce]=(0,p.useState)(null),[Te,Pe]=(0,p.useState)(null),[_e,Re]=(0,p.useState)(!1),[Ve,Oe]=(0,p.useState)(!1),et=(0,p.useRef)(null),[at,it]=(0,p.useState)({width:0,height:0}),ct=(0,p.useMemo)(()=>{var e,t;return((e,t,a)=>!!e&&("event"===e.kind?a.some(t=>t.time===e.time):t.some(t=>t.key===e.seriesKey&&t.allPoints.some(t=>t.time===e.time))))(me,Y,J)?me:null!==(e=null===(t=re[0])||void 0===t?void 0:t.selection)&&void 0!==e?e:null},[Y,J,me,re]),ut=(0,p.useMemo)(()=>[...re].sort((e,t)=>e.time-t.time),[re]),ht=Le(ct);(0,p.useLayoutEffect)(()=>{const e=et.current;if(!e)return;let t=0;const a=()=>{"undefined"!=typeof window&&(window.cancelAnimationFrame(t),t=window.requestAnimationFrame(()=>{const t={width:Math.round(e.clientWidth),height:Math.round(e.clientHeight)};it(e=>e.width===t.width&&e.height===t.height?e:t)}))};a();let r=null;return"undefined"!=typeof ResizeObserver?(r=new ResizeObserver(()=>{a()}),r.observe(e)):"undefined"!=typeof window&&window.addEventListener("resize",a),()=>{"undefined"!=typeof window&&(window.cancelAnimationFrame(t),window.removeEventListener("resize",a)),null==r||r.disconnect()}},[r,n,I.inspector,I.mainChart]),(0,p.useEffect)(()=>{if(!Te||"undefined"==typeof window)return;const e=window.setTimeout(()=>{Pe(null)},3200);return()=>{window.clearTimeout(e)}},[Te]);const yt=e=>{e&&(ue(e.selection),Ce(e.time),Fe(e.time))},xt=(0,p.useMemo)(()=>{var e,t;const a=Ke(ct,Y,J);if(a)return a;const r=null!==(e=null!==(t=re.find(e=>Le(e.selection)===ht))&&void 0!==t?t:re[0])&&void 0!==e?e:null;return(n=r)?{kind:"point",title:n.title,subtitle:n.subtitle,seriesKey:Le(n.selection),seriesLabel:n.title,color:se[n.severityLabel],time:n.time,bucketStart:n.time,bucketEnd:n.time+1,actual:n.score,expected:null,deviation:null,deviationPercent:null,rangeLower:null,rangeUpper:null,sampleCount:1,minValue:n.score,maxValue:n.score,score:n.score,pointScore:n.score,windowScore:0,scoreDriver:"point",severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel}:null;var n},[ct,ht,Y,J,re]),Et=(0,p.useMemo)(()=>Y.flatMap(e=>e.allPoints),[Y]),kt=null!=$e?$e:we,St=(0,p.useMemo)(()=>((e,t,a)=>{var r;if(null===e)return null;const n=t.map(t=>{const a=t.allPoints.find(t=>t.time===e);return a?{key:t.key,label:t.label,color:t.color,actual:a.value,expected:a.expected,score:a.score,isAnomaly:a.isAnomaly,severityLabel:a.severityLabel,severityScore:a.severityScore,confidenceScore:a.confidenceScore,confidenceLabel:a.confidenceLabel,dataQualityLabel:a.dataQualityLabel}:null}).filter(e=>null!==e).sort((e,t)=>t.score-e.score);if(0===n.length)return null;const i=null!==(r=a.find(t=>t.time===e))&&void 0!==r?r:null,l=i?{severityLabel:i.severityLabel,severityScore:i.severityScore}:n.reduce((e,t)=>Ae(e,t),{severityLabel:"normal",severityScore:0});return{time:e,event:i,series:n,anomalyCount:n.filter(e=>e.isAnomaly).length+((null==i?void 0:i.isAnomaly)?1:0),severityLabel:l.severityLabel,severityScore:l.severityScore}})(kt,Y,J),[kt,Y,J]),Mt=((e,t)=>{switch(e){case"synced":return t?"#34D399":"#047857";case"syncing":return t?"#FBBF24":"#B45309";case"error":return t?"#F87171":"#B91C1C";case"unsupported":return t?"#F59E0B":"#B45309";case"off":return t?"#94A3B8":"#64748B";default:return t?"#60A5FA":"#1D4ED8"}})(ae.kind,M.isDark),Ct=nt(ae.registered),At=lt(null!==(s=null===(v=ae.registered[0])||void 0===v?void 0:v.target)&&void 0!==s?s:t.scoreFeedTarget),Bt="error"===ae.kind?"Error":"syncing"===ae.kind?"Syncing":"synced"===ae.kind?"Up":"Ready",Tt="Up"===Bt?"#22C55E":"Syncing"===Bt?"#60A5FA":"Error"===Bt?"#EF4444":"#F59E0B",Pt="Up"===Bt?(_t=ae.lastSyncedAt)?new Date(_t).toLocaleString():"Not synced yet":"Syncing"===Bt?"Publishing":"Error"===Bt?"Check exporter":"Selected target";var _t;const Rt="synced"===ae.kind?`${vt(At)} healthy`:Vt(ae.kind),It="off"!==t.scoreFeedMode?h().createElement("div",{className:`${L.card} ${L.scoreFeedCard}`},h().createElement("div",{style:{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12,flexWrap:"wrap"}},h().createElement("div",{style:{minWidth:0,flex:"1 1 320px"}},h().createElement("div",{className:L.cardTitle},"Anomaly score feed"),h().createElement("div",{className:L.subtitle},ae.message)),h().createElement("div",{style:{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}},h().createElement("span",{className:L.recommendationBadge,style:{background:`${Mt}22`,color:Mt}},Rt),h().createElement("button",{type:"button",onClick:()=>{ae.syncNow()},disabled:"syncing"===ae.kind,style:{border:"1px solid "+(M.isDark?"#1D4ED8":"#93C5FD"),background:M.isDark?"#172554":"#EFF6FF",color:M.isDark?"#DBEAFE":"#1D4ED8",borderRadius:999,padding:"8px 14px",fontSize:12,fontWeight:700,cursor:"syncing"===ae.kind?"wait":"pointer",opacity:"syncing"===ae.kind?.72:1}},"syncing"===ae.kind?"Syncing...":"Sync score feed"))),h().createElement("div",{className:L.scoreFeedTargetGrid,"aria-label":"Score feed target health"},h().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},h().createElement("span",{"aria-hidden":"true",style:{width:10,height:10,borderRadius:999,background:Tt,boxShadow:`0 0 0 4px ${Tt}1f`}}),h().createElement("div",{className:L.healthChipText},h().createElement("span",{className:L.healthChipLabel},"Status"),h().createElement("span",{className:L.healthChipValue},Vt(ae.kind)))),h().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},h().createElement("div",{className:L.healthChipText},h().createElement("span",{className:L.healthChipLabel},"Mode"),h().createElement("span",{className:L.healthChipValue},gt[null!==(o=t.scoreFeedMode)&&void 0!==o?o:"auto"]))),h().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},h().createElement("div",{className:L.scoreFeedTargetTop},h().createElement("span",{className:L.scoreFeedTargetIcon,style:{color:(qt=At,bt[lt(qt)])}},wt(At)),h().createElement("div",{className:L.healthChipText},h().createElement("span",{className:L.scoreFeedTargetTitle},vt(At)),h().createElement("span",{className:L.scoreFeedTargetMeta},"Score target")))),h().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},h().createElement("div",{className:L.healthChipText},h().createElement("span",{className:L.healthChipLabel},"Last sync"),h().createElement("span",{className:L.healthChipValue},Pt))),h().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},h().createElement("div",{className:L.healthChipText},h().createElement("span",{className:L.healthChipLabel},"Feed series"),h().createElement("span",{className:L.healthChipValue},ae.registered.length>0?ae.registered.length:"Waiting")))),ae.registered.length>0?h().createElement(h().Fragment,null,h().createElement("div",{className:L.subtitle},"Published score feed records are ready for alerting from the selected target. Queries below match the store selected in Score feed target."),h().createElement("div",{className:L.actionRow},h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>Re(e=>!e)},_e?"Hide synced rules":"Show synced rules")),_e?h().createElement("div",{className:L.feedRuleList},ae.registered.map(e=>{var t,a,r;return h().createElement("div",{key:e.rule,className:L.feedRuleCard},h().createElement("div",{className:L.handoffHeader},h().createElement("div",{style:{minWidth:0,flex:"1 1 180px"}},h().createElement("div",{className:L.summaryTitle},e.rule),h().createElement("div",{className:L.subtitle},"Alert rule query")),h().createElement("span",{className:L.targetBadge,title:st(e)},h().createElement("span",{className:L.targetIcon},wt(null!==(t=e.target)&&void 0!==t?t:"prometheus")),h().createElement("span",{className:L.targetText},h().createElement("span",{className:L.targetName},vt(null!==(a=e.target)&&void 0!==a?a:"prometheus")),h().createElement("span",{className:L.targetLanguage},null!==(r=e.queryLanguage)&&void 0!==r?r:Ct)))),h().createElement("div",{className:L.codeLine},e.query),h().createElement("div",{className:L.subtitle},"Per-series drilldown query"),h().createElement("div",{className:L.codeLine},e.perSeriesQuery),e.queryVariants&&e.queryVariants.length>0?h().createElement("div",{className:L.feedRuleList},e.queryVariants.map(t=>h().createElement("div",{key:`${e.rule}-${t.target}-${t.queryLanguage}`,className:L.feedRuleCard},h().createElement("div",{className:L.handoffHeader},h().createElement("div",{className:L.subtitle},"Variant query"),h().createElement("span",{className:L.targetBadge,title:st(t)},h().createElement("span",{className:L.targetIcon},wt(t.target)),h().createElement("span",{className:L.targetText},h().createElement("span",{className:L.targetName},vt(t.target)),h().createElement("span",{className:L.targetLanguage},t.queryLanguage)))),h().createElement("div",{className:L.codeLine},t.query),h().createElement("div",{className:L.codeLine},t.perSeriesQuery),h().createElement("div",{className:L.actionRow},h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{mt(t.query).then(()=>Pe({tone:"success",message:`Copied ${st(t)} query for ${e.rule}.`})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to copy the target query."}))}},"Copy variant query"))))):null,h().createElement("div",{className:L.actionRow},h().createElement("button",{type:"button",className:L.actionButton,onClick:()=>{mt(e.query).then(()=>Pe({tone:"success",message:`Copied alert query for ${e.rule}.`})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."}))}},"Copy alert query"),h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{mt(e.perSeriesQuery).then(()=>Pe({tone:"success",message:`Copied per-series query for ${e.rule}.`})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to copy the per-series query."}))}},"Copy series query")))})):null):null):null;var qt;if(R)return h().createElement("div",{className:L.wrapper},h().createElement("div",{className:L.skeletonShell,"aria-label":"Anomaly detector is loading"},h().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonHeader}`}),h().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonChart}`}),h().createElement("div",{className:L.skeletonRows},h().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonRow}`}),h().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonRow}`}),h().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonRow}`}))));if(0===P.length||0===Et.length)return h().createElement("div",{className:L.wrapper},I.scoreFeed?It:null,h().createElement("div",{className:L.emptyState},"Add a time series query with at least one numeric field to start anomaly analysis."));const Wt=Y.length,zt="multi"===O.detectionMode?J.filter(e=>e.isAnomaly).length:Y.reduce((e,t)=>e+t.anomalyCount,0),jt="multi"===O.detectionMode?J.map(e=>e.severityScore):Y.map(e=>e.maxSeverityScore),Ut=Math.max(...jt,0),Ht=Y.reduce((e,t)=>Ae(e,{severityLabel:t.maxSeverityLabel,severityScore:t.maxSeverityScore}),{severityLabel:"normal",severityScore:0}),Qt=Et.map(e=>e.time),Gt=[...new Set(Qt)].sort((e,t)=>e-t),Yt=Et.flatMap(e=>[e.value,e.expected,e.lower,e.upper]).filter(e=>null!==e&&Number.isFinite(e)),Kt=Math.min(...Qt),Zt=Math.max(...Qt),Jt=Math.max(Zt-Kt,1),Xt=Math.max((null!==(d=null===(w=i.to)||void 0===w||null===(x=w.valueOf)||void 0===x?void 0:x.call(w))&&void 0!==d?d:Zt)-(null!==(m=null===(k=i.from)||void 0===k||null===(E=k.valueOf)||void 0===E?void 0:E.call(k))&&void 0!==m?m:Kt),1),ea=Math.max(Jt,Xt),ta=((e,t)=>{const a=e.filter(Number.isFinite),r=t.filter(Number.isFinite);if(0===a.length)return{min:0,max:1};const n=Math.min(...a),i=Math.max(...a),l=Math.max(.12*(i-n),.03*Math.abs(i),1);return{min:r.length>0&&r.every(e=>e>=0)?Math.max(0,n-l):n-l,max:i+l}})(Yt,Et.map(e=>e.value).filter(Number.isFinite)),aa=ta.min,ra=ta.max,na=(0,c.timeZoneAbbrevation)(Zt,{timeZone:l})||("string"==typeof l?l:"local"),ia=se[Ht.severityLabel],la=I.initialLabels||I.statistics,sa=I.detectionProfile||I.exports,oa=I.anomalyFeed||sa,ca=I.seriesSummary||I.scoreFeed&&Boolean(It),da=Math.max(r-24,320),ma=Math.max(Math.min(oa?.54*n:n-72,500),340),ua=at.width>0?Math.max(at.width,260):da,pa=at.height>0?Math.max(at.height,220):ma,ha=U(j({},G),{top:pa<280?18:24,right:"multi"===O.detectionMode?28:24,bottom:pa<280?42:54,left:"multi"===O.detectionMode?ua<720?80:92:ua<720?72:84}),ga=Math.max(ua-ha.left-ha.right,40),fa=Math.max(pa-ha.top-ha.bottom,40),ya=e=>Zt===Kt?ha.left+ga/2:ha.left+(e-Kt)/(Zt-Kt)*ga,ba=e=>ra===aa?ha.top+fa/2:ha.top+fa-(e-aa)/(ra-aa)*fa,va=((e,t,a,r)=>{const n=xe(a,r),i="multi"===t?e/235:e/205,l="compact"===n?.76:"dense"===n?1.35:1,s=Math.round(i*l),o="dense"===n?5:4,c="dense"===n?10:"compact"===n?7:8;return Math.max(o,Math.min(c,s))})(ua,O.detectionMode,O.timeAxisDensity,ea),xa=Math.max(5,Math.min(6,Math.round(fa/72))),wa=Ue(Kt,Zt,va),Ea="top_and_bottom"===O.timeAxisPlacement?wa.filter((e,t)=>0===t||t===wa.length-1||t%Math.max(1,Math.ceil(wa.length/3))===0):[],ka=Ue(aa,ra,xa),Sa=Math.max(64,ga/10),Fa="multi"===O.detectionMode?Ge(He(J.filter(e=>e.isAnomaly),ya,Sa,"event"===(null==ct?void 0:ct.kind)?ct.time:null),8,"event"===(null==ct?void 0:ct.kind)?ct.time:null):[],Na=O.showFocusBand?((e,t,a)=>{if(!e||a.length<2)return null;const r=Qe(a,e.time);if(r<0)return null;const n=Math.max(3,Math.min(5,Math.floor(a.length/10)||3)),i=Math.max(0,r-n),l=Math.min(a.length-1,r+n),s=a[i],o=a[l];if(o<=s)return null;const c=t.map(e=>({key:e.key,label:e.label,color:e.color,points:e.allPoints.filter(e=>e.time>=s&&e.time<=o)})).filter(e=>e.points.length>0);if(0===c.length)return null;const d=c.flatMap(e=>e.points.flatMap(e=>[e.value,e.expected].filter(e=>null!==e&&Number.isFinite(e))));return 0===d.length?null:{startTime:s,endTime:o,selectedTime:e.time,bucketStart:e.bucketStart,bucketEnd:e.bucketEnd,title:"event"===e.kind?"Focused incident window":`Focused view for ${e.seriesLabel}`,series:c,minValue:Math.min(...d),maxValue:Math.max(...d)}})(xt,Y,Gt):null,$a=((e,t,a,r)=>{const n=r.length>=2?pe(r.slice(1).map((e,t)=>Math.max(e-r[t],1))):6e4,i=Math.max(1.25*n,3e4),l="multi"===a?t.filter(e=>e.isAnomaly).map(e=>({start:e.bucketStart,end:Math.max(e.bucketEnd,e.time),center:e.time,severityLabel:e.severityLabel,severityScore:e.severityScore,selection:{kind:"event",time:e.time}})):e.flatMap(e=>e.allPoints.filter(e=>e.isAnomaly).map(t=>({start:t.bucketStart,end:Math.max(t.bucketEnd,t.time),center:t.time,severityLabel:t.severityLabel,severityScore:t.severityScore,selection:{kind:"point",seriesKey:e.key,time:t.time}})));if(0===l.length)return[];l.sort((e,t)=>e.start-t.start);const s=[];let o=[l[0]];const c=()=>{if(0===o.length)return;const e=o.reduce((e,t)=>Ae(e,t)===e?e:t,o[0]),t=Math.min(...o.map(e=>e.start)),a=Math.max(...o.map(e=>e.end));s.push({key:`ribbon-${t}-${a}-${s.length}`,start:t,end:a,center:e.center,count:o.length,label:1===o.length?"1 incident":`${o.length} incidents`,severityLabel:e.severityLabel,severityScore:e.severityScore,selection:e.selection}),o=[]};for(let e=1;e<l.length;e+=1){const t=l[e],a=o[o.length-1];t.start<=a.end+i?o.push(t):(c(),o=[t])}return c(),s})(Y,J,O.detectionMode,Gt),Ma=Na?Math.max(54,Math.min(76,.2*fa)):0,La=Na?ha.top+fa-Ma-10:ha.top+fa,Ca=Na?La-8:ha.top+fa,Aa=Y.length>8,Ba=Aa?[]:Y.length>4?[...Y].sort((e,t)=>t.maxSeverityScore-e.maxSeverityScore||t.anomalyCount-e.anomalyCount||e.label.localeCompare(t.label)).slice(0,4):Y,Da=O.showInlineSeriesLabels&&!Aa?((e,t,a,r,n,i)=>{const l=e.map(e=>{const r=[...e.points].reverse().find(e=>Number.isFinite(e.value));if(!r)return null;const n=ve(`${e.label} • ${he(r.value)}`,28);return{key:e.key,label:n,color:e.color,targetY:a(r.value),labelY:a(r.value),anchorX:i,lastX:t(r.time),lastY:a(r.value),width:Math.max(84,Math.min(168,6.6*n.length+18)),value:r.value}}).filter(e=>null!==e).sort((e,t)=>e.targetY-t.targetY);if(0===l.length)return[];let s=r+14;for(const e of l)e.labelY=Math.max(e.targetY,s),s=e.labelY+20;s=n-12;for(let e=l.length-1;e>=0;e-=1){const t=l[e];t.labelY=Math.min(t.labelY,s),s=t.labelY-20}return l.map(e=>U(j({},e),{labelY:Math.max(r+14,Math.min(n-12,e.labelY))}))})(Ba,ya,ba,ha.top+12,Ca-10,ua-ha.right-10):[],Ta=ze(O.bucketSpan,K),Pa=((e,t)=>{const a=ze(e.bucketSpan,t),r=t?`Dense data is first summarized into ${a} buckets so the panel stays fast.`:"Incoming samples are scored directly for maximum detail.";return`${"custom"===e.effectiveMetricPreset?"Custom profile is active.":`${X[e.effectiveMetricPreset]} profile is active.`} ${"level_shift"===e.algorithm?`It focuses on sustained baseline shifts over the last ${e.baselineWindow} buckets.`:"seasonal"===e.algorithm?`It compares each point with similar historical positions using ${ne[e.seasonalRefinement].toLowerCase()} refinement and ${e.seasonalitySamples} seasonal samples.`:"ewma"===e.algorithm?`It keeps a moving baseline over ${e.baselineWindow} buckets and reacts when the live metric keeps pulling away from that baseline.`:"mad"===e.algorithm?`It uses a robust median-based spread over ${e.baselineWindow} buckets so noisy data does not create too many false alarms.`:`It compares each point with a rolling average over ${e.baselineWindow} buckets.`} Current threshold is ${e.sensitivity.toFixed(2)}. ${r}`})(O,K),_a=xt?((e,t)=>{const a=oe[e.confidenceLabel].replace("confidence","signal confidence"),r=de[e.dataQualityLabel].toLowerCase();if("event"===e.kind)return`${e.activeSeries} metric agreed on this combined anomaly. Strongest reason: ${e.breakdown[0]?Be(e.breakdown[0].scoreDriver,t):"Cross-metric deviation"}. ${a}, data quality is ${r}.`;const n=Be(e.scoreDriver,t),i=null===e.deviation?"moved away from baseline":e.deviation>0?"moved above its baseline":e.deviation<0?"fell below its baseline":"stayed close to its baseline";return`${e.seriesLabel} ${i}. Main reason: ${n}. ${a}, data quality is ${r}.`})(xt,O.algorithm):"",Ra=((e,t)=>JSON.stringify(e.map(e=>({time:e.time,text:e.title,tags:Ze(["anomaly-detector",e.severityLabel,e.confidenceLabel,e.dataQualityLabel,t]),detail:e.detail,raw_score:e.score,alarm_score_0_100:e.severityScore,alarm_severity:e.severityLabel,confidence_score:e.confidenceScore,confidence_label:e.confidenceLabel,data_quality:e.dataQualityLabel})),null,2))(re,Ta),Va=rt(ae.registered),Oa=Je(O.severityPreset),Ia=(null==z?void 0:z.folderTitle)||$t(),qa=(null==z?void 0:z.panelTitle)||q,Wa=(null==z?void 0:z.dashboardTitle)||Nt()||"Grafana dashboard",za=lt(null!==(u=null===(S=ae.registered[0])||void 0===S?void 0:S.target)&&void 0!==u?u:t.scoreFeedTarget),ja=((e,t,a)=>{const r=e.trim();let n=t.trim();return r&&n.toLowerCase().endsWith(` - ${r}`.toLowerCase())&&(n=n.slice(0,n.length-r.length-3).trim()),[r,n,a.trim()].filter((e,t,a)=>e.length>0&&a.findIndex(t=>t===e)===t).join(" - ")})(Ia,Wa,qa)||qa,Ua=((e,t,a)=>({alert_family:"anomaly_detector",severity:"major",dashboard_uid:e||"unsaved_dashboard",panel_id:t>0?String(t):"unknown_panel",score_target:lt(a)}))(W,null!=e?e:0,za),Ha=(Ga={dashboardUid:W,folderTitle:Ia,dashboardTitle:Wa,panelId:null!=e?e:0,panelTitle:qa,ruleName:ja},{summary:(Qa=xt)?Qa.title:Ga.ruleName,description:ot(Qa,Ga.panelTitle),folder_title:null!==(Ya=Ga.folderTitle)&&void 0!==Ya?Ya:"",dashboard_title:Ga.dashboardTitle,panel_title:Ga.panelTitle,__dashboardUid__:Ga.dashboardUid,__panelId__:Ga.panelId>0?String(Ga.panelId):""});var Qa,Ga,Ya;const Ka={dashboardUid:W,folderTitle:Ia,dashboardTitle:Wa,panelId:null!=e?e:0,panelTitle:qa,ruleName:ja,queryLanguage:Ct,alertQuery:Va,threshold:Oa,target:za,labels:Ua,annotations:Ha},Za=Xe(Ua),Ja=((e,t,a,r,n)=>{var i;const l=Je(t.severityPreset),s=rt(r),o=nt(r);return JSON.stringify({title:n.ruleName,folder_name:null!==(i=n.folderTitle)&&void 0!==i?i:"",dashboard_name:n.dashboardTitle,dashboard_uid:n.dashboardUid,panel_title:n.panelTitle,panel_id:n.panelId,score_feed_ready:r.length>0,paste_into:`Grafana Alerting query editor (${o})`,query_language:o,alert_query:s||"Sync anomaly score feed first to generate an alert-ready score query.",grafana_condition:s?`WHEN QUERY IS ABOVE ${l}`:"Sync anomaly score feed first",for:"10m",evaluate_every:"3m",no_data_state:"Alerting",exec_err_state:"Error",threshold:l,suggested_labels:n.labels,suggested_label_pairs:Xe(n.labels),suggested_annotations:n.annotations,synced_rules:r.map(e=>{var t,a,r,n;return{rule:e.rule,target:null!==(t=e.target)&&void 0!==t?t:"prometheus",query_language:null!==(a=e.queryLanguage)&&void 0!==a?a:o,datasource_type:null!==(r=e.datasourceType)&&void 0!==r?r:"",query:e.query,per_series_query:e.perSeriesQuery,query_variants:null!==(n=e.queryVariants)&&void 0!==n?n:[]}}),rule_scope:r.length>1?"Combined max across synced panel rules":"Single synced panel rule",mode:t.detectionMode,algorithm:t.algorithm,bucket_span:a,history_window:t.baselineWindow,severity_preset:t.severityPreset,selected_severity:e?e.severityLabel:"normal",selected_score:e?e.score:0,selected_raw_score:e?e.score:0,selected_alarm_score_0_100:e?e.severityScore:0,selected_alarm_severity:e?e.severityLabel:"normal",score_scale_note:"Alert queries use the normalized 0-100 alarm score, not the raw detection score.",selected_confidence:e?e.confidenceLabel:"low",selected_confidence_score:e?e.confidenceScore:0,selected_data_quality:e?e.dataQualityLabel:"thin",guidance:e?De(e,t.severityPreset):"Select an anomaly to generate a focused alert draft."},null,2)})(xt,O,Ta,ae.registered,Ka),Xa=dt(xt,null!=e?e:0,W,Ta),er=Xa?JSON.stringify(Xa,null,2):"",tr=xt?Math.max(1,re.findIndex(e=>Le(e.selection)===ht)+1):0,ar="point"===(null==xt?void 0:xt.kind)?xt.seriesLabel:"event"===(null==xt?void 0:xt.kind)?xt.contributors.slice(0,2).join(", ")||`${xt.activeSeries} active series`:null!==(y=null===(F=Y[0])||void 0===F?void 0:F.label)&&void 0!==y?y:"n/a",rr="point"===(null==xt?void 0:xt.kind)?he(xt.actual):"event"===(null==xt?void 0:xt.kind)?`${xt.activeSeries} active`:"n/a",nr="point"===(null==xt?void 0:xt.kind)?he(xt.expected):"event"===(null==xt?void 0:xt.kind)?`${xt.breakdown.length} contributors`:"n/a",ir="point"===(null==xt?void 0:xt.kind)?null!==xt.deviationPercent?fe(xt.deviationPercent):he(xt.deviation):"event"===(null==xt?void 0:xt.kind)?he(xt.score):"n/a",lr=xt?he(xt.score):"n/a",sr=xt?`${le[xt.severityLabel]} ${xt.severityScore}`:"n/a",or=xt?oe[xt.confidenceLabel]:"n/a",cr=xt?ge(xt.confidenceScore):"n/a",dr=xt?"healthy"===xt.dataQualityLabel?"Good":de[xt.dataQualityLabel].replace(" data",""):"n/a",mr=xt?ge(xt.confidenceScore):"n/a",ur=(null===(N=Q[0])||void 0===N?void 0:N.datasourceType)?Q[0].datasourceType.charAt(0).toUpperCase()+Q[0].datasourceType.slice(1):ft[lt(t.scoreFeedTarget)],pr=Y.length>8?[...Y].sort((e,t)=>t.anomalyCount-e.anomalyCount||t.maxSeverityScore-e.maxSeverityScore||e.label.localeCompare(t.label)).slice(0,8):Y,hr=Math.max(0,Y.length-pr.length),gr=xt?{x:ya(xt.bucketStart),height:Math.max(24,Ca-ha.top),width:xt.bucketEnd>xt.bucketStart?Math.max(ya(xt.bucketEnd)-ya(xt.bucketStart),10):12}:null,fr=Fa.map(e=>{const t=ya(e.bucketStart),a=(e.bucketEnd>e.bucketStart?ya(e.bucketEnd):t)-t,r=Math.max(10,Math.min(ga/80,20)),n=Math.max(10,Math.min(Number.isFinite(a)&&a>0?a:r,24)),i=a>0?t:ya(e.time)-n/2,l=Math.max(ha.left+2,Math.min(i,ua-ha.right-n-2));return{event:e,x:l,width:n,centerX:l+n/2}}),yr=`anomaly-plot-${null!=e?e:"panel"}-${O.detectionMode}`,br=M.isDark?"#CBD5E1":"#334155",vr=M.isDark?"#0B1628":"#F8FAFC",xr=M.isDark?"#0F1C2D":"#FFFFFF",wr=St?ya(St.time):null,Er=null===wr?0:Math.max(16,Math.min(wr+18,ua-290)),kr=null!==wr&&wr>.62*ua,Sr=null===wr?void 0:{left:kr?void 0:Er,right:kr?Math.max(14,ua-wr+14):void 0},Fr=h().createElement("aside",{className:L.inspectorCard,"aria-label":"Anomaly inspector"},h().createElement("div",{className:L.inspectorTop},h().createElement("div",{className:L.inspectorTitle},"Anomaly inspector"),h().createElement("button",{type:"button",className:L.inspectorClose,"aria-label":"Inspector is pinned in this panel"},"x")),xt?h().createElement(h().Fragment,null,h().createElement("div",{className:L.inspectorTimestamp},h().createElement("span",null,ke(xt.time,ea,l)),h().createElement("span",{"aria-hidden":"true"},"•"),h().createElement("span",{style:{color:se[xt.severityLabel]}},le[xt.severityLabel])),h().createElement("div",{className:L.inspectorRows},h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Series"),h().createElement("span",{className:L.inspectorRowValue},ve(ar,34))),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Value"),h().createElement("span",{className:L.inspectorRowValue},rr)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Expected"),h().createElement("span",{className:L.inspectorRowValue},nr)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Deviation"),h().createElement("span",{className:L.inspectorRowValue},ir)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Raw detection score"),h().createElement("span",{className:L.inspectorRowValue},lr)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Alert score (0-100)"),h().createElement("span",{className:L.inspectorRowValue,style:{color:se[xt.severityLabel]}},sr)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Bucket"),h().createElement("span",{className:L.inspectorRowValue},Ta)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Incident"),h().createElement("span",{className:L.inspectorRowValue},tr," of ",Math.max(re.length,tr)))),h().createElement("div",null,h().createElement("div",{className:L.inspectorSectionTitle},"Why is this anomalous?"),h().createElement("div",{className:L.recommendationText,style:{marginTop:10}},_a)),h().createElement("div",{className:L.inspectorRows},h().createElement("div",{className:L.inspectorHealthRow},h().createElement("span",{className:L.inspectorRowLabel},"Confidence"),h().createElement("span",null,h().createElement("span",{className:L.inspectorPill,style:{background:`${ce[xt.confidenceLabel]}33`,color:ce[xt.confidenceLabel]}},or),h().createElement("span",{className:L.inspectorRowValue,style:{marginLeft:10}},cr,"%"))),h().createElement("div",{className:L.inspectorHealthRow},h().createElement("span",{className:L.inspectorRowLabel},"Data quality"),h().createElement("span",null,h().createElement("span",{className:L.inspectorPill,style:{background:"rgba(34,197,94,0.24)",color:"#86EFAC"}},dr),h().createElement("span",{className:L.inspectorRowValue,style:{marginLeft:10}},mr,"%")))),h().createElement("div",null,h().createElement("div",{className:L.inspectorSectionTitle},"Rule labels"),h().createElement("div",{className:L.labelChipGrid,style:{marginTop:10}},Object.entries(Ua).map(([e,t])=>h().createElement("span",{key:e,className:L.labelChip,title:`${e}=${t}`},h().createElement("span",{className:L.labelChipKey},e),h().createElement("span",null,"="),h().createElement("span",{className:L.labelChipValue},t))))),h().createElement("div",{className:L.inspectorActionStack},h().createElement("button",{type:"button",className:`${L.actionButton} ${L.inspectorActionButton} ${L.inspectorActionButtonPrimary}`,disabled:!Va,onClick:()=>{if(!Va)return void Pe({tone:"error",message:"Sync anomaly score feed first to generate the alert query."});const e=tt(Ka);Pe({tone:"success",message:e?"Opened Grafana alert rule builder. Copying the alert query to your clipboard.":"Copying the alert query. If the builder did not open, use Alerting > Alert rules > New alert rule."}),mt(Va).then(()=>Pe({tone:"success",message:e?"Opened Grafana alert rule builder and copied the alert query.":"Copied the alert query. If the builder did not open, use Alerting > Alert rules > New alert rule."})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."}))}},"Open alert rule builder"),h().createElement("button",{type:"button",className:`${L.actionButtonSecondary} ${L.inspectorActionButton} ${L.inspectorActionButtonSecondary}`,disabled:!Za,onClick:()=>{mt(Za).then(()=>Pe({tone:"success",message:"Copied suggested alert labels."})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to copy alert labels."}))}},"Copy rule labels"),h().createElement("button",{type:"button",className:`${L.actionButtonSecondary} ${L.inspectorActionButton} ${L.inspectorActionButtonSecondary}`,disabled:!Xa||!W,onClick:()=>{Xa?W?pt(Xa).then(()=>Pe({tone:"success",message:"Created a Grafana annotation for the selected anomaly."})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to create the Grafana annotation."})):Pe({tone:"error",message:"Save the dashboard once before creating Grafana annotations from the panel."}):Pe({tone:"error",message:"Select an anomaly first to create an annotation."})}},"Create annotation"),h().createElement("button",{type:"button",className:`${L.actionButtonSecondary} ${L.inspectorActionButton} ${L.inspectorActionButtonSecondary}`,disabled:!Va,onClick:()=>{Va?mt(Va).then(()=>Pe({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):Pe({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy alert query")),h().createElement("div",null,h().createElement("div",{className:L.inspectorSectionTitle},"Query preview"),h().createElement("pre",{className:L.queryPreview},Va||`Sync the score feed to generate ${Ct}.`))):h().createElement("div",{className:L.subtitle},"Select a detected incident to see why it was flagged, how strong the signal is, and whether it is ready for alerting."));return h().createElement("div",{className:L.wrapper},h().createElement("div",{className:L.operationalCanvas,style:{gridTemplateColumns:I.inspector?void 0:"minmax(0, 1fr)"}},h().createElement("main",{className:L.workspacePane},la?h().createElement("div",{className:L.statusHeader,style:{gridTemplateColumns:I.initialLabels&&I.statistics?void 0:"minmax(0, 1fr)"}},I.initialLabels?h().createElement(h().Fragment,null,h().createElement("div",{className:L.statusRail,style:{background:ia}}),h().createElement("div",{className:L.statusIcon,"aria-hidden":"true"},h().createElement("svg",{className:L.statusIconSvg,viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("path",{d:"M2.5 12h4.1l2.1-5.7 3.9 11.4 2.1-5.7h6.8",fill:"none",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"}),h().createElement("circle",{cx:"12",cy:"12",r:"10",fill:"none",stroke:"currentColor",strokeOpacity:"0.28",strokeWidth:"1.4"}))),h().createElement("div",{className:L.statusMain},h().createElement("div",{className:L.title,role:"heading","aria-level":2},"Anomaly Detector"),h().createElement("div",{className:L.headerMetaGrid},h().createElement("span",null,"Algorithm: ",h().createElement("span",{className:L.metaAccent},O.algorithm)),h().createElement("span",null,"Bucket: ",Ta),h().createElement("span",null,"Series: ",ve(ar,34)),h().createElement("span",null,"Datasource: ",ur)),_?h().createElement("div",{className:L.staleBanner},"Showing the last good snapshot while Grafana refreshes the query result."):null)):null,I.statistics?h().createElement("div",{className:L.statusStats},h().createElement("div",{className:`${L.statCard} ${L.statCardPrimary}`},h().createElement("div",{className:L.statLabel},"Severity"),h().createElement("div",{className:L.statValue},le[Ht.severityLabel]),h().createElement("div",{className:L.statCaption},xt?`Since ${ke(xt.time,ea,l)}`:`Peak ${ge(Ut)}`)),h().createElement("div",{className:L.statCard},h().createElement("div",{className:L.statLabel},"Confidence"),h().createElement("div",{className:L.statValue},cr,"%"),h().createElement("div",{className:L.statCaption},or)),h().createElement("div",{className:L.statCard,role:"status","aria-live":"polite","aria-atomic":"true"},h().createElement("div",{className:L.statLabel},"Anomalies"),h().createElement("div",{className:L.statValue},zt),h().createElement("div",{className:L.statCaption},"clustered")),h().createElement("div",{className:L.statCard},h().createElement("div",{className:L.statLabel},"Data quality"),h().createElement("div",{className:L.statValue,style:{color:"#4ADE80"}},dr),h().createElement("div",{className:L.statCaption},mr,"%"))):null):null,I.initialLabels?h().createElement("div",{className:L.recommendationBanner},h().createElement("div",{className:L.recommendationBadge},O.recommendation.badge),h().createElement("div",{className:L.recommendationCopy},h().createElement("div",{className:L.recommendationTitle},O.recommendation.title),h().createElement("div",{className:L.recommendationText},O.recommendation.reason,O.recommendation.matchedNames.length>0?` Matched metrics: ${O.recommendation.matchedNames.slice(0,3).join(", ")}.`:""))):null,Te?h().createElement("div",{className:L.actionNotice},h().createElement("span",{className:L.recommendationBadge,style:{background:"success"===Te.tone?`${se.low}22`:`${se.critical}22`,color:"success"===Te.tone?se.low:se.critical}},"success"===Te.tone?"Action complete":"Action needed"),h().createElement("div",{className:L.recommendationCopy},h().createElement("div",{className:L.recommendationTitle},"success"===Te.tone?"Ready to continue":"Could not finish action"),h().createElement("div",{className:L.recommendationText},Te.message))):null,I.anomalyFeed?h().createElement(h().Fragment,null,h().createElement("div",{className:L.incidentHeader},h().createElement("div",{className:L.cardTitle,role:"heading","aria-level":3},"Detected incidents"),h().createElement("div",{className:L.severityLegend,"aria-label":"Incident severity legend"},["critical","high","medium","low"].map(e=>h().createElement("span",{key:e,className:L.severityLegendItem},h().createElement("span",{className:L.severityLegendSwatch,style:{background:se[e]}}),le[e])))),$a.length>0?h().createElement("div",{className:L.incidentRibbonPanel,"aria-label":"Detected incident overview"},h().createElement("svg",{width:"100%",height:"34",viewBox:`0 0 ${ua} 34`,preserveAspectRatio:"none",role:"img","aria-label":"Detected incident overview"},h().createElement("rect",{x:ha.left,y:11,width:ga,height:12,rx:6,fill:M.isDark?"#252C38":"#E2E8F0",opacity:.88}),$a.map(e=>{const t=Math.max(ha.left,ya(e.start)),a=Math.min(ua-ha.right,ya(e.end)),r=Math.max(8,a-t),n=Le(ct)===Le(e.selection),i=se[e.severityLabel];return h().createElement("g",{key:`overview-${e.key}`,style:{cursor:"pointer"},onClick:()=>{ue(e.selection),Ce(e.center),Fe(e.center)}},h().createElement("title",null,`${e.label} | ${le[e.severityLabel]} ${e.severityScore} | ${ke(e.center,ea,l)}`),h().createElement("rect",{x:t,y:11,width:r,height:12,rx:6,fill:i,fillOpacity:n?1:.82,stroke:n?M.isDark?"#F8FAFC":"#0F172A":"none",strokeWidth:n?1.2:0}),e.count>1&&r>=28?h().createElement("g",null,h().createElement("rect",{x:t+r/2-13,y:2,width:26,height:18,rx:8,fill:i,stroke:M.isDark?"#7F1D1D":"#FFFFFF",strokeWidth:1}),h().createElement("text",{x:t+r/2,y:15,textAnchor:"middle",fill:"#FFFFFF",fontSize:"10",fontWeight:"900",pointerEvents:"none"},"x",e.count)):null)}))):h().createElement("div",{className:L.incidentRibbonPanel,"aria-label":"Detected incident overview"},h().createElement("div",{className:L.incidentRibbonEmpty},"No clustered incidents in this time range."))):null,I.mainChart?h().createElement("div",{className:L.chartCard,ref:et,tabIndex:0,onKeyDown:e=>{if((e=>e instanceof HTMLElement&&(["BUTTON","INPUT","TEXTAREA","SELECT","A"].includes(e.tagName)||e.isContentEditable))(e.target)||0===ut.length)return;const t=ut.findIndex(e=>Le(e.selection)===ht),a=t>=0?t:0;if("ArrowRight"===e.key||"ArrowDown"===e.key){e.preventDefault();const t=ut[(a+1)%ut.length];return void yt(t)}if("ArrowLeft"===e.key||"ArrowUp"===e.key){e.preventDefault();const t=ut[(a-1+ut.length)%ut.length];return void yt(t)}if("Enter"===e.key||" "===e.key){const t=ut[a];if(!t)return;return e.preventDefault(),Ce(e=>e===t.time?null:t.time),void Fe(t.time)}"Escape"===e.key&&(e.preventDefault(),Ce(null),Fe(null))},"aria-label":"Anomaly chart. Use left and right arrows to move between incidents, Enter to pin, and Escape to clear."},h().createElement("svg",{width:"100%",height:"100%",viewBox:`0 0 ${ua} ${pa}`,preserveAspectRatio:"none",role:"img","aria-label":"Anomaly chart",onMouseMove:e=>{const t=e.currentTarget.getBoundingClientRect(),a=(e.clientX-t.left)/t.width*ua;if(a<ha.left||a>ua-ha.right)return void(null===$e&&Fe(null));const r=(e=>{if(Zt===Kt)return Kt;const t=Math.max(0,Math.min(1,(e-ha.left)/ga));return Kt+t*(Zt-Kt)})(a),n=Qe(Gt,r);Fe(n>=0?Gt[n]:null)},onMouseLeave:()=>{null===$e&&Fe(null)},onClick:()=>{St&&Ce(e=>e===St.time?null:St.time)},style:{width:"100%",height:"100%",display:"block",cursor:"crosshair"}},h().createElement("defs",null,h().createElement("clipPath",{id:yr},h().createElement("rect",{x:ha.left,y:ha.top,width:ga,height:fa,rx:12}))),h().createElement("rect",{x:0,y:0,width:ua,height:pa,fill:M.isDark?"#08111F":"#FFFFFF"}),h().createElement("rect",{x:8,y:ha.top-8,width:ha.left-16,height:fa+16,rx:16,fill:vr,opacity:.96}),h().createElement("text",{transform:`translate(22 ${ha.top+fa/2}) rotate(-90)`,textAnchor:"middle",fill:br,fontSize:"11",fontWeight:"700",letterSpacing:"0.08em"},"VALUE"),h().createElement("text",{x:ua-ha.right,y:pa-16,textAnchor:"end",fill:br,fontSize:"11",fontWeight:"700",letterSpacing:"0.08em"},"TIME (",na,")"),Ea.map((e,t)=>{const a=ya(e),r=0===t?"start":t===Ea.length-1?"end":"middle";return h().createElement("g",{key:`top-x-${t}`},h().createElement("text",{x:a,y:ha.top-10,textAnchor:r,fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},((e,t,a)=>t<=2592e5?(0,c.dateTimeFormat)(e,{format:"ddd DD/MM",timeZone:a}):(0,c.dateTimeFormat)(e,{format:"DD/MM/YYYY",timeZone:a}))(e,ea,l)))}),gr?h().createElement("rect",{x:Math.max(ha.left,gr.x),y:ha.top,width:Math.min(gr.width,ga),height:gr.height,fill:M.isDark?"rgba(59,130,246,0.10)":"rgba(37,99,235,0.08)",stroke:M.isDark?"rgba(96,165,250,0.35)":"rgba(37,99,235,0.25)",rx:8}):null,h().createElement("rect",{x:ha.left,y:ha.top,width:ga,height:fa,rx:12,fill:M.isDark?"#06101E":"#FFFFFF",stroke:M.isDark?"#142033":"#E2E8F0"}),ka.map((e,t)=>{const a=ba(e);return h().createElement("g",{key:`y-${t}`},h().createElement("line",{x1:ha.left,y1:a,x2:ua-ha.right,y2:a,stroke:M.isDark?"#1E293B":"#E2E8F0",strokeOpacity:.78,strokeDasharray:"3 6"}),h().createElement("rect",{x:14,y:a-10,width:ha.left-28,height:20,rx:10,fill:xr,opacity:M.isDark?.84:.96}),h().createElement("text",{x:ha.left-18,y:a+4,textAnchor:"end",fill:M.isDark?"#E2E8F0":"#0F172A",fontSize:"12",fontWeight:"700"},(e=>{if(!Number.isFinite(e))return"";const t=Math.abs(e);return t>=1e3?e.toLocaleString(void 0,{notation:"compact",maximumFractionDigits:1}):t>=100?e.toLocaleString(void 0,{maximumFractionDigits:0}):t>=10?e.toLocaleString(void 0,{maximumFractionDigits:1}):t>=1?e.toLocaleString(void 0,{maximumFractionDigits:2}):e.toLocaleString(void 0,{maximumFractionDigits:3})})(e)))}),wa.map((e,t)=>{const a=ya(e),r=0===t?"start":t===wa.length-1?"end":"middle";return h().createElement("g",{key:`x-${t}`},t>0&&t<wa.length-1?h().createElement("line",{x1:a,y1:ha.top,x2:a,y2:pa-ha.bottom,stroke:M.isDark?"#162336":"#E2E8F0",strokeOpacity:.45}):null,h().createElement("text",{x:a,y:pa-12,textAnchor:r,fill:M.isDark?"#94A3B8":"#64748B",fontSize:"11"},Ee(e,ea,O.timeAxisDensity,l)))}),null!==wr?h().createElement("g",{pointerEvents:"none"},h().createElement("line",{x1:wr,y1:ha.top,x2:wr,y2:Ca,stroke:M.isDark?"#93C5FD":"#2563EB",strokeDasharray:"5 5",strokeOpacity:.72,strokeWidth:1.35}),h().createElement("rect",{x:Math.max(ha.left+6,Math.min(wr-52,ua-ha.right-104)),y:ha.top+24,width:104,height:20,rx:10,fill:M.isDark?"#0F172A":"#FFFFFF",stroke:M.isDark?"#334155":"#CBD5E1"}),h().createElement("text",{x:Math.max(ha.left+58,Math.min(wr,ua-ha.right-52)),y:ha.top+38,textAnchor:"middle",fill:M.isDark?"#E2E8F0":"#0F172A",fontSize:"11",fontWeight:"700"},Ee(null!==(b=null==St?void 0:St.time)&&void 0!==b?b:Kt,ea,"dense",l))):null,"multi"===O.detectionMode&&fr.length>0?h().createElement("g",null,fr.map(({event:e,x:t,width:a,centerX:r})=>{const n="event"===(null==ct?void 0:ct.kind)&&ct.time===e.time,i=se[e.severityLabel],l=Se(e.severityLabel,O.markerShapeMode),s="high"===e.confidenceLabel?.18:"medium"===e.confidenceLabel?.12:.08,o=ha.top+18;return h().createElement("g",{key:`event-${e.time}`,style:{cursor:"pointer"},onClick:()=>{ue({kind:"event",time:e.time}),Ce(e.time)}},h().createElement("title",null,`Combined anomaly at ${ye(e.time)} | Score ${he(e.score)} | ${le[e.severityLabel]} | ${oe[e.confidenceLabel]}`),h().createElement("rect",{x:t,y:ha.top+1,width:a,height:fa-2,rx:n?10:8,fill:i,fillOpacity:n?.18:s}),h().createElement("rect",{x:t,y:ha.top+4,width:a,height:4,rx:2,fill:i,fillOpacity:n?.95:"high"===e.confidenceLabel?.8:.62}),h().createElement("rect",{x:t,y:ha.top+fa-6,width:a,height:3,rx:1.5,fill:i,fillOpacity:n?.9:"high"===e.confidenceLabel?.72:.5}),h().createElement("line",{x1:r,y1:o+8,x2:r,y2:Ca-8,stroke:i,strokeOpacity:n?.74:.38,strokeWidth:n?1.8:1.25,strokeDasharray:"4 5"}),Ne(l,r,o,n?7.5:6.2,M.isDark?"#08111F":"#FFFFFF",i,n?2.8:2.2),Ne(l,r,o,n?3:2.5,i))})):null,h().createElement("g",{clipPath:`url(#${yr})`},Y.map(e=>{const a=!1===t.showBands?"":((e,t,a)=>{const r=e.filter(e=>null!==e.lower&&null!==e.upper);if(r.length<2)return"";const n=r.map(e=>`${t(e.time).toFixed(2)},${a(e.upper).toFixed(2)}`),i=[...r].reverse().map(e=>`${t(e.time).toFixed(2)},${a(e.lower).toFixed(2)}`);return`M${n.join(" L")} L${i.join(" L")} Z`})(e.points,ya,ba),r=je(e.points,ya,ba,e=>e.value),n=O.showExpectedLine?je(e.points,ya,ba,e=>e.expected):"",i="point"===(null==ct?void 0:ct.kind)&&ct.seriesKey===e.key?ct.time:null,l=O.markerShapeMode,s=Math.max(54,ga/12),o=Math.max(12,ga/44),c="multi"===O.detectionMode?[]:Ge(He(e.points.filter(e=>e.isAnomaly),ya,Aa?s:o,i),Aa?2:8,i);return h().createElement("g",{key:e.key},a?h().createElement("path",{d:a,fill:e.color,opacity:xt&&"point"===xt.kind&&xt.seriesKey===e.key?.14:.07}):null,n?h().createElement("path",{d:n,fill:"none",stroke:e.color,strokeOpacity:.32,strokeWidth:1.3,strokeDasharray:"6 6"}):null,h().createElement("path",{d:r,fill:"none",stroke:e.color,strokeWidth:2.6,strokeLinecap:"round",strokeLinejoin:"round"}),c.map(t=>{const a="point"===(null==ct?void 0:ct.kind)&&ct.seriesKey===e.key&&ct.time===t.time,r=ya(t.time),n=ba(t.value),i=Se(t.severityLabel,l),s=a?11:"high"===t.confidenceLabel?8.4:"medium"===t.confidenceLabel?7.4:6.2;return h().createElement("g",{key:`${e.key}-${t.time}`,style:{cursor:"pointer"},onClick:()=>{ue({kind:"point",seriesKey:e.key,time:t.time}),Ce(t.time)}},h().createElement("title",null,`${e.label} | ${ye(t.time)} | ${le[t.severityLabel]} | ${oe[t.confidenceLabel]}`),h().createElement("line",{x1:r,y1:ha.top+18,x2:r,y2:Math.max(ha.top+26,n-10),stroke:se[t.severityLabel],strokeOpacity:a?.72:.3,strokeWidth:a?1.7:1.2,strokeDasharray:"4 5"}),h().createElement("circle",{cx:r,cy:n,r:s,fill:ce[t.confidenceLabel],opacity:a?.28:.18}),Ne(i,r,n,a?7.2:5.4,M.isDark?"#111827":"#FFFFFF",se[t.severityLabel],a?2.8:2.4),Ne(i,r,n,a?3.2:2.6,se[t.severityLabel],void 0,0,"high"===t.confidenceLabel?.96:.8),h().createElement("circle",{cx:r,cy:n,r:11,fill:"transparent"}))}))})),Da.map(e=>{const t=Math.max(ha.left+8,e.anchorX-e.width),a=t-8;return h().createElement("g",{key:`inline-${e.key}`},h().createElement("line",{x1:e.lastX,y1:e.lastY,x2:a,y2:e.labelY,stroke:e.color,strokeOpacity:.78,strokeWidth:1.4}),h().createElement("rect",{x:t,y:e.labelY-11,width:e.width,height:22,rx:11,fill:M.isDark?"#0F172A":"#FFFFFF",stroke:e.color,strokeOpacity:.48}),h().createElement("circle",{cx:t+11,cy:e.labelY,r:3,fill:e.color}),h().createElement("text",{x:t+19,y:e.labelY+4,fill:M.isDark?"#E2E8F0":"#0F172A",fontSize:"11",fontWeight:"700"},e.label))}),Na?(()=>{const e=ha.left+14,t=Math.max(ga-28,48),a=La,r=Math.max(Ma-28,18),n=Na.minValue,i=Na.maxValue,s=Math.max(i-n,1e-6),o=a=>e+(a-Na.startTime)/Math.max(Na.endTime-Na.startTime,1)*t,c=e=>a+18+r-(e-n)/s*r,d=o(Na.bucketStart),m=o(Math.max(Na.bucketEnd,Na.selectedTime));return h().createElement("g",null,h().createElement("rect",{x:ha.left+6,y:a,width:ga-12,height:Ma,rx:14,fill:M.isDark?"rgba(8,17,31,0.92)":"rgba(255,255,255,0.94)",stroke:M.isDark?"#1E293B":"#D7E3F4"}),h().createElement("text",{x:e,y:a+14,fill:M.isDark?"#CBD5E1":"#334155",fontSize:"10",fontWeight:"700",letterSpacing:"0.08em"},"FOCUSED ANOMALY WINDOW"),h().createElement("text",{x:ua-ha.right-8,y:a+14,textAnchor:"end",fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},Na.title),h().createElement("rect",{x:Math.min(d,m),y:a+18,width:Math.max(Math.abs(m-d),8),height:r,rx:8,fill:M.isDark?"rgba(59,130,246,0.14)":"rgba(37,99,235,0.10)",stroke:M.isDark?"rgba(96,165,250,0.28)":"rgba(37,99,235,0.22)"}),Na.series.map(e=>{const t=je(e.points,o,c,e=>e.value);return h().createElement("path",{key:`focus-${e.key}`,d:t,fill:"none",stroke:e.color,strokeWidth:1.8,strokeOpacity:"point"===(null==ct?void 0:ct.kind)&&ct.seriesKey===e.key?1:.78,strokeLinecap:"round",strokeLinejoin:"round"})}),h().createElement("line",{x1:o(Na.selectedTime),y1:a+18,x2:o(Na.selectedTime),y2:a+18+r,stroke:M.isDark?"#93C5FD":"#2563EB",strokeDasharray:"4 4",strokeWidth:1.4}),h().createElement("text",{x:e,y:a+Ma-8,fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10"},Ee(Na.startTime,Na.endTime-Na.startTime,"dense",l)),h().createElement("text",{x:o(Na.selectedTime),y:a+Ma-8,textAnchor:"middle",fill:M.isDark?"#E2E8F0":"#0F172A",fontSize:"10",fontWeight:"700"},Ee(Na.selectedTime,Na.endTime-Na.startTime,"dense",l)),h().createElement("text",{x:ua-ha.right-8,y:a+Ma-8,textAnchor:"end",fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10"},Ee(Na.endTime,Na.endTime-Na.startTime,"dense",l)))})():null,h().createElement("rect",{x:ha.left,y:ha.top,width:ga,height:fa,rx:12,fill:"none",stroke:M.isDark?"#22314A":"#D7E3F4"})),St?h().createElement("div",{style:U(j({position:"absolute",top:18},null!=Sr?Sr:{}),{width:272,pointerEvents:null!==$e?"auto":"none",borderRadius:16,border:"1px solid "+(M.isDark?"#334155":"#CBD5E1"),background:M.isDark?"rgba(8,17,31,0.96)":"rgba(255,255,255,0.96)",boxShadow:M.isDark?"0 18px 42px rgba(2,6,23,0.42)":"0 18px 42px rgba(15,23,42,0.12)",padding:"12px 14px",display:"flex",flexDirection:"column",gap:8,backdropFilter:"blur(8px)"})},h().createElement("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:8}},h().createElement("div",{style:{minWidth:0}},h().createElement("div",{style:{fontSize:12,fontWeight:800,color:M.isDark?"#F8FAFC":"#0F172A"}},ke(St.time,ea,l)),h().createElement("div",{style:{fontSize:11,color:M.isDark?"#94A3B8":"#64748B"}},(null===($=St.event)||void 0===$?void 0:$.isAnomaly)?`Cross-metric incident | ${St.event.activeSeries} aligned metric${1===St.event.activeSeries?"":"s"}`:St.anomalyCount>0?`${St.anomalyCount} flagged signal${1===St.anomalyCount?"":"s"} at this time`:"Live metric snapshot")),h().createElement("div",{style:{display:"flex",alignItems:"center",gap:8}},h().createElement("span",{style:{display:"inline-flex",alignItems:"center",borderRadius:999,padding:"4px 8px",fontSize:10,fontWeight:800,background:`${se[St.severityLabel]}22`,color:se[St.severityLabel]}},le[St.severityLabel]," ",St.severityScore),null!==$e?h().createElement("button",{type:"button",onClick:e=>{e.stopPropagation(),Ce(null)},style:{border:"1px solid "+(M.isDark?"#334155":"#CBD5E1"),background:M.isDark?"#0F172A":"#F8FAFC",color:M.isDark?"#E2E8F0":"#334155",borderRadius:999,padding:"4px 8px",fontSize:10,fontWeight:700,cursor:"pointer"}},"Unpin"):null)),h().createElement("div",{style:{display:"flex",flexDirection:"column",gap:6}},St.series.slice(0,4).map(e=>h().createElement("div",{key:`tooltip-${e.key}`,style:{display:"grid",gridTemplateColumns:"minmax(0,1fr) auto auto",gap:8,alignItems:"center",padding:"6px 8px",borderRadius:12,background:M.isDark?"rgba(15,23,42,0.72)":"#F8FAFC",border:"1px solid "+(M.isDark?"#1E293B":"#E2E8F0")}},h().createElement("div",{style:{minWidth:0,display:"flex",alignItems:"center",gap:8}},h().createElement("span",{style:{width:8,height:8,borderRadius:999,background:e.color,flex:"0 0 auto"}}),h().createElement("span",{style:{fontSize:11,fontWeight:700,color:M.isDark?"#E2E8F0":"#0F172A",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}},ve(e.label,24))),h().createElement("span",{style:{fontSize:11,fontWeight:700,color:M.isDark?"#F8FAFC":"#0F172A"}},he(e.actual)),h().createElement("span",{style:{fontSize:10,fontWeight:700,color:e.isAnomaly?se[e.severityLabel]:M.isDark?"#94A3B8":"#64748B"}},e.isAnomaly?le[e.severityLabel]:"normal"))))):null):null,ca?h().createElement("div",{className:L.bottomDock,style:{gridTemplateColumns:I.seriesSummary&&I.scoreFeed&&It?void 0:"minmax(0, 1fr)"}},I.seriesSummary?h().createElement("div",{className:L.legendTable,"aria-label":"Series anomaly summary"},h().createElement("div",{className:L.legendTableHeader},h().createElement("span",null,"Series (",Wt,")"),h().createElement("span",null,"Flagged"),h().createElement("span",null,"Max"),h().createElement("span",null,"Last")),pr.map(e=>{var t;const a=null!==(t=e.allPoints[e.allPoints.length-1])&&void 0!==t?t:null;return h().createElement("div",{key:e.key,className:L.legendTableRow,title:`${e.label} | ${e.anomalyCount} flagged buckets | max ${ge(e.maxSeverityScore)}`},h().createElement("span",{className:L.legendSeriesName},h().createElement("span",{className:L.legendSwatch,style:{background:e.color}}),h().createElement("span",{style:{minWidth:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}},e.label)),h().createElement("span",{className:L.legendValue,style:{color:e.anomalyCount>0?se[e.maxSeverityLabel]:void 0}},e.anomalyCount),h().createElement("span",{className:L.legendValue},ge(e.maxSeverityScore)),h().createElement("span",{className:L.legendValue},a?he(a.value):"n/a"))}),hr>0?h().createElement("div",{className:L.legendTableFooter},h().createElement("span",null,"Showing top ",pr.length," active series"),h().createElement("span",null,"+",hr," more hidden to keep the panel readable")):null):null,I.scoreFeed?It:null):null,oa?h().createElement("div",{className:L.secondaryDock,style:{gridTemplateColumns:I.anomalyFeed&&sa?void 0:"minmax(0, 1fr)"}},I.anomalyFeed?h().createElement(h().Fragment,null,h().createElement("div",{className:L.card},h().createElement("div",{className:L.cardTitle},"Detected incidents"),ut.length>0?h().createElement("div",{className:L.summaryTimeline},h().createElement("div",{className:L.subtitle},"Incident timeline"),h().createElement("svg",{width:"100%",height:"56",viewBox:"0 0 320 56",role:"img","aria-label":"Incident timeline overview"},h().createElement("line",{x1:18,y1:28,x2:302,y2:28,stroke:M.isDark?"#22314A":"#CBD5E1",strokeWidth:4,strokeLinecap:"round"}),ut.map((e,t)=>{const a=Zt===Kt?160:18+(e.time-Kt)/Math.max(Zt-Kt,1)*284,r=Le(e.selection)===ht,n=Se(e.severityLabel,O.markerShapeMode);return h().createElement("g",{key:`summary-timeline-${e.key}`,style:{cursor:"pointer"},onClick:()=>yt(e)},h().createElement("title",null,`${e.title} | ${ke(e.time,ea,l)}`),h().createElement("line",{x1:a,y1:16,x2:a,y2:40,stroke:se[e.severityLabel],strokeOpacity:r?.85:.4,strokeWidth:r?2:1.3}),Ne(n,a,28,r?7:5.4,M.isDark?"#08111F":"#FFFFFF",se[e.severityLabel],r?2.5:2),r?h().createElement("circle",{cx:a,cy:28,r:10.5,fill:"none",stroke:M.isDark?"#E2E8F0":"#0F172A",strokeOpacity:.4,strokeWidth:1.3}):null,0===t?h().createElement("text",{x:a,y:50,textAnchor:"start",fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},Ee(e.time,ea,"compact",l)):t===ut.length-1?h().createElement("text",{x:a,y:50,textAnchor:"end",fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},Ee(e.time,ea,"compact",l)):null)}))):null,h().createElement("div",{className:L.summaryList},0===re.length?h().createElement("div",{className:L.subtitle},"No operationally relevant incidents crossed the active threshold in the selected time range."):re.map(e=>h().createElement("button",{key:e.key,type:"button","aria-label":`Detected incident ${e.title}`,className:`${L.summaryRow} ${ht===Le(e.selection)?L.summaryRowSelected:""}`,onClick:()=>yt(e),style:{textAlign:"left",color:"inherit"}},h().createElement("div",{className:L.summaryMeta},h().createElement("span",{className:L.summaryTitle,title:e.title},e.title),h().createElement("span",{className:L.severityBadge,style:{background:`${se[e.severityLabel]}22`,color:se[e.severityLabel]}},le[e.severityLabel]," ",e.severityScore)),h().createElement("div",{className:L.subtitle},e.subtitle),h().createElement("div",{className:L.recommendationText},e.detail))))),h().createElement("div",{className:`${L.card} ${L.inlineInspectorLegacy}`},h().createElement("div",{className:L.cardTitle},"Legacy inspector details"),xt?h().createElement(h().Fragment,null,h().createElement("div",{className:L.recommendationText},xt.title),h().createElement("div",{className:L.subtitle},xt.subtitle),h().createElement("div",{className:L.recommendationText},_a),h().createElement("div",{className:L.actionRow},h().createElement("button",{type:"button",className:L.actionButton,disabled:!Xa||!W,onClick:()=>{Xa?W?pt(Xa).then(()=>Pe({tone:"success",message:"Created a Grafana annotation for the selected anomaly."})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to create the Grafana annotation."})):Pe({tone:"error",message:"Save the dashboard once before creating Grafana annotations from the panel."}):Pe({tone:"error",message:"Select an anomaly first to create an annotation."})}},"Create annotation"),h().createElement("button",{type:"button",className:L.actionButtonSecondary,disabled:!Va,onClick:()=>{Va?mt(Va).then(()=>Pe({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):Pe({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy alert query"),h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{er?mt(er).then(()=>Pe({tone:"success",message:"Copied the selected anomaly annotation JSON."})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to copy the annotation JSON."})):Pe({tone:"error",message:"Select an anomaly first to copy its annotation JSON."})}},"Copy annotation JSON")),W?null:h().createElement("div",{className:L.subtitle},"Save the dashboard once so Grafana knows which dashboard the new annotation belongs to."),h().createElement("div",{className:L.detailGrid},h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Raw detection score"),h().createElement("div",{className:L.detailValue},he(xt.score))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Alert score (0-100)"),h().createElement("div",{className:L.detailValue,style:{color:se[xt.severityLabel]}},le[xt.severityLabel]," ",xt.severityScore)),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Confidence"),h().createElement("div",{className:L.detailValue,style:{color:ce[xt.confidenceLabel]}},oe[xt.confidenceLabel])),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Data quality"),h().createElement("div",{className:L.detailValue},de[xt.dataQualityLabel])),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Bucket span"),h().createElement("div",{className:L.detailValue},be(xt.bucketStart,xt.bucketEnd))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Recommended action"),h().createElement("div",{className:L.detailValue},De(xt,O.severityPreset)))),"point"===xt.kind?h().createElement("div",{className:L.detailGrid},h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Current value"),h().createElement("div",{className:L.detailValue},he(xt.actual))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Expected value"),h().createElement("div",{className:L.detailValue},he(xt.expected))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Change"),h().createElement("div",{className:L.detailValue},he(xt.deviation))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Change %"),h().createElement("div",{className:L.detailValue},fe(xt.deviationPercent))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Expected range"),h().createElement("div",{className:L.detailValue},(Nr=xt.rangeLower,$r=xt.rangeUpper,null===Nr||null===$r?"n/a":`${he(Nr)} - ${he($r)}`))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Samples in bucket"),h().createElement("div",{className:L.detailValue},xt.sampleCount)),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Instant signal"),h().createElement("div",{className:L.detailValue},he(xt.pointScore))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Sustained signal"),h().createElement("div",{className:L.detailValue},he(xt.windowScore))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Main reason"),h().createElement("div",{className:L.detailValue},Be(xt.scoreDriver,O.algorithm)))):h().createElement("div",{className:L.metricBreakdownList},h().createElement("div",{className:L.subtitle},"Metric breakdown"),xt.breakdown.map(e=>h().createElement("div",{key:e.label,className:L.metricBreakdownCard,style:{borderColor:M.isDark?`${e.color}55`:`${e.color}66`}},h().createElement("div",{className:L.metricBreakdownHeader},h().createElement("div",null,h().createElement("div",{className:L.metricBreakdownTitle,style:{color:e.color}},e.label),h().createElement("div",{className:L.metricBreakdownReason},Be(e.scoreDriver,O.algorithm)," | ",oe[e.confidenceLabel])),h().createElement("span",{className:L.severityBadge,style:{background:`${se[e.severityLabel]}22`,color:se[e.severityLabel]}},le[e.severityLabel]," ",e.severityScore)),h().createElement("div",{className:L.metricBreakdownGrid},h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Current"),h().createElement("div",{className:L.metricBreakdownStatValue},he(e.actual))),h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Expected"),h().createElement("div",{className:L.metricBreakdownStatValue},he(e.expected))),h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Change"),h().createElement("div",{className:L.metricBreakdownStatValue},he(e.deviation))),h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Main reason"),h().createElement("div",{className:L.metricBreakdownStatValue},Be(e.scoreDriver,O.algorithm))),h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Confidence"),h().createElement("div",{className:L.metricBreakdownStatValue,style:{color:ce[e.confidenceLabel]}},oe[e.confidenceLabel])),h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Strength"),h().createElement("div",{className:L.metricBreakdownStatValue,style:{color:se[e.severityLabel]}},he(e.score)))))))):h().createElement("div",{className:L.subtitle},"Select a detected incident to see why it was flagged, how strong the signal is, and whether it is ready for alerting."))):null,sa?h().createElement("div",{className:L.sideUtilityStack},I.detectionProfile?h().createElement("div",{className:`${L.card} ${L.profileCard}`},h().createElement("div",{className:L.cardTitle},"Active detection profile"),h().createElement("div",{className:`${L.recommendationText} ${L.profileSummary}`},Pa),h().createElement("div",{className:L.profileDetailGrid},h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Setup mode"),h().createElement("div",{className:L.detailValue},Z[O.setupMode])),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Metric preset"),h().createElement("div",{className:L.detailValue},X[O.metricPreset])),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Effective preset"),h().createElement("div",{className:L.detailValue},"custom"===O.effectiveMetricPreset?"Custom":X[O.effectiveMetricPreset])),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Severity preset"),h().createElement("div",{className:L.detailValue},ie[O.severityPreset])))):null,I.exports?h().createElement("div",{className:`${L.card} ${L.handoffCard}`},h().createElement("div",{className:L.handoffHeader},h().createElement("div",{style:{minWidth:0,flex:"1 1 220px"}},h().createElement("div",{className:L.cardTitle},"Alerting & automation"),h().createElement("div",{className:L.subtitle},"Optional handoff only. Daily alert setup should use the inspector buttons; expand this when you need raw JSON.")),h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>Oe(e=>!e)},Ve?"Hide exports":"Show exports")),Ve?h().createElement(h().Fragment,null,h().createElement("div",{className:L.feedRuleCard},h().createElement("div",{className:L.handoffHeader},h().createElement("div",{className:L.cardTitle},"Annotation export"),h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{mt(Ra).then(()=>Pe({tone:"success",message:"Copied the annotation export JSON."})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to copy the annotation export JSON."}))}},"Copy JSON")),h().createElement("div",{className:L.subtitle},"Use this JSON as a ready annotation or incident handoff payload."),h().createElement("pre",{className:L.monoBlock},Ra)),h().createElement("div",{className:L.feedRuleCard},h().createElement("div",{className:L.handoffHeader},h().createElement("div",{style:{minWidth:0,flex:"1 1 220px"}},h().createElement("div",{className:L.cardTitle},"Alert rule export"),h().createElement("div",{className:L.subtitle},Va?`Paste this ${Ct} into Grafana Alerting, then set WHEN QUERY IS ABOVE ${Oa} FOR 10m and evaluate every 3m.`:"Sync anomaly score feed first to generate an alert-ready anomaly score query.")),h().createElement("button",{type:"button",className:L.actionButtonSecondary,disabled:!Va,onClick:()=>{Va?mt(Va).then(()=>Pe({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>Pe({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):Pe({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy query")),h().createElement("div",null,h().createElement("div",{className:L.subtitle},"Suggested labels"),h().createElement("div",{className:L.labelChipGrid,style:{marginTop:8}},Object.entries(Ua).map(([e,t])=>h().createElement("span",{key:e,className:L.labelChip,title:`${e}=${t}`},h().createElement("span",{className:L.labelChipKey},e),h().createElement("span",null,"="),h().createElement("span",{className:L.labelChipValue},t))))),h().createElement("div",{className:L.codeLine},Va||"Sync anomaly score feed first to generate an alert-ready query."),h().createElement("pre",{className:L.monoBlock},Ja))):null):null):null):null),I.inspector?h().createElement("aside",{className:L.inspectorRail},Fr):null));var Nr,$r}).setPanelOptions(e=>e.addTextInput({path:"title",name:"Panel title",description:"Short label shown above the anomaly chart.",defaultValue:"Anomaly detector",category:It}).addRadio({path:"setupMode",name:"Setup mode",description:"Recommended mode keeps the UI simple. Advanced mode unlocks manual algorithm controls.",defaultValue:"recommended",settings:{options:Ht},category:It}).addSelect({path:"metricPreset",name:"Metric type",description:"Start with Auto unless you already know the metric family.",defaultValue:"auto",settings:{options:Kt},category:It,showIf:e=>"advanced"!==e.setupMode&&"custom"!==e.metricPreset}).addRadio({path:"detectionMode",name:"Detection mode",description:"Single metric scores each series independently. Multi metric combines same-timestamp signals into one event score.",defaultValue:"single",settings:{options:Qt},category:It}).addSelect({path:"scoreFeedMode",name:"Score feed mode",description:"Publish the anomaly scores detected by this plugin panel to Prometheus metrics or an exporter sink.",defaultValue:"auto",settings:{options:Gt},category:qt}).addSelect({path:"scoreFeedTarget",name:"Score feed target",description:"Choose where the plugin-computed anomaly score snapshot is published.",defaultValue:"prometheus",settings:{options:Yt},category:qt,showIf:e=>"off"!==e.scoreFeedMode}).addTextInput({path:"scoreFeedEndpoint",name:"Exporter endpoint",description:"Browser-side endpoint for the anomaly exporter. The plugin posts detected score snapshots here.",defaultValue:"http://127.0.0.1:9110",category:qt,showIf:e=>"off"!==e.scoreFeedMode}).addTextInput({path:"scoreFeedRuleNamePrefix",name:"Rule name prefix",description:"Optional short prefix used when naming the published anomaly score feed for this panel.",defaultValue:"",category:qt,showIf:e=>"off"!==e.scoreFeedMode}).addSelect({path:"bucketSpan",name:"Bucket span",description:"Optional pre-aggregation before anomaly scoring. Auto keeps the panel responsive on large or live queries.",defaultValue:"auto",settings:{options:Zt},category:Wt}).addSelect({path:"algorithm",name:"Algorithm",description:"Visible in Advanced mode when you want to pick the scoring strategy yourself.",defaultValue:"zscore",settings:{options:Jt},category:zt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addSliderInput({path:"sensitivity",name:"Anomaly threshold",description:"Move left to catch subtler changes (more alerts), or right to suppress noise (fewer alerts). Balanced 4.0 is the recommended starting point.",defaultValue:4,settings:{min:.2,max:10,step:.1,marks:{[d]:"Sensitive",[u]:"Balanced",[m]:"Strict"},ariaLabelForHandle:"Anomaly threshold: lower is more sensitive, higher is stricter"},category:zt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"baselineWindow",name:"History & warm-up window",description:"Baseline bucket count. Detection waits for this history at the start of a selected range, reducing premature false positives; larger values are steadier but react more slowly.",defaultValue:12,category:zt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"seasonalitySamples",name:"Season length (samples)",description:"Used by cycle-based seasonal mode. Example: 24 for an hourly pattern or 288 for a daily pattern in 5-minute data.",defaultValue:24,category:zt,showIf:e=>("advanced"===e.setupMode||"custom"===e.metricPreset)&&"seasonal"===e.algorithm}).addSelect({path:"seasonalRefinement",name:"Seasonal refinement",description:"Choose whether seasonal matching is based on fixed cycles, hour-of-day, or weekday plus hour.",defaultValue:"cycle",settings:{options:Xt},category:zt,showIf:e=>("advanced"===e.setupMode||"custom"===e.metricPreset)&&"seasonal"===e.algorithm}).addSelect({path:"severityPreset",name:"Severity preset",description:"Controls how severity scores are translated into warning, high, and critical style labels.",defaultValue:"balanced",settings:{options:ea},category:zt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"maxAnomalies",name:"Max anomalies in summary",description:"Limits the number of highest scoring anomalies listed below the chart.",defaultValue:8,category:jt}).addBooleanSwitch({path:"showBands",name:"Show expected band",defaultValue:!0,category:jt}).addBooleanSwitch({path:"showExpectedLine",name:"Show expected line",defaultValue:!0,category:jt}).addBooleanSwitch({path:"showInitialLabels",name:"Initial labels",description:"Show the panel title, algorithm, bucket, selected series, and datasource context.",defaultValue:!0,category:Ut}).addBooleanSwitch({path:"showStatistics",name:"Statistics",description:"Show severity, confidence, anomaly count, and data quality cards.",defaultValue:!0,category:Ut}).addBooleanSwitch({path:"showAnomalyFeed",name:"Anomaly feed",description:"Show the incident overview ribbon, timeline, and incident list.",defaultValue:!0,category:Ut}).addBooleanSwitch({path:"showMainChart",name:"Main chart",defaultValue:!0,category:Ut}).addBooleanSwitch({path:"showSeriesSummary",name:"Series summary",defaultValue:!0,category:Ut}).addBooleanSwitch({path:"showInspector",name:"Anomaly inspector",defaultValue:!0,category:Ut}).addBooleanSwitch({path:"showScoreFeed",name:"Score feed status",description:"Show the selected score target and its synchronization status. Publishing remains controlled by Score feed mode.",defaultValue:!0,category:Ut}).addBooleanSwitch({path:"showDetectionProfile",name:"Detection profile",defaultValue:!0,category:Ut}).addBooleanSwitch({path:"showInlineSeriesLabels",name:"Show inline series labels",description:"Show each series name at the right edge of the chart so the line identity stays visible without scanning the legend.",defaultValue:!0,category:jt}).addBooleanSwitch({path:"showFocusBand",name:"Show anomaly focus band",description:"Render a zoomed local band around the selected anomaly for faster incident review.",defaultValue:!1,category:jt}).addSelect({path:"timeAxisDensity",name:"Time axis density",description:"Control how many time labels are shown on the chart.",defaultValue:"auto",settings:{options:ta},category:jt}).addSelect({path:"timeAxisPlacement",name:"Time axis placement",description:"Choose whether time labels are shown only at the bottom or on both top and bottom edges.",defaultValue:"top_and_bottom",settings:{options:aa},category:jt}).addSelect({path:"markerShapeMode",name:"Anomaly marker style",description:"Choose whether severity is communicated with different marker shapes or with classic circular markers.",defaultValue:"severity",settings:{options:ra},category:jt}).addBooleanSwitch({path:"showExports",name:"Show export blocks",defaultValue:!1,category:Ut}));return o})());
//# sourceMappingURL=module.js.map