/* [create-plugin] version: 7.0.7 */
/* [create-plugin] plugin: alpas-anomalydetector-panel@1.3.0 */
define(["@emotion/css","@grafana/data","@grafana/runtime","@grafana/ui","react"],(e,t,a,r,n)=>(()=>{"use strict";var i={89(t){t.exports=e},781(e){e.exports=t},531(e){e.exports=a},7(e){e.exports=r},959(e){e.exports=n}},l={};function s(e){var t=l[e];if(void 0!==t)return t.exports;var a=l[e]={exports:{}};return i[e](a,a.exports,s),a.exports}s.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return s.d(t,{a:t}),t},s.d=(e,t)=>{for(var a in t)s.o(t,a)&&!s.o(e,a)&&Object.defineProperty(e,a,{enumerable:!0,get:t[a]})},s.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),s.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var o={};s.r(o),s.d(o,{plugin:()=>jt});var c=s(781),d=s(959),m=s.n(d),u=s(89),p=s(7),h=s(531);function g(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}function f(e){for(var t=1;t<arguments.length;t++){var a=null!=arguments[t]?arguments[t]:{},r=Object.keys(a);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(a).filter(function(e){return Object.getOwnPropertyDescriptor(a,e).enumerable}))),r.forEach(function(t){g(e,t,a[t])})}return e}function y(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),a.push.apply(a,r)}return a}(Object(t)).forEach(function(a){Object.defineProperty(e,a,Object.getOwnPropertyDescriptor(t,a))}),e}const b={"1m":6e4,"5m":3e5,"15m":9e5,"1h":36e5},v=(Object.values(b).sort((e,t)=>e-t),{warning_first:{low:35,medium:55,high:72,critical:88},balanced:{low:40,medium:60,high:75,critical:90},page_first:{low:45,medium:65,high:82,critical:95}}),x=e=>e.reduce((e,t)=>e+t,0)/e.length,w=e=>{const t=[...e].sort((e,t)=>e-t),a=Math.floor(t.length/2);return t.length%2==0?(t[a-1]+t[a])/2:t[a]},E=(e,t)=>{if(0===e.length)return 0;const a=null!=t?t:w(e);return 1.4826*w(e.map(e=>Math.abs(e-a)))},k=(e,t)=>{if(e.length<=1)return 0;const a=null!=t?t:x(e),r=e.reduce((e,t)=>e+Math.pow(t-a,2),0)/e.length;return Math.sqrt(r)},S=(e,t)=>Number.isFinite(e)&&e>1e-9?e:Math.max(.02*Math.abs(t),1e-6),F=(e,t,a)=>{const r=v[a],n=e/Math.max(t,1e-4);if(n<1)return{severityScore:Math.min(r.low-1,Math.round(n*(r.low-1))),severityLabel:"normal"};const i=Math.min(100,Math.round(r.low+30*(n-1)));return i>=r.critical?{severityScore:i,severityLabel:"critical"}:i>=r.high?{severityScore:i,severityLabel:"high"}:i>=r.medium?{severityScore:i,severityLabel:"medium"}:{severityScore:i,severityLabel:"low"}},$=(e,t,a)=>{const r=e.slice(Math.max(0,t-a),t+1),n=r.map(e=>e.value),i=r.slice(-Math.max(4,Math.min(a,8)));if(n.length<Math.max(3,Math.floor(a/2)))return"thin";if(i.length>=3){const e=i.slice(1).map((e,t)=>e.time-i[t].time).filter(e=>e>0),t=e.length>0?w(e):null;if(t&&e.some(e=>e>2.4*t))return"gappy"}if(i.length>=4){const e=i.map(e=>e.value),t=Math.max(.002*Math.abs(x(e)),1e-6);if(Math.max(...e)-Math.min(...e)<=t)return"flatline"}return"healthy"},N=(e,t,a,r,n,i)=>{const l=Math.max(t,1e-6);let s=Math.min(e/l,2.5)/2.5*100;r>a&&(s+=8),n>=8&&(s+=4),"thin"===i?s-=18:"flatline"===i?s-=22:"gappy"===i&&(s-=12);const o=Math.max(5,Math.min(100,Math.round(10*s)/10));return{confidenceScore:o,confidenceLabel:o>=80?"high":o>=55?"medium":"low",dataQualityLabel:i}},M=(e,t,a)=>{const r=F(0,t,a);return y(f(y(f({},e),{expected:null,upper:null,lower:null,score:0,pointScore:0,windowScore:0,scoreDriver:"point",isAnomaly:!1}),r),{confidenceScore:5,confidenceLabel:"low",dataQualityLabel:"thin"})},L=(e,t,a,r)=>{const n=[],i=2/(Math.max(a,2)+1);let l=null;const s=[];return e.forEach((o,c)=>{if(0===c||null===l)return l=o.value,void n.push(M(o,t,r));const d=l,m=S(w(s.slice(-a))||k(e.slice(Math.max(0,c-a),c).map(e=>e.value)),d),u=e.slice(Math.max(0,c-a),c).map(e=>e.value),p=Math.abs(o.value-d)/m,h=((e,t,a,r,n)=>{const i=Math.min(Math.max(3,Math.floor(n/3)),10),l=[...e.slice(-(i-1)),t];return l.length<3?0:Math.abs(x(l)-a)/r})(u,o.value,d,m,a),g=Math.max(p,h),b=F(g,t,r),v=N(g,t,p,h,u.length+1,$(e,c,a));s.push(Math.abs(o.value-d)),l=i*o.value+(1-i)*d,n.push(f(y(f({},o),{expected:d,lower:d-t*m,upper:d+t*m,score:g,pointScore:p,windowScore:h,scoreDriver:h>p?"window":"point",isAnomaly:g>=t}),b,v))}),n},A=(e,t,a,r,n,i)=>{const l=new Map,s=new Map;return e.map((o,c)=>{let d=[];if("cycle"===n)for(let t=c-r;t>=0&&d.length<a;t-=r)d.push(e[t].value);else{var m,u,p,h;const e=(e=>{const t=new Date(e);return{hour_of_day:`hour:${t.getHours()}`,weekday_hour:`weekday:${t.getDay()}-${t.getHours()}`}})(o.time);var g;if(d="hour_of_day"===n?[...null!==(m=l.get(e.hour_of_day))&&void 0!==m?m:[]].slice(-a):[...null!==(u=s.get(e.weekday_hour))&&void 0!==u?u:[]].slice(-a),"weekday_hour"===n&&d.length<3)d=[...null!==(g=l.get(e.hour_of_day))&&void 0!==g?g:[]].slice(-a);const t=null!==(p=l.get(e.hour_of_day))&&void 0!==p?p:[];t.push(o.value),l.set(e.hour_of_day,t);const r=null!==(h=s.get(e.weekday_hour))&&void 0!==h?h:[];r.push(o.value),s.set(e.weekday_hour,r)}if(d.length<3)return M(o,t,i);const b=e.slice(Math.max(0,c-a),c).map(e=>e.value),{expected:v,spread:x}=((e,t)=>{const a=w(e),r=S(E(e,a),a),n=e.slice(1).map((t,a)=>t-e[a]),i=n.length>=2?w(n):0,l=n.length>=2?S(E(n,i),a):0,s=t.length>0?S(E(t),w(t)):0,o=Math.max(r,l,.75*s);return{expected:a+i,spread:S(o,a+i)}})(d,b),k=Math.abs(o.value-v)/x,L=k,A=F(L,t,i),C=N(L,t,k,0,b.length+1,$(e,c,a));return f(y(f({},o),{expected:v,lower:v-t*x,upper:v+t*x,score:L,pointScore:k,windowScore:0,scoreDriver:0>k?"window":"point",isAnomaly:L>=t}),A,C)})},C=(e,t,a,r)=>{const n=e.map(e=>e.value),i=Math.min(Math.max(3,Math.floor(a/3)),12),l=Math.max(1,i-1),s=Math.max(6*a,a+i),o=Math.max(6,i+3);return e.map((i,c)=>{const d=Math.max(0,c-s);if(c-d<o)return M(i,t,r);const m=c-l;if(m-d<3)return M(i,t,r);const u=((e,t,a,r)=>{const n=Math.min(t+r,a);return n-t>=3?e.slice(t,n):e.slice(Math.max(t,a-r),a)})(n,d,m,a),p=x(u),h=S(k(u,p),p),g=Math.abs(i.value-p)/h,b=Math.max(0,c-l);let v=i.value,w=Math.abs(i.value-p)>h?1:0;for(let e=b;e<c;e+=1){const t=n[e];v+=t,Math.abs(t-p)>h&&(w+=1)}const E=c-b+1,L=v/E,A=w/E,C=Math.abs(L-p)/h*(1+Math.max(0,A-.4)),B=Math.max(.85*g,C),D=F(B,t,r),T=N(B,t,g,C,u.length+1,$(e,c,a));return f(y(f({},i),{expected:p,lower:p-t*h,upper:p+t*h,score:B,pointScore:g,windowScore:C,scoreDriver:C>=.85*g?"window":"point",isAnomaly:B>=t}),D,T)})},B=(e,t)=>{const a=Math.max(t.baselineWindow,3),r=Math.max(t.sensitivity,.2);switch(t.algorithm){case"mad":return((e,t,a,r)=>e.map((n,i)=>{const l=e.slice(Math.max(0,i-a),i).map(e=>e.value);if(l.length<3)return M(n,t,r);const s=w(l),o=l.map(e=>Math.abs(e-s)),c=S(1.4826*w(o),s),d=Math.abs(n.value-s)/c,m=d,u=F(m,t,r),p=N(m,t,d,0,l.length+1,$(e,i,a));return f(y(f({},n),{expected:s,lower:s-t*c,upper:s+t*c,score:m,pointScore:d,windowScore:0,scoreDriver:0>d?"window":"point",isAnomaly:m>=t}),u,p)}))(e,r,a,t.severityPreset);case"ewma":return L(e,r,a,t.severityPreset);case"level_shift":return C(e,r,a,t.severityPreset);case"seasonal":return A(e,r,a,Math.max(t.seasonalitySamples,2),t.seasonalRefinement,t.severityPreset);default:return((e,t,a,r)=>e.map((n,i)=>{const l=e.slice(Math.max(0,i-a),i).map(e=>e.value);if(l.length<3)return M(n,t,r);const s=x(l),o=S(k(l,s),s),c=Math.abs(n.value-s)/o,d=c,m=F(d,t,r),u=N(d,t,c,0,l.length+1,$(e,i,a));return f(y(f({},n),{expected:s,lower:s-t*o,upper:s+t*o,score:d,pointScore:c,windowScore:0,scoreDriver:0>c?"window":"point",isAnomaly:d>=t}),m,u)}))(e,r,a,t.severityPreset)}};function D(e,t,a,r,n,i,l){try{var s=e[i](l),o=s.value}catch(e){return void a(e)}s.done?t(o):Promise.resolve(o).then(r,n)}function T(e){return function(){var t=this,a=arguments;return new Promise(function(r,n){var i=e.apply(t,a);function l(e){D(i,r,n,l,s,"next",e)}function s(e){D(i,r,n,l,s,"throw",e)}l(void 0)})}}function P(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}function _(e){for(var t=1;t<arguments.length;t++){var a=null!=arguments[t]?arguments[t]:{},r=Object.keys(a);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(a).filter(function(e){return Object.getOwnPropertyDescriptor(a,e).enumerable}))),r.forEach(function(t){P(e,t,a[t])})}return e}function R(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),a.push.apply(a,r)}return a}(Object(t)).forEach(function(a){Object.defineProperty(e,a,Object.getOwnPropertyDescriptor(t,a))}),e}const O=["#7EB26D","#EAB839","#6ED0E0","#EF843C","#E24D42","#1F78C1"],V=720,I={top:18,right:20,bottom:42,left:64},q={"1m":6e4,"5m":3e5,"15m":9e5,"1h":36e5},W=Object.values(q).sort((e,t)=>e-t),z={recommended:"Recommended",advanced:"Advanced"},j={zscore:"Rolling z-score",mad:"Rolling MAD",ewma:"EWMA baseline",seasonal:"Seasonal baseline",level_shift:"Level shift detector"},U={auto:"Auto",custom:"Custom",traffic:"Traffic / throughput",latency:"Latency / duration",error_rate:"Error rate",resource:"Resource usage",business:"Business KPI",level_shift:"Subtle level shift"},H={auto:"Auto",raw:"Raw samples","1m":"1 minute","5m":"5 minutes","15m":"15 minutes","1h":"1 hour"},Q={traffic:{algorithm:"ewma",sensitivity:4.5,baselineWindow:30,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"warning_first",badge:"Stable default",why:"Traffic and throughput metrics drift with load, so EWMA is usually the safest default for live dashboards."},latency:{algorithm:"mad",sensitivity:4,baselineWindow:12,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"page_first",badge:"Noisy data",why:"Latency metrics are often spiky and outlier-heavy, so MAD is more robust than a mean-based baseline."},error_rate:{algorithm:"mad",sensitivity:4.5,baselineWindow:12,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"page_first",badge:"Burst errors",why:"Error metrics often stay low and then jump sharply, so MAD isolates bursts without letting them poison the baseline."},resource:{algorithm:"ewma",sensitivity:4.5,baselineWindow:24,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Drifting baseline",why:"CPU, memory, and load metrics usually move gradually, so EWMA follows the baseline smoothly without overreacting."},business:{algorithm:"seasonal",sensitivity:4.5,baselineWindow:8,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Seasonal data",why:"Business KPIs often repeat by hour or weekday, so seasonal matching reduces false positives on recurring patterns."},level_shift:{algorithm:"level_shift",sensitivity:6,baselineWindow:30,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Sustained change",why:"When the baseline shifts gradually or steps into a new level, a level-shift detector is better than a pure spike detector."}},G=["latency","error_rate","level_shift","resource","business","traffic"],Y=[{preset:"latency",patterns:[/latency/i,/duration/i,/response/i,/p95/i,/p99/i,/p90/i,/quantile/i,/delay/i,/ms/i,/seconds?/i]},{preset:"error_rate",patterns:[/error/i,/errors/i,/failure/i,/fail/i,/exception/i,/timeout/i,/reject/i,/5xx/i,/4xx/i]},{preset:"resource",patterns:[/cpu/i,/memory/i,/load/i,/utili/i,/usage/i,/heap/i,/rss/i,/disk/i,/iops/i,/saturation/i,/throttle/i]},{preset:"level_shift",patterns:[/queue/i,/backlog/i,/pending/i,/session/i,/connection/i,/thread/i,/pool/i,/worker/i,/lag/i,/offset/i,/buffer/i,/inflight/i,/active/i]},{preset:"business",patterns:[/revenue/i,/order/i,/orders/i,/signup/i,/conversion/i,/checkout/i,/cart/i,/booking/i,/payment/i,/sales/i,/gmv/i]},{preset:"traffic",patterns:[/request/i,/requests/i,/throughput/i,/traffic/i,/volume/i,/events?/i,/rps/i,/qps/i,/ops/i,/hits?/i,/ingress/i,/egress/i,/count/i]}],K={cycle:"Cycle only",hour_of_day:"Hour of day",weekday_hour:"Weekday + hour"},Z={balanced:"Balanced",warning_first:"Warning first",page_first:"Page first"},J={normal:"Normal",low:"Low",medium:"Medium",high:"High",critical:"Critical"},X={normal:"#94A3B8",low:"#EAB308",medium:"#F59E0B",high:"#F97316",critical:"#DC2626"},ee={low:"Low confidence",medium:"Medium confidence",high:"High confidence"},te={low:"#F59E0B",medium:"#2563EB",high:"#16A34A"},ae={healthy:"Healthy data",thin:"Thin history",flatline:"Flatline risk",gappy:"Gappy sampling"},re=e=>{if("number"==typeof e&&Number.isFinite(e))return e;if("string"==typeof e){const t=Number(e);return Number.isFinite(t)?t:null}return null},ne=(e,t)=>{if(e)return"function"==typeof e.get?e.get(t):e[t]},ie=e=>{const t=[...e].sort((e,t)=>e-t),a=Math.floor(t.length/2);return t.length%2==0?(t[a-1]+t[a])/2:t[a]},le=e=>{if(null===e||!Number.isFinite(e))return"n/a";const t=Math.abs(e);return t>=1e3?e.toLocaleString(void 0,{maximumFractionDigits:1}):t>=10?e.toLocaleString(void 0,{maximumFractionDigits:2}):e.toLocaleString(void 0,{maximumFractionDigits:3})},se=e=>null!==e&&Number.isFinite(e)?Math.round(e).toLocaleString(void 0,{maximumFractionDigits:0}):"n/a",oe=e=>null!==e&&Number.isFinite(e)?`${e.toLocaleString(void 0,{maximumFractionDigits:1})}%`:"n/a",ce=e=>new Date(e).toLocaleString(void 0,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}),de=(e,t)=>t<=e?ce(e):`${ce(e)} - ${ce(t)}`,me=(e,t=26)=>e.length<=t?e:`${e.slice(0,Math.max(1,t-1)).trimEnd()}…`,ue=(e,t)=>"auto"!==e?e:t<=216e5?"dense":t<=1296e5?"balanced":"compact",pe=(e,t)=>{const a=ue(t,e);return e<=432e5||"dense"===a?"HH:mm":e<=2592e5?"DD/MM HH:mm":"DD/MM"},he=(e,t,a,r)=>(0,c.dateTimeFormat)(e,{format:pe(t,a),timeZone:r}),ge=(e,t,a)=>(0,c.dateTimeFormat)(e,{format:t<=2592e5?"DD/MM HH:mm":"DD/MM/YYYY HH:mm",timeZone:a}),fe=(e,t)=>{if("classic"===t)return"circle";switch(e){case"medium":return"diamond";case"high":return"triangle";case"critical":return"square";default:return"circle"}},ye=(e,t,a,r)=>"diamond"===e?`M ${t} ${a-r} L ${t+r} ${a} L ${t} ${a+r} L ${t-r} ${a} Z`:`M ${t} ${a-r} L ${t+.92*r} ${a+.9*r} L ${t-.92*r} ${a+.9*r} Z`,be=(e,t,a,r,n,i,l=0,s)=>"circle"===e?m().createElement("circle",{cx:t,cy:a,r,fill:n,stroke:i,strokeWidth:l,opacity:s}):"square"===e?m().createElement("rect",{x:t-r,y:a-r,width:2*r,height:2*r,rx:Math.max(1.5,.32*r),fill:n,stroke:i,strokeWidth:l,opacity:s}):m().createElement("path",{d:ye(e,t,a,r),fill:n,stroke:i,strokeWidth:l,opacity:s}),ve=(e,t)=>{var a,r;if("advanced"===e.setupMode||"custom"===e.effectiveMetricPreset)return{source:"manual",badge:"Manual tuning",title:"Advanced controls are active",reason:`Algorithm ${j[e.algorithm]} with ${Z[e.severityPreset]} severity mapping is applied directly.`,matchedNames:[],confidence:"matched"};const n=Q[e.effectiveMetricPreset],i="auto"===e.metricPreset?"auto":"selected",l="auto"===i?`Auto selected ${U[e.effectiveMetricPreset]}`:`${U[e.effectiveMetricPreset]} preset is active`;return{source:i,badge:n.badge,title:l,reason:n.why,matchedNames:null!==(a=null==t?void 0:t.matchedNames)&&void 0!==a?a:[],confidence:null!==(r=null==t?void 0:t.confidence)&&void 0!==r?r:"matched"}},xe=(e,t)=>{var a,r,n,i,l,s,o;const c=null!==(a=e.setupMode)&&void 0!==a?a:"recommended",d=null!==(r=e.metricPreset)&&void 0!==r?r:"auto",m=Math.max(3,Math.min(20,Math.round(null!==(n=e.maxAnomalies)&&void 0!==n?n:8))),u=e.bucketSpan||"auto";if("advanced"===c||"custom"===d){var p,h,g,f,y,b,v,x,w,E;const t={setupMode:c,metricPreset:d,effectiveMetricPreset:"custom",detectionMode:null!==(p=e.detectionMode)&&void 0!==p?p:"single",algorithm:null!==(h=e.algorithm)&&void 0!==h?h:"zscore",sensitivity:Math.max(.2,null!==(g=e.sensitivity)&&void 0!==g?g:4),baselineWindow:Math.max(3,Math.round(null!==(f=e.baselineWindow)&&void 0!==f?f:12)),seasonalitySamples:Math.max(2,Math.round(null!==(y=e.seasonalitySamples)&&void 0!==y?y:24)),seasonalRefinement:null!==(b=e.seasonalRefinement)&&void 0!==b?b:"cycle",severityPreset:null!==(v=e.severityPreset)&&void 0!==v?v:"balanced",bucketSpan:u,showExpectedLine:!1!==e.showExpectedLine,showInlineSeriesLabels:!1!==e.showInlineSeriesLabels,showFocusBand:!0===e.showFocusBand,timeAxisDensity:null!==(x=e.timeAxisDensity)&&void 0!==x?x:"auto",timeAxisPlacement:null!==(w=e.timeAxisPlacement)&&void 0!==w?w:"top_and_bottom",markerShapeMode:null!==(E=e.markerShapeMode)&&void 0!==E?E:"severity",maxAnomalies:m};return R(_({},t),{recommendation:ve(t,null)})}const k="auto"===d?(e=>{const t=new Map;for(const r of e)for(const e of Y)if(e.patterns.some(e=>e.test(r))){var a;const n=null!==(a=t.get(e.preset))&&void 0!==a?a:[];n.push(r),t.set(e.preset,n)}for(const e of G){var r;const a=null!==(r=t.get(e))&&void 0!==r?r:[];if(a.length>0)return{preset:e,matchedNames:a,confidence:a.length>=2?"matched":"weak"}}return{preset:"traffic",matchedNames:[],confidence:"fallback"}})(t):null,S="auto"===d?null==k?void 0:k.preset:d,F=Q[S],$={setupMode:c,metricPreset:d,effectiveMetricPreset:S,detectionMode:null!==(i=e.detectionMode)&&void 0!==i?i:"single",algorithm:F.algorithm,sensitivity:F.sensitivity,baselineWindow:F.baselineWindow,seasonalitySamples:F.seasonalitySamples,seasonalRefinement:F.seasonalRefinement,severityPreset:F.severityPreset,bucketSpan:u,showExpectedLine:!1!==e.showExpectedLine,showInlineSeriesLabels:!1!==e.showInlineSeriesLabels,showFocusBand:!0===e.showFocusBand,timeAxisDensity:null!==(l=e.timeAxisDensity)&&void 0!==l?l:"auto",timeAxisPlacement:null!==(s=e.timeAxisPlacement)&&void 0!==s?s:"top_and_bottom",markerShapeMode:null!==(o=e.markerShapeMode)&&void 0!==o?o:"severity",maxAnomalies:m};return R(_({},$),{recommendation:ve($,k)})},we=e=>e?"point"===e.kind?`point:${e.seriesKey}:${e.time}`:`event:${e.time}`:"none",Ee=e=>["normal","low","medium","high","critical"].indexOf(e),ke=(e,t)=>Ee(t.severityLabel)>Ee(e.severityLabel)||Ee(t.severityLabel)===Ee(e.severityLabel)&&t.severityScore>e.severityScore?t:e,Se=(e,t)=>"level_shift"===t?"window"===e?"Sustained baseline shift":"Fresh step change":"seasonal"===t?"Seasonal pattern break":"window"===e?"ewma"===t?"Short sustained drift":"Sustained deviation":"Sharp point deviation",Fe=(e,t)=>{const a="warning_first"===t?"Warning-first preset surfaces operator-visible severity earlier.":"page_first"===t?"Page-first preset keeps high and critical stricter for paging workflows.":"Balanced preset aims to work for both dashboards and alert handoff.",r="low"===e.confidenceLabel?" Confidence is still low, so verify with nearby metrics before paging.":"thin"===e.dataQualityLabel?" History is still thin, so treat this as early signal rather than hard evidence.":"flatline"===e.dataQualityLabel?" The series looks nearly flat, so verify the metric is still reporting healthy samples.":"gappy"===e.dataQualityLabel?" Recent samples are gappy, so confirm the data source timing before escalating.":"";return"critical"===e.severityLabel||"high"===e.severityLabel?`${a} This anomaly is already in the investigate-now range.${r}`:"medium"===e.severityLabel?`${a} This anomaly looks strong enough for triage or warning workflows.${r}`:`${a} This anomaly is currently better suited to watchlists or dashboard review.${r}`},$e=e=>{const t=[];for(const a of e){const e=t[t.length-1];if(e&&e.time===a.time){const t=e.sampleCount+a.sampleCount;e.value=(e.value*e.sampleCount+a.value*a.sampleCount)/t,e.sampleCount=t,e.minValue=Math.min(e.minValue,a.minValue),e.maxValue=Math.max(e.maxValue,a.maxValue),e.bucketStart=Math.min(e.bucketStart,a.bucketStart),e.bucketEnd=Math.max(e.bucketEnd,a.bucketEnd);continue}t.push(_({},a))}return t},Ne=(e,t)=>{if("raw"===t)return null;if("auto"!==t)return q[t];const a=e.map(e=>e.rawPoints.length).filter(e=>e>0);if(0===a.length)return null;const r=Math.max(...a),n=e.flatMap(e=>e.rawPoints.map(e=>e.time)),i=Math.min(...n),l=Math.max(...n),s=Math.max(l-i,0),o=e.map(e=>(e=>{if(e.length<2)return null;const t=[];for(let a=1;a<e.length&&t.length<120;a+=1){const r=e[a].time-e[a-1].time;r>0&&t.push(r)}return t.length>0?ie(t):null})(e.rawPoints)).filter(e=>null!==e),c=o.length>0?ie(o):null;if(r<=640||s<=0)return null;const d=Math.ceil(s/640),m=c?Math.max(1.5*c,d):d,u=W.find(e=>e>=m);return null!=u?u:W[W.length-1]},Me=(e,t)=>({time:e,value:t,bucketStart:e,bucketEnd:e,sampleCount:1,minValue:t,maxValue:t}),Le=(e,t)=>{const a=Ne(e,t.bucketSpan),r=e.map(e=>{const r=((e,t)=>{if(!t||0===e.length)return $e(e.map(e=>_({},e)));const a=new Map;for(const n of e){var r;const e=Math.floor(n.time/t)*t,i=null!==(r=a.get(e))&&void 0!==r?r:{sum:0,count:0,min:Number.POSITIVE_INFINITY,max:Number.NEGATIVE_INFINITY,end:e+t};i.sum+=n.value,i.count+=n.sampleCount,i.min=Math.min(i.min,n.minValue),i.max=Math.max(i.max,n.maxValue),a.set(e,i)}return[...a.entries()].sort((e,t)=>e[0]-t[0]).map(([e,a])=>({time:e+Math.round(t/2),value:a.sum/a.count,bucketStart:e,bucketEnd:a.end,sampleCount:a.count,minValue:a.min,maxValue:a.max}))})(e.rawPoints,a),n=((e,t)=>B(e,{algorithm:t.algorithm,sensitivity:t.sensitivity,baselineWindow:t.baselineWindow,seasonalitySamples:t.seasonalitySamples,seasonalRefinement:t.seasonalRefinement,severityPreset:t.severityPreset}))(r,t),i=(e=>{if(e.length<=V)return e;const t=new Set,a=(e.length-1)/719;for(let e=0;e<V;e+=1)t.add(Math.round(e*a));return e.forEach((e,a)=>{e.isAnomaly&&t.add(a)}),[...t].sort((e,t)=>e-t).slice(0,V+Math.min(60,e.filter(e=>e.isAnomaly).length)).map(t=>e[t])})(n),l=n.filter(e=>e.isAnomaly),s=l.reduce((e,t)=>ke(e,t),{severityLabel:"normal",severityScore:0});return{key:e.key,label:e.label,color:e.color,points:i,allPoints:n,anomalyCount:l.length,maxScore:l.reduce((e,t)=>Math.max(e,t.score),0),maxSeverityScore:s.severityScore,maxSeverityLabel:s.severityLabel,sourcePointCount:e.rawPoints.length,aggregatedPointCount:r.length,processedPointCount:n.length}});return{analyses:r,effectiveBucketSpanMs:a}},Ae=(e,t)=>"raw"===e?H.raw:"auto"!==e?H[e]:t?`Auto -> ${(e=>{const t=Math.round(e/6e4);if(t<60)return`${t}m`;const a=Math.round(e/36e5*10)/10;return a<24?`${a}h`:Math.round(e/864e5*10)/10+"d"})(t)}`:"Auto -> raw",Ce=(e,t,a,r)=>{let n="";return e.forEach(e=>{const i=r(e);if(null===i||!Number.isFinite(i))return;const l=0===n.length?"M":"L";n+=`${l}${t(e.time).toFixed(2)},${a(i).toFixed(2)} `}),n.trim()},Be=(e,t,a)=>Number.isFinite(e)&&Number.isFinite(t)?a<=1||t===e?[e]:Array.from({length:a},(r,n)=>e+(t-e)*n/(a-1)):[],De=(e,t,a,r=null)=>{if(e.length<=1)return e;const n=[];let i=[],l=Number.NEGATIVE_INFINITY;const s=()=>{if(0===i.length)return;let e=i[0];for(const t of i){if(null!==r&&t.time===r){e=t;break}t.score>e.score&&(e=t)}n.push(e),i=[]};for(const r of e){const e=t(r.time);0!==i.length?e-l<a?i.push(r):(s(),i=[r],l=e):(i=[r],l=e)}if(s(),null!==r&&!n.some(e=>e.time===r)){const t=e.find(e=>e.time===r);t&&(n.push(t),n.sort((e,t)=>e.time-t.time))}return n},Te=(e,t)=>{if(0===e.length)return-1;let a=0,r=Math.abs(e[0]-t);for(let n=1;n<e.length;n+=1){const i=Math.abs(e[n]-t);i<r&&(r=i,a=n)}return a},Pe=(e,t,a=null)=>{var r;if(e.length<=t)return e;const n=null!==a&&null!==(r=e.find(e=>e.time===a))&&void 0!==r?r:null,i=[...e].sort((e,t)=>t.score-e.score||e.time-t.time),l=[];n&&l.push(n);for(const e of i){if(l.length>=t)break;l.some(t=>t.time===e.time)||l.push(e)}return l.sort((e,t)=>e.time-t.time)},_e=(e,t,a)=>"multi"===a.detectionMode?t.filter(e=>e.isAnomaly).sort((e,t)=>t.score-e.score).slice(0,a.maxAnomalies).map((e,t)=>({key:`event-${e.time}-${t}`,time:e.time,title:`Cross-metric incident at ${ce(e.time)}`,subtitle:`${e.activeSeries} metric${1===e.activeSeries?"":"s"} aligned${e.contributors.length>0?` | ${e.contributors.join(", ")}`:""}`,detail:`${J[e.severityLabel]} ${e.severityScore} | ${ee[e.confidenceLabel]} | ${ae[e.dataQualityLabel]}`,score:e.score,severityLabel:e.severityLabel,severityScore:e.severityScore,confidenceScore:e.confidenceScore,confidenceLabel:e.confidenceLabel,dataQualityLabel:e.dataQualityLabel,selection:{kind:"event",time:e.time}})):e.flatMap(e=>(e=>{const t=e.filter(e=>e.isAnomaly).sort((e,t)=>e.time-t.time);if(0===t.length)return[];const a=[];let r=[t[0]];for(let e=1;e<t.length;e+=1){const n=r[r.length-1],i=t[e],l=Math.max(n.bucketEnd-n.bucketStart,1),s=Math.max(i.bucketEnd-i.bucketStart,1),o=1.25*Math.max(l,s);i.bucketStart<=n.bucketEnd+o?r.push(i):(a.push(r),r=[i])}return a.push(r),a})(e.allPoints).map((t,r)=>{const n=t.reduce((e,t)=>t.score>e.score?t:e),i=t[0].bucketStart,l=t[t.length-1].bucketEnd;return{key:`${e.key}-${n.time}-${r}`,time:n.time,title:(s=e.label,o=a.algorithm,c=n.scoreDriver,`${Se(c,o)} in ${s}`),subtitle:t.length>1?`${t.length} consecutive buckets | ${de(i,l)}`:de(i,l),detail:`${J[n.severityLabel]} ${n.severityScore} | ${ee[n.confidenceLabel]} | Current ${le(n.value)} vs expected ${le(n.expected)}`,score:n.score,severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel,selection:{kind:"point",seriesKey:e.key,time:n.time}};var s,o,c})).sort((e,t)=>t.score-e.score).slice(0,a.maxAnomalies),Re=(e,t,a)=>{if(!e)return null;if("point"===e.kind){const a=((e,t)=>{var a;const r=null!==(a=t.find(t=>t.key===e.seriesKey))&&void 0!==a?a:null,n=r?[r,...t.filter(e=>e.key!==r.key)]:t;for(const t of n){const a=t.allPoints.find(t=>t.time===e.time);if(a)return{analysis:t,point:a}}let i=null,l=null;for(const t of n)for(const a of t.allPoints){const r=Math.max(a.bucketEnd-a.bucketStart,1),n=Math.abs(a.time-e.time);a.isAnomaly&&(!l||n<l.distance)&&(l={analysis:t,point:a,distance:n}),n<=1.5*r&&(!i||n<i.distance)&&(i={analysis:t,point:a,distance:n})}const s=null!=i?i:l;return s?{analysis:s.analysis,point:s.point}:null})(e,t);if(!a)return null;const{analysis:r,point:n}=a,i=null===n.expected?null:n.value-n.expected,l=n.expected&&Math.abs(n.expected)>1e-9?i/n.expected*100:null;return{kind:"point",title:`${"window"===n.scoreDriver?"Sustained change":"Sharp change"} in ${r.label}`,subtitle:de(n.bucketStart,n.bucketEnd),seriesKey:r.key,seriesLabel:r.label,color:r.color,time:n.time,bucketStart:n.bucketStart,bucketEnd:n.bucketEnd,actual:n.value,expected:n.expected,deviation:i,deviationPercent:l,rangeLower:n.lower,rangeUpper:n.upper,sampleCount:n.sampleCount,minValue:n.minValue,maxValue:n.maxValue,score:n.score,pointScore:n.pointScore,windowScore:n.windowScore,scoreDriver:n.scoreDriver,severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel}}const r=a.find(t=>t.time===e.time);if(!r)return null;const n=t.map(e=>{const t=e.allPoints.find(e=>e.time===r.time);return t?{label:e.label,color:e.color,actual:t.value,expected:t.expected,deviation:null===t.expected?null:t.value-t.expected,rangeLower:t.lower,rangeUpper:t.upper,score:t.score,pointScore:t.pointScore,windowScore:t.windowScore,scoreDriver:t.scoreDriver,severityLabel:t.severityLabel,severityScore:t.severityScore,confidenceScore:t.confidenceScore,confidenceLabel:t.confidenceLabel,dataQualityLabel:t.dataQualityLabel}:null}).filter(e=>null!==e).sort((e,t)=>t.score-e.score);return{kind:"event",title:`Cross-metric incident at ${ce(r.time)}`,subtitle:de(r.bucketStart,r.bucketEnd),time:r.time,bucketStart:r.bucketStart,bucketEnd:r.bucketEnd,score:r.score,activeSeries:r.activeSeries,contributors:r.contributors,breakdown:n,severityLabel:r.severityLabel,severityScore:r.severityScore,confidenceScore:r.confidenceScore,confidenceLabel:r.confidenceLabel,dataQualityLabel:r.dataQualityLabel}},Oe=e=>{const t=new Set;return e.map(e=>(null!=e?e:"").trim()).filter(e=>!(!e||t.has(e))&&(t.add(e),!0))},Ve=e=>{switch(e){case"warning_first":return 60;case"page_first":return 75;default:return 70}},Ie=e=>Object.entries(e).filter(([,e])=>e.length>0).map(([e,t])=>`${e}=${t}`).join("\n"),qe=(e,t,a)=>{const r=e.document.querySelector(t);if(!r)return!1;const n=r.tagName.toLowerCase();if("input"!==n&&"textarea"!==n)return!1;return r.value=a,r.dispatchEvent(new Event("input",{bubbles:!0})),r.dispatchEvent(new Event("change",{bubbles:!0})),!0},We=e=>{if("undefined"==typeof window)return!1;const t=new URL("/alerting/new",window.location.origin),a=new URLSearchParams(window.location.search).get("orgId");a&&t.searchParams.set("orgId",a),e.dashboardUid&&t.searchParams.set("dashboardUid",e.dashboardUid),e.panelId>0&&t.searchParams.set("panelId",String(e.panelId)),t.searchParams.set("title",e.ruleName),t.searchParams.set("ruleName",e.ruleName),e.folderTitle&&t.searchParams.set("folderTitle",e.folderTitle),t.searchParams.set("dashboardTitle",e.dashboardTitle),t.searchParams.set("panelTitle",e.panelTitle),t.searchParams.set("queryLanguage",e.queryLanguage),t.searchParams.set("threshold",String(e.threshold)),t.searchParams.set("for","10m"),t.searchParams.set("evaluateEvery","3m"),t.searchParams.set("labels",Ie(e.labels)),Object.entries(e.labels).forEach(([e,a])=>{a&&t.searchParams.set(`label_${e}`,a)}),e.alertQuery&&e.alertQuery.length<=1400&&t.searchParams.set("query",e.alertQuery),t.searchParams.set("returnTo",`${window.location.pathname}${window.location.search}`);try{window.sessionStorage.setItem("grafana-anomaly-alert-draft",JSON.stringify(e))}catch(e){}const r=window.open(t.toString(),"_blank");return!!r&&(((e,t)=>{let a=0;const r=()=>{a+=1;try{var n,i;const r=e.document;if(!r||e.closed)return;if(qe(e,'[data-testid="data-testid alert-rule name-field"], input[name="name"], input[placeholder="Give your alert rule a name"]',t.ruleName),qe(e,'input[type="number"]',String(t.threshold)),qe(e,'[data-testid="annotation-value-0"], textarea[name="annotations.0.value"]',null!==(n=t.annotations.summary)&&void 0!==n?n:t.ruleName),qe(e,'[data-testid="annotation-value-1"], textarea[name="annotations.1.value"]',null!==(i=t.annotations.description)&&void 0!==i?i:""),"promql"===t.queryLanguage.toLowerCase()){const n=r.querySelector('input[id^="option-code-radiogroup"]');n&&a<=2&&"function"==typeof n.click&&n.click();const i=['textarea[placeholder*="PromQL"]','textarea[aria-label*="Query"]','textarea[aria-label*="Editor content"]','input[placeholder*="PromQL"]','input[aria-label*="Query"]','textarea[name*="expr"]','input[name*="expr"]'].join(",");qe(e,i,t.alertQuery)}}catch(e){}a<18&&!e.closed&&e.setTimeout(r,450)};e.setTimeout(r,450)})(r,e),!0)},ze=e=>{var t,a;const r=(null!==(t=e.queryLanguage)&&void 0!==t?t:"").toLowerCase(),n=(null!==(a=e.target)&&void 0!==a?a:"").toLowerCase();return"promql"===r||"prometheus"===n||!r&&e.query.includes("grafana_anomaly_rule_score")},je=e=>{if(0===e.length)return"";if(1===e.length)return e[0].query;if(!e.every(ze))return e.map(e=>e.query).join("\n\n");return`max(max_over_time(grafana_anomaly_rule_score{rule=~"${e.map(e=>e.rule.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")}"}[5m]))`},Ue=e=>{if(0===e.length)return"query";const t=Array.from(new Set(e.map(e=>e.queryLanguage).filter(e=>Boolean(e))));return 1===t.length?t[0]:e.every(ze)?"PromQL":"target-specific query"},He=["prometheus","loki","influxdb","postgresql","clickhouse","elasticsearch"],Qe=e=>{const t=String(null!=e?e:"").toLowerCase();return He.includes(t)?t:"prometheus"},Ge=e=>{const t=Qe(e.target);return`${rt[t]}${e.queryLanguage?` (${e.queryLanguage})`:""}`},Ye=(e,t)=>e?"point"===e.kind?`${e.title}. Raw detection score ${le(e.score)}; alert score ${e.severityScore}/100 (${J[e.severityLabel]}). Current ${le(e.actual)} vs expected ${le(e.expected)}.`:`${e.title}. Raw detection score ${le(e.score)} across ${e.activeSeries} active series; alert score ${e.severityScore}/100 (${J[e.severityLabel]}): ${e.contributors.slice(0,4).join(", ")}.`:`Anomaly score alert for ${t}.`,Ke=e=>e.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"")||"metric",Ze=(e,t,a,r)=>{if(!e)return null;const n=Oe(["anomaly-detector",e.severityLabel,e.confidenceLabel,e.dataQualityLabel,Ke(r),e.kind]),i={time:e.bucketStart,tags:n,text:""};if(a&&(i.dashboardUID=a,i.dashboardUid=a),t>0&&(i.panelId=t),e.bucketEnd>e.bucketStart&&(i.timeEnd=e.bucketEnd,i.isRegion=!0),"point"===e.kind){const t=Ke(e.seriesLabel);return n.includes(t)||n.push(t),i.text=[e.title,`Window: ${de(e.bucketStart,e.bucketEnd)}`,`Raw detection score: ${le(e.score)}`,`Alert score (0-100): ${J[e.severityLabel]} ${e.severityScore}`,`Confidence: ${ee[e.confidenceLabel]} (${le(e.confidenceScore)})`,`Data quality: ${ae[e.dataQualityLabel]}`,`Actual: ${le(e.actual)} | Expected: ${le(e.expected)}`,`Deviation: ${le(e.deviation)}${null===e.deviationPercent?"":` (${le(e.deviationPercent)}%)`}`,`Expected range: ${le(e.rangeLower)} to ${le(e.rangeUpper)}`].join("\n"),i}return i.text=[e.title,`Window: ${de(e.bucketStart,e.bucketEnd)}`,`Raw detection score: ${le(e.score)}`,`Alert score (0-100): ${J[e.severityLabel]} ${e.severityScore}`,`Confidence: ${ee[e.confidenceLabel]} (${le(e.confidenceScore)})`,`Data quality: ${ae[e.dataQualityLabel]}`,`Active series: ${e.activeSeries}`,`Top contributors: ${e.contributors.join(", ")||"No contributors found"}`].join("\n"),i},Je=e=>T(function*(){var t;if("undefined"!=typeof navigator&&(null===(t=navigator.clipboard)||void 0===t?void 0:t.writeText))try{return void(yield Promise.race([navigator.clipboard.writeText(e),new Promise((e,t)=>{("undefined"!=typeof window?window.setTimeout:setTimeout)(()=>t(new Error("Clipboard API timed out.")),900)})]))}catch(e){}if("undefined"==typeof document)throw new Error("Clipboard access is not available in this environment.");const a=document.createElement("textarea");a.value=e,a.setAttribute("readonly","true"),a.style.position="fixed",a.style.opacity="0",document.body.appendChild(a),a.select();const r=document.execCommand("copy");if(document.body.removeChild(a),!r)throw new Error("The browser blocked clipboard access.")})(),Xe=(e,t)=>{if(e&&"object"==typeof e){const t=e,a=t.data,r=a&&"object"==typeof a?a:null,n="string"==typeof(null==r?void 0:r.message)&&r.message||"string"==typeof t.statusText&&t.statusText||"string"==typeof t.message&&t.message||"",i="number"!=typeof t.status||String(n).includes(String(t.status))?"":` (HTTP ${t.status})`;if(n)return`${n}${i}`}return e instanceof Error&&e.message?e.message:t},et=e=>T(function*(){try{yield(0,h.getBackendSrv)().post("/api/annotations",e)}catch(e){throw new Error(Xe(e,"Failed to create the Grafana annotation."))}})(),tt="http://127.0.0.1:9110",at={off:"Off",manual:"Manual sync",auto:"Auto sync"},rt={prometheus:"Prometheus metrics",loki:"Loki",influxdb:"InfluxDB",postgresql:"PostgreSQL",clickhouse:"ClickHouse",elasticsearch:"Elasticsearch"},nt={prometheus:"Prometheus",loki:"Loki",influxdb:"InfluxDB",postgresql:"PostgreSQL",clickhouse:"ClickHouse",elasticsearch:"Elastic"},it={prometheus:"#94A3B8",loki:"#F59E0B",influxdb:"#3B82F6",postgresql:"#60A5FA",clickhouse:"#FACC15",elasticsearch:"#22D3EE"},lt=e=>nt[Qe(e)],st=({target:e})=>{switch(Qe(e)){case"loki":return m().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},m().createElement("path",{d:"M7 20V7.6l3.3-.9V20H7Z",fill:"#D97706"}),m().createElement("path",{d:"M11.3 20V3.8l3.4-.9V20h-3.4Z",fill:"#F59E0B"}),m().createElement("path",{d:"M15.8 20V10.2l3.2-.86V20h-3.2Z",fill:"#FBBF24"}),m().createElement("path",{d:"M5.2 20.4h15.1",stroke:"#B45309",strokeWidth:"1.8",strokeLinecap:"round"}));case"influxdb":return m().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},m().createElement("path",{d:"M12 2.8 20 7.3v9.4l-8 4.5-8-4.5V7.3l8-4.5Z",fill:"none",stroke:"#3B82F6",strokeWidth:"1.8"}),m().createElement("path",{d:"m12 2.8 3.9 7.1L12 21.2 8.1 9.9 12 2.8Z",fill:"none",stroke:"#60A5FA",strokeWidth:"1.3"}),m().createElement("path",{d:"M4 7.3 12 12l8-4.7M4 16.7 12 12l8 4.7",fill:"none",stroke:"#2563EB",strokeWidth:"1.2"}));case"postgresql":return m().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},m().createElement("path",{d:"M6.2 10.6c0-4.4 2.4-7 6.1-7 3.9 0 6.5 2.7 6.5 7 0 2.9-1.2 5.1-3.3 6.3l.3 3.1-2.9-1.8c-.8.15-1.7.15-2.6-.03L7.2 20l.43-3.35c-.95-.7-1.43-2.55-1.43-6.05Z",fill:"#3B82F6",opacity:"0.9"}),m().createElement("path",{d:"M9 10.1c.45-.5 1.25-.5 1.7 0M14 10.1c.45-.5 1.25-.5 1.7 0",stroke:"#DBEAFE",strokeWidth:"1.2",strokeLinecap:"round"}),m().createElement("path",{d:"M12.8 11.3c-.4 1.2-.15 2.1.75 2.7.85.6.95 1.55.15 2.45",fill:"none",stroke:"#DBEAFE",strokeWidth:"1.3",strokeLinecap:"round"}));case"clickhouse":return m().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},m().createElement("path",{d:"M4 4h3v16H4V4Zm5 0h3v16H9V4Zm5 0h3v16h-3V4Z",fill:"#FACC15"}),m().createElement("path",{d:"M19 4h1.8v16H19V4Z",fill:"#EF4444"}));case"elasticsearch":return m().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},m().createElement("circle",{cx:"9",cy:"7",r:"4",fill:"#F59E0B"}),m().createElement("circle",{cx:"15.2",cy:"7.7",r:"3.3",fill:"#22C55E"}),m().createElement("circle",{cx:"16.1",cy:"14.8",r:"4",fill:"#06B6D4"}),m().createElement("circle",{cx:"8.2",cy:"15.5",r:"3.5",fill:"#EF4444"}),m().createElement("circle",{cx:"12",cy:"11.5",r:"3.3",fill:"#64748B",opacity:"0.72"}));default:return m().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},m().createElement("ellipse",{cx:"12",cy:"5.4",rx:"7.2",ry:"3.1",fill:"#64748B"}),m().createElement("path",{d:"M4.8 5.4v4.5c0 1.7 3.2 3.1 7.2 3.1s7.2-1.4 7.2-3.1V5.4",fill:"#475569"}),m().createElement("ellipse",{cx:"12",cy:"9.9",rx:"7.2",ry:"3.1",fill:"#94A3B8"}),m().createElement("path",{d:"M4.8 9.9v4.5c0 1.7 3.2 3.1 7.2 3.1s7.2-1.4 7.2-3.1V9.9",fill:"#475569"}),m().createElement("ellipse",{cx:"12",cy:"14.4",rx:"7.2",ry:"3.1",fill:"#CBD5E1"}))}},ot=e=>m().createElement(st,{target:e}),ct=e=>(null!=e?e:tt).trim().replace(/\/+$/,"")||tt,dt=e=>e.trim().toLowerCase().replace(/[^a-z0-9_]+/g,"_").replace(/^_+|_+$/g,"")||"anomaly_panel",mt=(e,t)=>{const a=dt(e||"anomaly_panel"),r=dt(null!=t?t:"");return r?`${r}_${a}`:a},ut=()=>{var e;if("undefined"==typeof window)return"";const t=window.location.pathname.match(/\/d\/([^/]+)/);return null!==(e=null==t?void 0:t[1])&&void 0!==e?e:""},pt=()=>"undefined"==typeof document?"":document.title.replace(/\s+-\s+Grafana$/i,"").replace(/^View panel\s+-\s+/i,"").replace(/^Edit panel\s+-\s+/i,"").replace(/\s+-\s+Dashboards$/i,"").trim(),ht=()=>{if("undefined"==typeof document)return"";const e=Array.from(document.querySelectorAll('nav[aria-label="Breadcrumbs"] a')).map(e=>{var t,a;return null!==(t=null===(a=e.textContent)||void 0===a?void 0:a.trim())&&void 0!==t?t:""}).filter(Boolean);return e.length>=3&&"dashboards"===e[0].toLowerCase()?e[1]:""},gt=(e,t)=>{const a=e.trim(),r=t.trim().toLowerCase();return a&&("postgres"!==r&&"postgresql"!==r&&!r.includes("postgresql")||/^postgres(?:ql)?:\/\//i.test(a))?a:""},ft=e=>e.flatMap((e,t)=>{var a,r,n,i,l,s,o,c,d,m,u,p,h,g,f,y,b,v;if(!e||"object"!=typeof e)return[];const x=e;if(!0===x.hide)return[];const w=(e=>{var t,a,r,n;if("string"==typeof e)return{uid:e,type:"",url:""};if(!e||"object"!=typeof e)return{uid:"",type:"",url:""};const i=e;return{uid:String(null!==(t=null!==(a=i.uid)&&void 0!==a?a:i.name)&&void 0!==t?t:""),type:String(null!==(r=i.type)&&void 0!==r?r:""),url:String(null!==(n=i.url)&&void 0!==n?n:"")}})(x.datasource),E=String(null!==(a=null!==(r=x.datasourceUid)&&void 0!==r?r:w.uid)&&void 0!==a?a:"").trim(),k=String(null!==(n=null!==(i=x.datasourceType)&&void 0!==i?i:w.type)&&void 0!==n?n:"").trim().toLowerCase(),S=gt(String(null!==(l=null!==(s=null!==(o=x.datasourceUrl)&&void 0!==o?o:x.url)&&void 0!==s?s:w.url)&&void 0!==l?l:"").trim(),k),F=String(null!==(c=null!==(d=null!==(m=null!==(u=null!==(p=x.expr)&&void 0!==p?p:x.expression)&&void 0!==u?u:x.query)&&void 0!==m?m:x.rawSql)&&void 0!==d?d:x.rawQuery)&&void 0!==c?c:"").trim(),$="elasticsearch"===k&&(x.metrics||x.bucketAggs||x.timeField)?JSON.stringify({query:F,metrics:null!==(h=x.metrics)&&void 0!==h?h:[],bucketAggs:null!==(g=x.bucketAggs)&&void 0!==g?g:[],timeField:null!==(f=x.timeField)&&void 0!==f?f:"@timestamp"}):F;return $?"__expr__"===E||"__expr__"===k||"expression"===k?[]:[{refId:String(null!==(y=x.refId)&&void 0!==y?y:`Q${t+1}`).trim()||`Q${t+1}`,expr:$,legend:String(null!==(b=null!==(v=x.legendFormat)&&void 0!==v?v:x.legend)&&void 0!==b?b:"").trim(),datasourceUid:E,datasourceType:k,datasourceUrl:S}]:[]}).filter((e,t,a)=>a.findIndex(t=>t.refId===e.refId&&t.expr===e.expr)===t),yt=(e,t)=>T(function*(){if(!e||"__expr__"===e||"undefined"==typeof fetch)return"";try{var a,r;const n=yield fetch(`/api/datasources/uid/${encodeURIComponent(e)}`,{credentials:"same-origin"});if(!n.ok)return"";const i=yield n.json();return gt(String(null!==(a=i.url)&&void 0!==a?a:"").trim(),String(null!==(r=i.type)&&void 0!==r?r:t))}catch(e){return""}})(),bt=e=>T(function*(){if(0===e.length)return e;const t=Array.from(new Set(e.filter(e=>!e.datasourceUrl&&e.datasourceUid).map(e=>`${e.datasourceUid}:::${e.datasourceType}`))),a=yield Promise.all(t.map(e=>T(function*(){const[t,a]=e.split(":::");return[t,yield yt(t,a)]})())),r=new Map(a);return e.map(e=>R(_({},e),{datasourceUrl:e.datasourceUrl||r.get(e.datasourceUid)||""}))})(),vt=e=>{const t=[];return e.forEach(e=>{if(!e||"object"!=typeof e)return;const a=e;void 0!==a.id&&t.push(a),Array.isArray(a.panels)&&t.push(...vt(a.panels))}),t},xt=(e,t)=>T(function*(){var a,r,n,i,l,s,o,c;const d=ut();if(!d||"undefined"==typeof fetch)return null;const m=yield fetch(`/api/dashboards/uid/${encodeURIComponent(d)}`,{credentials:"same-origin"});if(!m.ok)throw new Error(`Could not read the saved dashboard definition (${m.status}).`);const u=yield m.json(),p=null!==(a=u.dashboard)&&void 0!==a?a:{},h=String(null!==(r=null!==(n=null===(c=u.meta)||void 0===c?void 0:c.folderTitle)&&void 0!==n?n:ht())&&void 0!==r?r:"").trim(),g=vt(Array.isArray(p.panels)?p.panels:[]).find(t=>{var a;return Number(null!==(a=t.id)&&void 0!==a?a:-1)===e});if(!g)return null;const f=yield bt(ft(Array.isArray(g.targets)?g.targets:[]));return{source:"saved",dashboardUid:d,folderTitle:h,dashboardTitle:String(null!==(i=null!==(l=p.title)&&void 0!==l?l:pt())&&void 0!==i?i:d).trim()||d,panelTitle:String(null!==(s=g.title)&&void 0!==s?s:t).trim()||t,targets:f,panelOptions:null!==(o=g.options)&&void 0!==o?o:{}}})(),wt=(e,t,a,r)=>{var n,i;return JSON.stringify({dashboardUid:e.dashboardUid,panelTitle:e.panelTitle,source:e.source,ruleNamePrefix:a,target:r,rangeSeconds:null!==(n=e.rangeSeconds)&&void 0!==n?n:0,stepSeconds:null!==(i=e.stepSeconds)&&void 0!==i?i:0,targets:e.targets.map(e=>{var t;return{refId:e.refId,expr:e.expr,datasourceUid:e.datasourceUid,datasourceType:e.datasourceType,datasourceUrl:null!==(t=e.datasourceUrl)&&void 0!==t?t:""}}),resolvedOptions:{setupMode:t.setupMode,metricPreset:t.metricPreset,effectiveMetricPreset:t.effectiveMetricPreset,detectionMode:t.detectionMode,algorithm:t.algorithm,sensitivity:t.sensitivity,baselineWindow:t.baselineWindow,seasonalitySamples:t.seasonalitySamples,seasonalRefinement:t.seasonalRefinement,severityPreset:t.severityPreset}})},Et=e=>{switch(e){case"1m":return 60;case"5m":return 300;case"15m":return 900;case"1h":return 3600;default:return 0}},kt=(e,t,a,r,n,i)=>{var l,s;const o=e.targets.filter(e=>e.expr.trim().length>0);if(0===o.length)return null;const c=Et(n.bucketSpan),d=Math.max(0,Math.round(null!==(l=e.stepSeconds)&&void 0!==l?l:0)),m=d>0?d:c>0?Math.max(5,Math.min(c,60)):30,u=Math.max(256,n.baselineWindow*Math.max(n.seasonalitySamples,1)+8,6*n.baselineWindow),p=Math.max(0,Math.round(null!==(s=e.rangeSeconds)&&void 0!==s?s:0)),h=Math.max(3600,u*m);return{dashboardUid:e.dashboardUid,folderTitle:e.folderTitle,dashboardTitle:e.dashboardTitle,panelId:t,panelTitle:e.panelTitle,ruleNamePrefix:mt(e.panelTitle,a),target:r,source:e.source,syncHash:i,targets:o.map(e=>{var t;return{refId:e.refId,expr:e.expr,legend:e.legend,datasourceUid:e.datasourceUid,datasourceType:e.datasourceType,datasourceUrl:null!==(t=e.datasourceUrl)&&void 0!==t?t:""}}),resolvedOptions:{setupMode:n.setupMode,metricPreset:n.metricPreset,effectiveMetricPreset:n.effectiveMetricPreset,detectionMode:n.detectionMode,algorithm:n.algorithm,sensitivity:n.sensitivity,baselineWindow:n.baselineWindow,seasonalitySamples:n.seasonalitySamples,seasonalRefinement:n.seasonalRefinement,severityPreset:n.severityPreset,rangeSeconds:p>0?Math.max(4*m,p):h,stepSeconds:m,bucketSpanSeconds:c}}},St=e=>"off"===e?{kind:"off",message:"Anomaly score feed is turned off for this panel.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}:"manual"===e?{kind:"idle",message:"Manual sync is ready. Use the button to publish plugin-computed anomaly scores for this panel.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}:{kind:"idle",message:"Auto sync watches this panel and republishes plugin-computed anomaly scores shortly after data is returned.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""},Ft=e=>{switch(e){case"synced":return"Synced";case"syncing":return"Syncing";case"error":return"Error";case"unsupported":return"Action needed";case"off":return"Off";default:return"Ready"}},$t=({panelId:e,panelTitle:t,options:a,resolvedOptions:r,liveTargets:n,analyses:i,timeRangeSeconds:l,queryStepSeconds:s})=>{var o;const[c,m]=(0,d.useState)(()=>{var e;return St(null!==(e=a.scoreFeedMode)&&void 0!==e?e:"auto")}),[u,p]=(0,d.useState)(""),h=null!==(o=a.scoreFeedMode)&&void 0!==o?o:"auto",g=(0,d.useCallback)((o="manual")=>T(function*(){var c;if("off"!==h)try{var d,g,f,y,b,v,x,w;let h=((e,t,a,r,n)=>({source:"live",dashboardUid:ut()||"local_dashboard",folderTitle:ht(),dashboardTitle:pt()||"Grafana dashboard",panelTitle:t,targets:a,panelOptions:{},rangeSeconds:r,stepSeconds:n}))(0,t,n,l,s),E=a,k=ct(a.scoreFeedEndpoint);if("auto"===o){const r=yield xt(e,t).catch(()=>null);r&&(E=_({},a,r.panelOptions),h=R(_({},r),{targets:n.length>0?n:r.targets,source:n.length>0?"live":r.source,rangeSeconds:l,stepSeconds:s}),k=ct(E.scoreFeedEndpoint))}const S=null!==(d="auto"===o?E.scoreFeedRuleNamePrefix:a.scoreFeedRuleNamePrefix)&&void 0!==d?d:"",F=Qe("auto"===o?E.scoreFeedTarget:a.scoreFeedTarget);h=R(_({},h),{targets:yield bt(h.targets),rangeSeconds:l,stepSeconds:s});const $=wt(h,r,S,F),N=kt(h,e,S,F,r,$),M=((e,t,a,r,n,i)=>{const l=i.flatMap(e=>{var t;const a=null!==(t=[...e.allPoints].reverse().find(e=>null!==e.expected))&&void 0!==t?t:e.allPoints[e.allPoints.length-1];return a?[{key:e.key,label:e.label,timestamp:a.time/1e3,value:a.value,expected:a.expected,lower:a.lower,upper:a.upper,deviation:null===a.expected?null:a.value-a.expected,rawScore:a.score,pointRawScore:a.pointScore,windowRawScore:a.windowScore,scoreDriver:a.scoreDriver,normalizedScore:a.severityScore,severityLabel:a.severityLabel,isAnomaly:a.isAnomaly,confidenceScore:a.confidenceScore,confidenceLabel:a.confidenceLabel,dataQualityLabel:a.dataQualityLabel,threshold:n.sensitivity}]:[]});if(0===l.length)return null;const s=[...l].sort((e,t)=>t.normalizedScore-e.normalizedScore)[0],o=Array.from(new Map(e.targets.map(e=>[`${e.datasourceUid||"unknown"}:${e.datasourceType||"unknown"}`,{uid:e.datasourceUid||"unknown",type:e.datasourceType||"unknown"}])).values());return{dashboardUid:e.dashboardUid,folderTitle:e.folderTitle,dashboardTitle:e.dashboardTitle,panelId:t,panelTitle:e.panelTitle,ruleName:mt(e.panelTitle,a),target:r,source:e.source,sourceDatasources:o,series:l,rule:{timestamp:Math.max(...l.map(e=>e.timestamp)),score:s.normalizedScore,rawScore:s.rawScore,breachCount:l.filter(e=>e.isAnomaly).length,seriesCount:l.length,activeSeries:l.length,severityLabel:s.severityLabel},resolvedOptions:{algorithm:n.algorithm,severityPreset:n.severityPreset,sensitivity:n.sensitivity}}})(h,e,S,F,r,i);if(!N&&!M)return void m((c="This panel has no query target or computed anomaly score points to publish yet. Refresh the panel after data is returned.",{kind:"unsupported",message:c,source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}));const L=JSON.stringify({registrationHash:$,target:F,ruleName:null!==(g=null!==(f=null==M?void 0:M.ruleName)&&void 0!==f?f:null==N?void 0:N.ruleNamePrefix)&&void 0!==g?g:"",ruleScore:null!==(y=null==M?void 0:M.rule.score)&&void 0!==y?y:null,ruleTimestamp:null!==(b=null==M?void 0:M.rule.timestamp)&&void 0!==b?b:null,series:null!==(v=null==M?void 0:M.series.map(e=>[e.key,e.timestamp,e.normalizedScore,e.isAnomaly]))&&void 0!==v?v:[],algorithm:r.algorithm,severityPreset:r.severityPreset});if("auto"===o&&L===u)return void m(e=>R(_({},e),{kind:"error"===e.kind?e.kind:"synced",message:null!==e.lastSyncedAt?e.message:`Auto sync is active. Latest plugin-computed scores are published to ${rt[F]}.`,source:h.source,syncHash:L}));m(e=>{var t;return R(_({},e),{kind:"syncing",message:"auto"===o?`Registering panel score feed and publishing latest scores to ${rt[F]}.`:`Registering panel score feed and publishing scores to ${rt[F]}.`,source:null!==(t=null==h?void 0:h.source)&&void 0!==t?t:e.source})});let A={};if(N){const e=yield fetch(`${k}/api/sync/panel`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(N)});if(A=yield e.json(),!e.ok)throw new Error(A.error||`Panel registration failed with status ${e.status}.`)}let C={};if(M){const e=yield fetch(`${k}/api/feed/scores`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(M)});if(C=yield e.json(),!e.ok)throw new Error(C.error||`Sync failed with status ${e.status}.`)}const B=((e,t)=>{const a=new Map;return e.forEach(e=>{var t;return a.set(`${e.rule}:${null!==(t=e.target)&&void 0!==t?t:""}`,e)}),t.forEach(e=>{var t;return a.set(`${e.rule}:${null!==(t=e.target)&&void 0!==t?t:""}`,e)}),Array.from(a.values())})(Array.isArray(C.registered)?C.registered:[],Array.isArray(A.registered)?A.registered:[]),D=[...Array.isArray(A.removed)?A.removed:[],...Array.isArray(C.removed)?C.removed:[]],T="saved"===h.source?"saved dashboard":"live panel",P=Math.max(0,Math.round(null!==(x=null!==(w=C.acceptedSeries)&&void 0!==w?w:null==M?void 0:M.series.length)&&void 0!==x?x:B.length));p(L),m({kind:"synced",message:B.length>0?M?`Published ${P} plugin-computed score series and registered backend recompute from the ${T} to ${rt[F]}.`:`Registered backend recompute from the ${T} to ${rt[F]}; scores will continue while the dashboard is closed.`:D.length>0?`Removed ${D.length} previous score feed registration${1===D.length?"":"s"} because this panel no longer exposes computed score data.`:`Score feed is active for this panel and targets ${rt[F]}.`,source:h.source,registered:B,removed:D,lastSyncedAt:Date.now(),syncHash:L})}catch(e){m(t=>R(_({},t),{kind:"error",message:e instanceof Error?e.message:"Score feed sync failed unexpectedly."}))}else m(St("off"))})(),[i,n,u,a,e,t,s,r,h,l]);return(0,d.useEffect)(()=>{if("off"===h)return void m(St("off"));if("manual"===h)return void m(e=>_({},"synced"===e.kind?e:R(_({},St("manual")),{source:e.source,registered:e.registered,removed:e.removed,lastSyncedAt:e.lastSyncedAt,syncHash:e.syncHash})));if("undefined"==typeof window)return;let e=!1,t=!1;const a=()=>T(function*(){if(!e&&!t){t=!0;try{yield g("auto")}finally{t=!1}}})();a();const r=window.setInterval(()=>{a()},15e3);return()=>{e=!0,window.clearInterval(r)}},[g,h]),R(_({},c),{syncNow:()=>g("manual")})},Nt=["Configuration"],Mt=["Anomaly score feed"],Lt=["Analysis"],At=["Advanced tuning"],Ct=["Display"],Bt=[{label:"Recommended",value:"recommended",description:"Pick the metric type and let the plugin choose the algorithm and severity tuning."},{label:"Advanced",value:"advanced",description:"Expose manual algorithm, threshold, and severity controls."}],Dt=[{label:"Single metric",value:"single"},{label:"Multi metric",value:"multi"}],Tt=[{label:"Auto sync (Recommended)",value:"auto",description:"Continuously publish plugin-computed anomaly scores to the selected score feed target."},{label:"Manual sync",value:"manual",description:"Show a sync button so users can publish the current plugin-computed score snapshot on demand."},{label:"Off",value:"off",description:"Disable anomaly score feed publishing for this panel."}],Pt=[{label:"Prometheus metrics",value:"prometheus",description:"Expose the plugin-computed anomaly scores from the exporter /metrics endpoint."},{label:"Loki",value:"loki",description:"Write plugin-computed anomaly scores to the Loki sink."},{label:"InfluxDB",value:"influxdb",description:"Write plugin-computed anomaly scores to the InfluxDB sink."},{label:"PostgreSQL",value:"postgresql",description:"Write plugin-computed anomaly scores to the PostgreSQL sink."},{label:"ClickHouse",value:"clickhouse",description:"Write plugin-computed anomaly scores to the ClickHouse sink."},{label:"Elasticsearch",value:"elasticsearch",description:"Write plugin-computed anomaly scores to the Elasticsearch sink."}],_t=[{label:"Auto (Recommended)",value:"auto",description:"Inspect the metric names and choose the safest starting algorithm automatically."},{label:"Traffic / throughput",value:"traffic",description:"Good starting point for request rate, throughput, and volume metrics."},{label:"Latency / duration",value:"latency",description:"Tuned for latency, p95, and response-time style metrics."},{label:"Error rate",value:"error_rate",description:"Tuned for error percentage and error-count spikes."},{label:"Resource usage",value:"resource",description:"Useful for CPU, memory, load, saturation, and host metrics."},{label:"Business KPI",value:"business",description:"Useful for revenue, signups, conversions, and other cyclical business metrics."},{label:"Subtle level shift / drift",value:"level_shift",description:"Best when the baseline changes gradually or steps up/down without a single sharp spike."}],Rt=[{label:"Auto",value:"auto",description:"Choose an efficient pre-aggregation span automatically on dense or live data."},{label:"Raw samples",value:"raw",description:"Analyze every incoming sample without pre-aggregation."},{label:"1 minute",value:"1m",description:"Aggregate close samples into 1-minute buckets before scoring."},{label:"5 minutes",value:"5m",description:"Aggregate samples into 5-minute buckets before scoring."},{label:"15 minutes",value:"15m",description:"Aggregate samples into 15-minute buckets before scoring."},{label:"1 hour",value:"1h",description:"Aggregate samples into 1-hour buckets before scoring."}],Ot=[{label:"Rolling z-score",value:"zscore",description:"Fast default for spikes and dips in streaming metrics."},{label:"Rolling MAD",value:"mad",description:"Robust against noisy outliers and uneven distributions."},{label:"EWMA baseline",value:"ewma",description:"Tracks gradual baseline shifts while still catching sudden jumps."},{label:"Seasonal baseline",value:"seasonal",description:"Compares each point with similar positions from earlier cycles."},{label:"Level shift detector",value:"level_shift",description:"Looks for sustained baseline changes and subtle step-ups that build over several buckets."}],Vt=[{label:"Cycle only",value:"cycle",description:"Uses a fixed sample lag such as 24 or 288 samples."},{label:"Hour of day",value:"hour_of_day",description:"Matches earlier values from the same hour bucket."},{label:"Weekday + hour",value:"weekday_hour",description:"Matches earlier values from the same weekday and hour bucket."}],It=[{label:"Balanced",value:"balanced",description:"General-purpose default for dashboards and alert handoff."},{label:"Warning first",value:"warning_first",description:"Promotes warning and medium severity earlier for watchlist-heavy teams."},{label:"Page first",value:"page_first",description:"Keeps high and critical severities stricter for paging workflows."}],qt=[{label:"Auto (Recommended)",value:"auto",description:"Choose a readable time tick density automatically from the panel width and visible range."},{label:"Compact",value:"compact",description:"Use fewer time labels for dense dashboards and smaller panels."},{label:"Balanced",value:"balanced",description:"Keep a mid-density time axis for general dashboard use."},{label:"Dense",value:"dense",description:"Show more time labels for close operational tracking."}],Wt=[{label:"Bottom only",value:"bottom",description:"Show time labels only on the bottom axis."},{label:"Top + bottom",value:"top_and_bottom",description:"Add a second time guide on top for faster cross-checking during incident review."}],zt=[{label:"Severity shapes (Recommended)",value:"severity",description:"Use different marker shapes for low, medium, high, and critical anomalies."},{label:"Classic circles",value:"classic",description:"Keep the previous circle-style anomaly markers."}],jt=new c.PanelPlugin(({id:e,options:t,data:a,width:r,height:n,timeRange:i,timeZone:l})=>{var s,o,h,g,f,y,b,v,x,w,E,k,S,F,$,N;const M=(0,p.useTheme2)(),L=(A=M.isDark,{wrapper:u.css`
    width: 100%;
    height: 100%;
    min-height: 0;
    container-type: inline-size;
    padding: 10px;
    box-sizing: border-box;
    overflow: auto;
    font-family: 'Segoe UI', sans-serif;
    color: ${A?"#F3F4F6":"#111827"};
    background: ${A?"radial-gradient(circle at 8% 0%, rgba(220,38,38,0.12), transparent 26%), linear-gradient(180deg, #060A12 0%, #0B111C 100%)":"linear-gradient(180deg, #F8FAFC 0%, #EEF4FF 100%)"};
  `,operationalCanvas:u.css`
    width: 100%;
    min-height: 100%;
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(300px, 360px);
    gap: 12px;
    align-items: stretch;
    @media (max-width: 1100px) {
      grid-template-columns: 1fr;
    }
    @container (max-width: 1040px) {
      grid-template-columns: 1fr;
    }
  `,workspacePane:u.css`
    min-width: 0;
    min-height: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,inspectorRail:u.css`
    min-width: 0;
    min-height: 0;
    @media (min-width: 1101px) {
      position: sticky;
      top: 0;
      align-self: start;
      max-height: calc(100vh - 24px);
      overflow: auto;
    }
    @container (max-width: 1040px) {
      position: static;
      max-height: none;
      overflow: visible;
    }
  `,header:u.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
  `,statusHeader:u.css`
    position: relative;
    display: grid;
    grid-template-columns: minmax(260px, 0.9fr) minmax(340px, 1.1fr);
    gap: 18px;
    align-items: stretch;
    padding: 14px 16px 14px 22px;
    border-radius: 18px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(135deg, rgba(17,24,39,0.94) 0%, rgba(12,18,29,0.98) 62%, rgba(8,13,22,0.98) 100%)":"linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%)"};
    overflow: hidden;
    box-shadow: ${A?"0 22px 70px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.04)":"0 16px 34px rgba(15,23,42,0.06)"};
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
  `,statusRail:u.css`
    position: absolute;
    inset: 0 auto 0 0;
    width: 5px;
    border-radius: 18px 0 0 18px;
  `,statusMain:u.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 10px;
    padding-left: 48px;
    @media (max-width: 700px) {
      padding-left: 34px;
    }
  `,statusIcon:u.css`
    position: absolute;
    left: 18px;
    top: 50%;
    width: 30px;
    height: 30px;
    transform: translateY(-50%);
    display: grid;
    place-items: center;
    border-radius: 999px;
    color: #FCA5A5;
    border: 1px solid rgba(248,113,113,0.62);
    background: rgba(127,29,29,0.22);
    box-shadow: 0 0 0 5px rgba(220,38,38,0.08);
  `,statusIconSvg:u.css`
    width: 18px;
    height: 18px;
    overflow: visible;
  `,statusTitleRow:u.css`
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
  `,statusBadge:u.css`
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 6px 10px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    border: 1px solid currentColor;
  `,statusDot:u.css`
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: currentColor;
    box-shadow: 0 0 0 3px ${A?"rgba(148,163,184,0.18)":"rgba(15,23,42,0.10)"};
  `,titleBlock:u.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
  `,title:u.css`
    font-size: clamp(22px, 1.65vw, 30px);
    font-weight: 800;
    letter-spacing: 0.01em;
  `,subtitle:u.css`
    font-size: 12px;
    color: ${A?"#94A3B8":"#475569"};
    line-height: 1.5;
  `,headerMetaGrid:u.css`
    display: grid;
    grid-template-columns: repeat(2, minmax(140px, max-content));
    gap: 8px 24px;
    color: ${A?"#C7D2E4":"#334155"};
    font-size: 12px;
    font-weight: 700;
    @media (max-width: 700px) {
      grid-template-columns: 1fr;
    }
  `,metaAccent:u.css`
    color: #F87171;
    font-weight: 900;
  `,recommendationBanner:u.css`
    display: none;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 12px;
    border-radius: 14px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
  `,recommendationBadge:u.css`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 78px;
    padding: 6px 10px;
    border-radius: 999px;
    background: ${A?"#172554":"#DBEAFE"};
    color: ${A?"#BFDBFE":"#1D4ED8"};
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
  `,recommendationCopy:u.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  `,recommendationTitle:u.css`
    font-size: 13px;
    font-weight: 700;
    color: ${A?"#F8FAFC":"#0F172A"};
  `,recommendationText:u.css`
    font-size: 12px;
    line-height: 1.55;
    color: ${A?"#CBD5E1":"#334155"};
  `,stats:u.css`
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
  `,statusStats:u.css`
    display: grid;
    grid-template-columns: 1.18fr repeat(3, minmax(82px, 1fr));
    gap: 10px;
    align-content: stretch;
    min-width: 0;
    @media (max-width: 700px) {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  `,statCard:u.css`
    min-width: 0;
    padding: 12px 13px;
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.12)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(30,41,59,0.62), rgba(15,23,42,0.82))":"#F8FAFC"};
    box-shadow: ${A?"inset 0 1px 0 rgba(255,255,255,0.04)":"none"};
  `,statCardPrimary:u.css`
    border-color: rgba(248,113,113,0.38);
    background: linear-gradient(145deg, #B91C1C 0%, #7F1D1D 100%);
    color: #FFFFFF !important;
    box-shadow: 0 12px 26px rgba(220,38,38,0.22), inset 0 1px 0 rgba(255,255,255,0.12);
  `,statLabel:u.css`
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: ${A?"#94A3B8":"#64748B"};
  `,statValue:u.css`
    margin-top: 6px;
    font-size: clamp(18px, 1.35vw, 22px);
    font-weight: 850;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  `,statCaption:u.css`
    margin-top: 3px;
    font-size: 11px;
    color: ${A?"#94A3B8":"#64748B"};
    font-weight: 800;
  `,chartCard:u.css`
    flex: 1 1 auto;
    min-height: clamp(340px, 45vh, 520px);
    position: relative;
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, #0A1321 0%, #07101D 100%)":"#FFFFFF"};
    overflow: hidden;
    box-shadow: ${A?"inset 0 1px 0 rgba(255,255,255,0.04), 0 18px 44px rgba(0,0,0,0.22)":"0 14px 28px rgba(15,23,42,0.05)"};
    outline: none;
    &:focus-visible {
      border-color: ${A?"#60A5FA":"#2563EB"};
      box-shadow: ${A?"0 0 0 1px rgba(96,165,250,0.55), inset 0 1px 0 rgba(148,163,184,0.05)":"0 0 0 1px rgba(37,99,235,0.35), 0 14px 28px rgba(15,23,42,0.05)"};
    }
  `,incidentRibbonPanel:u.css`
    position: relative;
    min-height: 34px;
    padding: 5px 10px;
    border-radius: 13px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.92), rgba(8,13,22,0.98))":"#FFFFFF"};
    box-shadow: ${A?"inset 0 1px 0 rgba(255,255,255,0.035)":"0 10px 22px rgba(15,23,42,0.04)"};
  `,incidentRibbonEmpty:u.css`
    display: flex;
    align-items: center;
    min-height: 24px;
    padding: 0 4px;
    color: ${A?"#94A3B8":"#64748B"};
    font-size: 12px;
    font-weight: 700;
  `,legend:u.css`
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    align-items: center;
  `,legendTable:u.css`
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.94), rgba(10,16,26,0.98))":"#FFFFFF"};
    overflow: hidden;
    min-width: 0;
  `,legendTableHeader:u.css`
    display: grid;
    grid-template-columns: minmax(180px, 1fr) 96px 84px 104px;
    gap: 10px;
    padding: 8px 12px;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: ${A?"#94A3B8":"#64748B"};
    border-bottom: 1px solid ${A?"#1E293B":"#D7E3F4"};
    @media (max-width: 700px) {
      grid-template-columns: minmax(0, 1fr) 72px 72px;
      & > span:last-child {
        display: none;
      }
    }
  `,legendTableRow:u.css`
    display: grid;
    grid-template-columns: minmax(180px, 1fr) 96px 84px 104px;
    gap: 10px;
    align-items: center;
    padding: 9px 12px;
    border-bottom: 1px solid ${A?"rgba(30,41,59,0.7)":"rgba(215,227,244,0.8)"};
    font-size: 12px;
    &:last-child {
      border-bottom: 0;
    }
    @media (max-width: 700px) {
      grid-template-columns: minmax(0, 1fr) 72px 72px;
      & > span:last-child {
        display: none;
      }
    }
  `,legendTableFooter:u.css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 9px 12px;
    border-top: 1px solid ${A?"rgba(30,41,59,0.8)":"rgba(215,227,244,0.9)"};
    color: ${A?"#94A3B8":"#64748B"};
    font-size: 11px;
    font-weight: 750;
  `,legendSeriesName:u.css`
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 700;
    color: ${A?"#E2E8F0":"#0F172A"};
  `,legendValue:u.css`
    font-variant-numeric: tabular-nums;
    font-weight: 700;
    color: ${A?"#CBD5E1":"#334155"};
  `,legendItem:u.css`
    display: inline-flex;
    align-items: center;
    gap: 8px;
    max-width: 100%;
    min-width: 0;
    font-size: 12px;
    padding: 6px 10px;
    border-radius: 999px;
    background: ${A?"#111827":"#EFF6FF"};
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,legendSwatch:u.css`
    width: 10px;
    height: 10px;
    border-radius: 999px;
  `,grid:u.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
    gap: 12px;
  `,bottomDock:u.css`
    display: grid;
    grid-template-columns: minmax(360px, 1.1fr) minmax(280px, 0.9fr);
    gap: 10px;
    align-items: stretch;
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
  `,secondaryDock:u.css`
    display: grid;
    grid-template-columns: minmax(420px, 1.35fr) minmax(260px, 0.65fr);
    gap: 10px;
    align-items: start;
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
  `,sideUtilityStack:u.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,card:u.css`
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.94), rgba(10,16,26,0.98))":"#FFFFFF"};
    padding: 14px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    min-height: 0;
    box-shadow: ${A?"inset 0 1px 0 rgba(255,255,255,0.035)":"0 10px 24px rgba(15,23,42,0.045)"};
  `,cardTitle:u.css`
    font-size: 15px;
    font-weight: 700;
    line-height: 1.4;
  `,summaryList:u.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
    max-height: min(360px, 42vh);
    overflow-y: auto;
    padding-right: 4px;
  `,summaryTimeline:u.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 10px 12px 12px;
    border-radius: 14px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#0F172A":"#F8FAFC"};
  `,summaryRow:u.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
    cursor: pointer;
    transition: transform 120ms ease, border-color 120ms ease;
    &:hover {
      transform: translateY(-1px);
      border-color: ${A?"#334155":"#93C5FD"};
    }
  `,summaryRowSelected:u.css`
    border-color: ${A?"#3B82F6":"#2563EB"};
    box-shadow: inset 0 0 0 1px ${A?"#3B82F6":"#2563EB"};
  `,summaryTitle:u.css`
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
  `,summaryMeta:u.css`
    display: flex;
    justify-content: space-between;
    gap: 8px;
    flex-wrap: wrap;
    font-size: 12px;
    color: ${A?"#94A3B8":"#475569"};
  `,severityBadge:u.css`
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  `,compactHealthStrip:u.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(118px, 1fr));
    gap: 8px;
  `,scoreFeedTargetGrid:u.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(168px, 1fr));
    gap: 8px;
  `,scoreFeedTargetCard:u.css`
    min-width: 0;
    min-height: 96px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: 7px;
    padding: 10px;
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.82) 0%, rgba(8,13,22,0.72) 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,scoreFeedTargetTop:u.css`
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 9px;
  `,scoreFeedTargetIcon:u.css`
    flex: 0 0 auto;
    width: 27px;
    height: 27px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    background: ${A?"rgba(15,23,42,0.92)":"#F8FAFC"};
    border: 1px solid ${A?"rgba(148,163,184,0.16)":"#D7E3F4"};
    font-size: 16px;
    font-weight: 900;
    line-height: 1;

    svg {
      display: block;
      width: 18px;
      height: 18px;
    }
  `,scoreFeedTargetTitle:u.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 12px;
    font-weight: 850;
    color: ${A?"#E2E8F0":"#0F172A"};
  `,scoreFeedTargetStatus:u.css`
    align-self: flex-start;
    min-width: 62px;
    display: inline-flex;
    justify-content: center;
    padding: 5px 10px;
    border-radius: 7px;
    font-size: 11px;
    font-weight: 850;
  `,scoreFeedTargetMeta:u.css`
    font-size: 11px;
    font-weight: 750;
    color: ${A?"#AAB7CA":"#64748B"};
  `,healthChip:u.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: space-between;
    gap: 6px;
    min-height: 68px;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.82) 0%, rgba(8,13,22,0.68) 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,healthChipCompact:u.css`
    min-height: 58px;
    padding: 9px 10px;
  `,healthChipText:u.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  `,healthChipLabel:u.css`
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    color: ${A?"#94A3B8":"#64748B"};
  `,healthChipValue:u.css`
    font-size: 12px;
    font-weight: 800;
    color: ${A?"#E2E8F0":"#0F172A"};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,targetBadge:u.css`
    min-width: 0;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    max-width: 100%;
  `,targetIcon:u.css`
    flex: 0 0 auto;
    width: 28px;
    height: 28px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    background: ${A?"rgba(37,99,235,0.18)":"#EFF6FF"};
    border: 1px solid ${A?"rgba(96,165,250,0.22)":"#BFDBFE"};
    font-size: 15px;
    line-height: 1;

    svg {
      display: block;
      width: 18px;
      height: 18px;
    }
  `,targetText:u.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 1px;
  `,targetName:u.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 12px;
    font-weight: 850;
    color: ${A?"#E2E8F0":"#0F172A"};
  `,targetLanguage:u.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 10px;
    font-weight: 750;
    color: ${A?"#94A3B8":"#64748B"};
  `,labelChipGrid:u.css`
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  `,labelChip:u.css`
    max-width: 100%;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 8px;
    border-radius: 999px;
    border: 1px solid ${A?"rgba(96,165,250,0.24)":"#BFDBFE"};
    background: ${A?"rgba(30,64,175,0.24)":"#EFF6FF"};
    color: ${A?"#DBEAFE":"#1D4ED8"};
    font-size: 11px;
    font-weight: 800;
  `,labelChipKey:u.css`
    opacity: 0.72;
  `,labelChipValue:u.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,staleBanner:u.css`
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 9px 12px;
    border-radius: 14px;
    border: 1px solid ${A?"#92400E":"#FDBA74"};
    background: ${A?"rgba(146,64,14,0.22)":"#FFF7ED"};
    color: ${A?"#FDBA74":"#9A3412"};
    font-size: 12px;
    font-weight: 700;
  `,incidentHeader:u.css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 2px 8px 0;
    flex-wrap: wrap;
  `,severityLegend:u.css`
    display: inline-flex;
    align-items: center;
    gap: 18px;
    flex-wrap: wrap;
    font-size: 12px;
    font-weight: 800;
    color: ${A?"#AAB7CA":"#475569"};
  `,severityLegendItem:u.css`
    display: inline-flex;
    align-items: center;
    gap: 7px;
  `,severityLegendSwatch:u.css`
    width: 10px;
    height: 10px;
    border-radius: 2px;
  `,inlineInspectorLegacy:u.css`
    display: none;
  `,inspectorCard:u.css`
    min-height: 100%;
    border-radius: 16px;
    border: 1px solid ${A?"rgba(148,163,184,0.15)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.98), rgba(8,13,22,0.99))":"#FFFFFF"};
    box-shadow: ${A?"0 24px 70px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.045)":"0 18px 34px rgba(15,23,42,0.08)"};
    padding: 18px;
    display: flex;
    flex-direction: column;
    gap: 16px;
  `,inspectorTop:u.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
  `,inspectorTitle:u.css`
    font-size: 20px;
    font-weight: 850;
    letter-spacing: -0.01em;
  `,inspectorClose:u.css`
    width: 28px;
    height: 28px;
    display: grid;
    place-items: center;
    border: 0;
    border-radius: 999px;
    background: transparent;
    color: ${A?"#94A3B8":"#64748B"};
    font-size: 22px;
    cursor: default;
  `,inspectorTimestamp:u.css`
    display: flex;
    align-items: center;
    gap: 8px;
    padding-bottom: 12px;
    border-bottom: 1px solid ${A?"rgba(148,163,184,0.13)":"#E2E8F0"};
    color: ${A?"#D6DEEB":"#334155"};
    font-size: 15px;
    font-weight: 800;
  `,inspectorRows:u.css`
    display: grid;
    gap: 10px;
    padding-bottom: 12px;
    border-bottom: 1px solid ${A?"rgba(148,163,184,0.13)":"#E2E8F0"};
  `,inspectorRow:u.css`
    display: grid;
    grid-template-columns: minmax(110px, 0.72fr) minmax(0, 1fr);
    gap: 12px;
    align-items: baseline;
    font-size: 13px;
  `,inspectorRowLabel:u.css`
    color: ${A?"#94A3B8":"#64748B"};
    font-weight: 750;
  `,inspectorRowValue:u.css`
    min-width: 0;
    color: ${A?"#E2E8F0":"#0F172A"};
    font-weight: 800;
    text-align: right;
    overflow-wrap: anywhere;
  `,inspectorSectionTitle:u.css`
    font-size: 14px;
    font-weight: 850;
    color: ${A?"#EEF2FF":"#0F172A"};
  `,inspectorHealthRow:u.css`
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    gap: 12px;
  `,inspectorPill:u.css`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 5px 9px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 850;
  `,inspectorActionStack:u.css`
    display: grid;
    gap: 8px;
  `,inspectorActionButton:u.css`
    display: inline-flex;
    align-items: center;
    width: 100%;
    min-height: 42px;
    justify-content: center;
    border-radius: 9px;
    font-size: 13px;
    box-shadow: none;
  `,inspectorActionButtonPrimary:u.css`
    border-color: #2563EB;
    background: linear-gradient(180deg, #3B82F6 0%, #2563EB 100%);
    color: #FFFFFF;
  `,inspectorActionButtonSecondary:u.css`
    border-color: ${A?"rgba(148,163,184,0.18)":"#CBD5E1"};
    background: ${A?"rgba(15,23,42,0.72)":"#F8FAFC"};
    color: ${A?"#D6DEEB":"#334155"};
  `,queryPreview:u.css`
    max-height: 170px;
    overflow: auto;
    margin: 0;
    padding: 12px;
    border-radius: 10px;
    border: 1px solid ${A?"rgba(148,163,184,0.14)":"#D7E3F4"};
    background: ${A?"#101820":"#F8FAFC"};
    color: ${A?"#FBBF24":"#92400E"};
    font-family: 'Cascadia Code', Consolas, monospace;
    font-size: 10.5px;
    line-height: 1.5;
    white-space: pre-wrap;
  `,scoreFeedCard:u.css`
    min-width: 0;
    position: relative;
    overflow: hidden;
    &::before {
      content: '';
      position: absolute;
      inset: 0 auto 0 0;
      width: 3px;
      background: ${A?"linear-gradient(180deg, #38BDF8 0%, #2563EB 55%, #22C55E 100%)":"linear-gradient(180deg, #0EA5E9 0%, #2563EB 55%, #16A34A 100%)"};
      opacity: 0.9;
    }
  `,profileCard:u.css`
    gap: 10px;
  `,profileSummary:u.css`
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  `,profileDetailGrid:u.css`
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 8px;
    @media (max-width: 520px) {
      grid-template-columns: 1fr;
    }
  `,handoffCard:u.css`
    padding: 12px;
    gap: 10px;
    background: ${A?"linear-gradient(180deg, rgba(8,13,22,0.88), rgba(6,10,18,0.96))":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,handoffHeader:u.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
  `,detailGrid:u.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 10px;
  `,detailStat:u.css`
    min-width: 0;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
  `,detailLabel:u.css`
    font-size: 11px;
    color: ${A?"#94A3B8":"#64748B"};
    text-transform: uppercase;
    letter-spacing: 0.06em;
  `,detailValue:u.css`
    margin-top: 6px;
    font-size: 14px;
    font-weight: 700;
    line-height: 1.4;
    overflow-wrap: anywhere;
  `,detailTable:u.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
  `,metricBreakdownList:u.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,metricBreakdownCard:u.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;
    border-radius: 14px;
    border: 1px solid ${A?"#22314A":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, #101A2B 0%, #0E1625 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,metricBreakdownHeader:u.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
  `,metricBreakdownTitle:u.css`
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
  `,metricBreakdownReason:u.css`
    margin-top: 4px;
    font-size: 11px;
    line-height: 1.45;
    color: ${A?"#94A3B8":"#64748B"};
  `,metricBreakdownGrid:u.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(112px, 1fr));
    gap: 8px;
  `,metricBreakdownStat:u.css`
    min-width: 0;
    padding: 8px 10px;
    border-radius: 10px;
    border: 1px solid ${A?"#1E293B":"#E2E8F0"};
    background: ${A?"rgba(2, 6, 23, 0.58)":"rgba(255, 255, 255, 0.82)"};
  `,metricBreakdownStatLabel:u.css`
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: ${A?"#94A3B8":"#64748B"};
  `,metricBreakdownStatValue:u.css`
    margin-top: 5px;
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
    color: ${A?"#F8FAFC":"#0F172A"};
    overflow-wrap: anywhere;
  `,actionRow:u.css`
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    align-items: center;
  `,actionButton:u.css`
    border: 1px solid ${A?"#1D4ED8":"#93C5FD"};
    background: ${A?"#172554":"#EFF6FF"};
    color: ${A?"#DBEAFE":"#1D4ED8"};
    border-radius: 999px;
    padding: 8px 14px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 120ms ease, transform 120ms ease;
    &:hover:enabled {
      transform: translateY(-1px);
    }
    &:disabled {
      cursor: not-allowed;
      opacity: 0.55;
    }
  `,actionButtonSecondary:u.css`
    border: 1px solid ${A?"#334155":"#CBD5E1"};
    background: ${A?"#111827":"#F8FAFC"};
    color: ${A?"#E2E8F0":"#334155"};
    border-radius: 999px;
    padding: 8px 14px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 120ms ease, transform 120ms ease;
    &:hover:enabled {
      transform: translateY(-1px);
    }
    &:disabled {
      cursor: not-allowed;
      opacity: 0.55;
    }
  `,actionNotice:u.css`
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 12px;
    border-radius: 14px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
  `,feedRuleList:u.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,wideCard:u.css`
    grid-column: 1 / -1;
  `,feedRuleCard:u.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;
    border-radius: 12px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
  `,codeLine:u.css`
    border-radius: 10px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#020617":"#F8FAFC"};
    padding: 10px 12px;
    font-family: 'Cascadia Code', 'Consolas', monospace;
    font-size: 11px;
    line-height: 1.55;
    word-break: break-word;
  `,detailRow:u.css`
    display: grid;
    grid-template-columns: minmax(0, 1.3fr) repeat(4, minmax(0, 1fr));
    gap: 10px;
    align-items: center;
    font-size: 12px;
  `,detailHeaderRow:u.css`
    color: ${A?"#94A3B8":"#64748B"};
    text-transform: uppercase;
    letter-spacing: 0.04em;
    font-size: 11px;
  `,monoBlock:u.css`
    width: 100%;
    min-height: 170px;
    max-height: 320px;
    overflow: auto;
    border-radius: 12px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#020617":"#F8FAFC"};
    padding: 12px;
    box-sizing: border-box;
    font-family: 'Cascadia Code', 'Consolas', monospace;
    font-size: 11px;
    line-height: 1.55;
    white-space: pre-wrap;
    word-break: break-word;
  `,emptyState:u.css`
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 240px;
    border-radius: 16px;
    border: 1px dashed ${A?"#334155":"#CBD5E1"};
    background: ${A?"#020617":"#FFFFFF"};
    color: ${A?"#94A3B8":"#64748B"};
    text-align: center;
    padding: 20px;
    line-height: 1.6;
  `,skeletonShell:u.css`
    display: grid;
    grid-template-rows: auto minmax(240px, 1fr) auto;
    gap: 12px;
  `,skeletonBlock:u.css`
    position: relative;
    overflow: hidden;
    min-height: 20px;
    border-radius: 14px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
    &::after {
      content: '';
      position: absolute;
      inset: 0;
      transform: translateX(-100%);
      background: linear-gradient(90deg, transparent, ${A?"rgba(148,163,184,0.12)":"rgba(148,163,184,0.22)"}, transparent);
      animation: anomaly-shimmer 1.45s infinite;
    }
    @keyframes anomaly-shimmer {
      100% {
        transform: translateX(100%);
      }
    }
  `,skeletonHeader:u.css`
    height: 86px;
  `,skeletonChart:u.css`
    min-height: 320px;
  `,skeletonRows:u.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
  `,skeletonRow:u.css`
    height: 128px;
  `});var A;const C=(0,d.useMemo)(()=>(e=>{const t=[];e.forEach((e,a)=>{const r=e.fields.find(e=>e.type===c.FieldType.time);r&&e.fields.filter(e=>e.type===c.FieldType.number).forEach((n,i)=>{var l,s,o,c,d,m;const u=[],p=Math.min(null!==(l=r.values.length)&&void 0!==l?l:0,null!==(s=n.values.length)&&void 0!==s?s:0);for(let e=0;e<p;e+=1){const t=re(ne(r.values,e)),a=re(ne(n.values,e));null!==t&&null!==a&&u.push(Me(t,a))}if(0===u.length)return;u.sort((e,t)=>e.time-t.time);const h=n.config.displayName||(null===(d=n.state)||void 0===d?void 0:d.displayName)||n.name||e.name||`Series ${t.length+1}`,g=null===(m=n.config.color)||void 0===m?void 0:m.fixedColor;t.push({key:`${null!==(o=e.name)&&void 0!==o?o:a}-${null!==(c=n.name)&&void 0!==c?c:i}`,label:h,color:g||O[t.length%O.length],rawPoints:$e(u)})})});const a=new Map;t.forEach(e=>{var t;a.set(e.label,(null!==(t=a.get(e.label))&&void 0!==t?t:0)+1)});const r=new Map;return t.map(e=>{var t,n;if((null!==(t=a.get(e.label))&&void 0!==t?t:1)<=1)return e;const i=(null!==(n=r.get(e.label))&&void 0!==n?n:0)+1;return r.set(e.label,i),R(_({},e),{label:`${e.label} (${i})`})})})(a.series),[a.series]),B=(e=>{const t=String(null!=e?e:"").toLowerCase();return t.includes("loading")||t.includes("streaming")||t.includes("notstarted")})(a.state),[D,T]=(0,d.useState)([]);(0,d.useEffect)(()=>{if(0===C.length||"undefined"==typeof window)return;const e=window.setTimeout(()=>{T(C)},0);return()=>window.clearTimeout(e)},[C]);const P=C.length>0?C:B?D:C,V=B&&0===C.length&&D.length>0,q=B&&0===P.length,W=(0,d.useMemo)(()=>P.map(e=>e.label),[P]),j=(0,d.useMemo)(()=>xe(t,W),[t,W]),H=t.title||"Anomaly detector",Q=ut(),[G,Y]=(0,d.useState)(null),pe=(0,d.useMemo)(()=>{var e,t;return ft(null!==(e=null===(t=a.request)||void 0===t?void 0:t.targets)&&void 0!==e?e:[])},[a]);(0,d.useEffect)(()=>{let t=!1;return Q?(xt(null!=e?e:0,H).then(e=>{t||Y(e)}).catch(()=>{t||Y(null)}),()=>{t=!0}):()=>{t=!0}},[Q,e,H]);const{analyses:ye,effectiveBucketSpanMs:ve}=(0,d.useMemo)(()=>Le(P,j),[P,j]),Ee=(0,d.useMemo)(()=>"multi"===j.detectionMode?((e,t)=>{const a=new Map;return e.forEach(e=>{e.allPoints.forEach(t=>{var r;if(null===t.expected)return;const n=null!==(r=a.get(t.time))&&void 0!==r?r:[];n.push({point:t,label:e.label}),a.set(t.time,n)})}),[...a.entries()].map(([e,a])=>{var r,n;const i=[...a].sort((e,t)=>t.point.score-e.point.score),l=i.slice(0,Math.min(3,i.length)).reduce((e,t)=>e+t.point.score,0)/Math.min(3,i.length||1),s=i.reduce((e,t)=>ke(e,t.point),{severityLabel:"normal",severityScore:0}),o=i[0],c=i.slice(0,Math.min(3,i.length)).reduce((e,t)=>e+t.point.confidenceScore,0)/Math.min(3,i.length||1),d=c>=80?"high":c>=55?"medium":"low",m=i.reduce((e,t)=>((e,t)=>{const a=["healthy","gappy","thin","flatline"];return a.indexOf(t)>a.indexOf(e)?t:e})(e,t.point.dataQualityLabel),"healthy");return{time:e,bucketStart:null!==(r=null==o?void 0:o.point.bucketStart)&&void 0!==r?r:e,bucketEnd:null!==(n=null==o?void 0:o.point.bucketEnd)&&void 0!==n?n:e,score:l,contributors:i.filter(e=>e.point.isAnomaly).map(e=>e.label).slice(0,4),activeSeries:a.length,isAnomaly:l>=t.sensitivity||i.some(e=>e.point.isAnomaly),severityLabel:s.severityLabel,severityScore:s.severityScore,confidenceScore:Math.round(10*c)/10,confidenceLabel:d,dataQualityLabel:m}}).sort((e,t)=>e.time-t.time)})(ye,j):[],[ye,j]),Ne=(0,d.useMemo)(()=>{var e,t,a,r,n,l;const s=null!==(e=null==i||null===(r=i.from)||void 0===r||null===(a=r.valueOf)||void 0===a?void 0:a.call(r))&&void 0!==e?e:0,o=null!==(t=null==i||null===(l=i.to)||void 0===l||null===(n=l.valueOf)||void 0===n?void 0:n.call(l))&&void 0!==t?t:0;return s>0&&o>s?Math.max(60,Math.round((o-s)/1e3)):0},[i]),qe=(0,d.useMemo)(()=>{var e;const t=a.request,r=Number(null!==(e=null==t?void 0:t.intervalMs)&&void 0!==e?e:0);return Number.isFinite(r)&&r>0?Math.max(1,Math.round(r/1e3)):0},[a]),ze=$t({panelId:null!=e?e:0,panelTitle:H,options:t,resolvedOptions:j,liveTargets:pe,analyses:ye,timeRangeSeconds:Ne,queryStepSeconds:qe}),He=(0,d.useMemo)(()=>!1===t.showSummary?[]:_e(ye,Ee,j),[ye,Ee,t.showSummary,j]),[Ke,Xe]=(0,d.useState)(null),[tt,nt]=(0,d.useState)(null),[st,ct]=(0,d.useState)(null),[dt,mt]=(0,d.useState)(null),[gt,yt]=(0,d.useState)(!1),[bt,vt]=(0,d.useState)(!1),wt=(0,d.useRef)(null),[Et,kt]=(0,d.useState)({width:0,height:0}),St=(0,d.useMemo)(()=>{var e,t;return((e,t,a)=>!!e&&("event"===e.kind?a.some(t=>t.time===e.time):t.some(t=>t.key===e.seriesKey&&t.allPoints.some(t=>t.time===e.time))))(Ke,ye,Ee)?Ke:null!==(e=null===(t=He[0])||void 0===t?void 0:t.selection)&&void 0!==e?e:null},[ye,Ee,Ke,He]),Nt=(0,d.useMemo)(()=>[...He].sort((e,t)=>e.time-t.time),[He]),Mt=we(St);(0,d.useLayoutEffect)(()=>{const e=wt.current;if(!e)return;let t=0;const a=()=>{"undefined"!=typeof window&&(window.cancelAnimationFrame(t),t=window.requestAnimationFrame(()=>{const t={width:Math.round(e.clientWidth),height:Math.round(e.clientHeight)};kt(e=>e.width===t.width&&e.height===t.height?e:t)}))};a();let r=null;return"undefined"!=typeof ResizeObserver?(r=new ResizeObserver(()=>{a()}),r.observe(e)):"undefined"!=typeof window&&window.addEventListener("resize",a),()=>{"undefined"!=typeof window&&(window.cancelAnimationFrame(t),window.removeEventListener("resize",a)),null==r||r.disconnect()}},[r,n,t.showSummary]),(0,d.useEffect)(()=>{if(!dt||"undefined"==typeof window)return;const e=window.setTimeout(()=>{mt(null)},3200);return()=>{window.clearTimeout(e)}},[dt]);const Lt=e=>{e&&(Xe(e.selection),ct(e.time),nt(e.time))},At=(0,d.useMemo)(()=>{var e,t;const a=Re(St,ye,Ee);if(a)return a;const r=null!==(e=null!==(t=He.find(e=>we(e.selection)===Mt))&&void 0!==t?t:He[0])&&void 0!==e?e:null;return(n=r)?{kind:"point",title:n.title,subtitle:n.subtitle,seriesKey:we(n.selection),seriesLabel:n.title,color:X[n.severityLabel],time:n.time,bucketStart:n.time,bucketEnd:n.time+1,actual:n.score,expected:null,deviation:null,deviationPercent:null,rangeLower:null,rangeUpper:null,sampleCount:1,minValue:n.score,maxValue:n.score,score:n.score,pointScore:n.score,windowScore:0,scoreDriver:"point",severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel}:null;var n},[St,Mt,ye,Ee,He]),Ct=(0,d.useMemo)(()=>ye.flatMap(e=>e.allPoints),[ye]),Bt=null!=st?st:tt,Dt=(0,d.useMemo)(()=>((e,t,a)=>{var r;if(null===e)return null;const n=t.map(t=>{const a=t.allPoints.find(t=>t.time===e);return a?{key:t.key,label:t.label,color:t.color,actual:a.value,expected:a.expected,score:a.score,isAnomaly:a.isAnomaly,severityLabel:a.severityLabel,severityScore:a.severityScore,confidenceScore:a.confidenceScore,confidenceLabel:a.confidenceLabel,dataQualityLabel:a.dataQualityLabel}:null}).filter(e=>null!==e).sort((e,t)=>t.score-e.score);if(0===n.length)return null;const i=null!==(r=a.find(t=>t.time===e))&&void 0!==r?r:null,l=i?{severityLabel:i.severityLabel,severityScore:i.severityScore}:n.reduce((e,t)=>ke(e,t),{severityLabel:"normal",severityScore:0});return{time:e,event:i,series:n,anomalyCount:n.filter(e=>e.isAnomaly).length+((null==i?void 0:i.isAnomaly)?1:0),severityLabel:l.severityLabel,severityScore:l.severityScore}})(Bt,ye,Ee),[Bt,ye,Ee]),Tt=((e,t)=>{switch(e){case"synced":return t?"#34D399":"#047857";case"syncing":return t?"#FBBF24":"#B45309";case"error":return t?"#F87171":"#B91C1C";case"unsupported":return t?"#F59E0B":"#B45309";case"off":return t?"#94A3B8":"#64748B";default:return t?"#60A5FA":"#1D4ED8"}})(ze.kind,M.isDark),Pt=Ue(ze.registered),_t=Qe(null!==(s=null===(v=ze.registered[0])||void 0===v?void 0:v.target)&&void 0!==s?s:t.scoreFeedTarget),Rt="error"===ze.kind?"Error":"syncing"===ze.kind?"Syncing":"synced"===ze.kind?"Up":"Ready",Ot="Up"===Rt?"#22C55E":"Syncing"===Rt?"#60A5FA":"Error"===Rt?"#EF4444":"#F59E0B",Vt="Up"===Rt?(It=ze.lastSyncedAt)?new Date(It).toLocaleString():"Not synced yet":"Syncing"===Rt?"Publishing":"Error"===Rt?"Check exporter":"Selected target";var It;const qt="synced"===ze.kind?`${lt(_t)} healthy`:Ft(ze.kind),Wt="off"!==t.scoreFeedMode?m().createElement("div",{className:`${L.card} ${L.scoreFeedCard}`},m().createElement("div",{style:{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12,flexWrap:"wrap"}},m().createElement("div",{style:{minWidth:0,flex:"1 1 320px"}},m().createElement("div",{className:L.cardTitle},"Anomaly score feed"),m().createElement("div",{className:L.subtitle},ze.message)),m().createElement("div",{style:{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}},m().createElement("span",{className:L.recommendationBadge,style:{background:`${Tt}22`,color:Tt}},qt),m().createElement("button",{type:"button",onClick:()=>{ze.syncNow()},disabled:"syncing"===ze.kind,style:{border:"1px solid "+(M.isDark?"#1D4ED8":"#93C5FD"),background:M.isDark?"#172554":"#EFF6FF",color:M.isDark?"#DBEAFE":"#1D4ED8",borderRadius:999,padding:"8px 14px",fontSize:12,fontWeight:700,cursor:"syncing"===ze.kind?"wait":"pointer",opacity:"syncing"===ze.kind?.72:1}},"syncing"===ze.kind?"Syncing...":"Sync score feed"))),m().createElement("div",{className:L.scoreFeedTargetGrid,"aria-label":"Score feed target health"},m().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},m().createElement("span",{"aria-hidden":"true",style:{width:10,height:10,borderRadius:999,background:Ot,boxShadow:`0 0 0 4px ${Ot}1f`}}),m().createElement("div",{className:L.healthChipText},m().createElement("span",{className:L.healthChipLabel},"Status"),m().createElement("span",{className:L.healthChipValue},Ft(ze.kind)))),m().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},m().createElement("div",{className:L.healthChipText},m().createElement("span",{className:L.healthChipLabel},"Mode"),m().createElement("span",{className:L.healthChipValue},at[null!==(o=t.scoreFeedMode)&&void 0!==o?o:"auto"]))),m().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},m().createElement("div",{className:L.scoreFeedTargetTop},m().createElement("span",{className:L.scoreFeedTargetIcon,style:{color:(zt=_t,it[Qe(zt)])}},ot(_t)),m().createElement("div",{className:L.healthChipText},m().createElement("span",{className:L.scoreFeedTargetTitle},lt(_t)),m().createElement("span",{className:L.scoreFeedTargetMeta},"Score target")))),m().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},m().createElement("div",{className:L.healthChipText},m().createElement("span",{className:L.healthChipLabel},"Last sync"),m().createElement("span",{className:L.healthChipValue},Vt))),m().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},m().createElement("div",{className:L.healthChipText},m().createElement("span",{className:L.healthChipLabel},"Feed series"),m().createElement("span",{className:L.healthChipValue},ze.registered.length>0?ze.registered.length:"Waiting")))),ze.registered.length>0?m().createElement(m().Fragment,null,m().createElement("div",{className:L.subtitle},"Published score feed records are ready for alerting from the selected target. Queries below match the store selected in Score feed target."),m().createElement("div",{className:L.actionRow},m().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>yt(e=>!e)},gt?"Hide synced rules":"Show synced rules")),gt?m().createElement("div",{className:L.feedRuleList},ze.registered.map(e=>{var t,a,r;return m().createElement("div",{key:e.rule,className:L.feedRuleCard},m().createElement("div",{className:L.handoffHeader},m().createElement("div",{style:{minWidth:0,flex:"1 1 180px"}},m().createElement("div",{className:L.summaryTitle},e.rule),m().createElement("div",{className:L.subtitle},"Alert rule query")),m().createElement("span",{className:L.targetBadge,title:Ge(e)},m().createElement("span",{className:L.targetIcon},ot(null!==(t=e.target)&&void 0!==t?t:"prometheus")),m().createElement("span",{className:L.targetText},m().createElement("span",{className:L.targetName},lt(null!==(a=e.target)&&void 0!==a?a:"prometheus")),m().createElement("span",{className:L.targetLanguage},null!==(r=e.queryLanguage)&&void 0!==r?r:Pt)))),m().createElement("div",{className:L.codeLine},e.query),m().createElement("div",{className:L.subtitle},"Per-series drilldown query"),m().createElement("div",{className:L.codeLine},e.perSeriesQuery),e.queryVariants&&e.queryVariants.length>0?m().createElement("div",{className:L.feedRuleList},e.queryVariants.map(t=>m().createElement("div",{key:`${e.rule}-${t.target}-${t.queryLanguage}`,className:L.feedRuleCard},m().createElement("div",{className:L.handoffHeader},m().createElement("div",{className:L.subtitle},"Variant query"),m().createElement("span",{className:L.targetBadge,title:Ge(t)},m().createElement("span",{className:L.targetIcon},ot(t.target)),m().createElement("span",{className:L.targetText},m().createElement("span",{className:L.targetName},lt(t.target)),m().createElement("span",{className:L.targetLanguage},t.queryLanguage)))),m().createElement("div",{className:L.codeLine},t.query),m().createElement("div",{className:L.codeLine},t.perSeriesQuery),m().createElement("div",{className:L.actionRow},m().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{Je(t.query).then(()=>mt({tone:"success",message:`Copied ${Ge(t)} query for ${e.rule}.`})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the target query."}))}},"Copy variant query"))))):null,m().createElement("div",{className:L.actionRow},m().createElement("button",{type:"button",className:L.actionButton,onClick:()=>{Je(e.query).then(()=>mt({tone:"success",message:`Copied alert query for ${e.rule}.`})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."}))}},"Copy alert query"),m().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{Je(e.perSeriesQuery).then(()=>mt({tone:"success",message:`Copied per-series query for ${e.rule}.`})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the per-series query."}))}},"Copy series query")))})):null):null):null;var zt;if(q)return m().createElement("div",{className:L.wrapper},m().createElement("div",{className:L.skeletonShell,"aria-label":"Anomaly detector is loading"},m().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonHeader}`}),m().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonChart}`}),m().createElement("div",{className:L.skeletonRows},m().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonRow}`}),m().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonRow}`}),m().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonRow}`}))));if(0===P.length||0===Ct.length)return m().createElement("div",{className:L.wrapper},Wt,m().createElement("div",{className:L.emptyState},"Add a time series query with at least one numeric field to start anomaly analysis."));const jt=ye.length,Ut="multi"===j.detectionMode?Ee.filter(e=>e.isAnomaly).length:ye.reduce((e,t)=>e+t.anomalyCount,0),Ht="multi"===j.detectionMode?Ee.map(e=>e.severityScore):ye.map(e=>e.maxSeverityScore),Qt=Math.max(...Ht,0),Gt=ye.reduce((e,t)=>ke(e,{severityLabel:t.maxSeverityLabel,severityScore:t.maxSeverityScore}),{severityLabel:"normal",severityScore:0}),Yt=Ct.map(e=>e.time),Kt=[...new Set(Yt)].sort((e,t)=>e-t),Zt=Ct.flatMap(e=>[e.value,e.expected,e.lower,e.upper]).filter(e=>null!==e&&Number.isFinite(e)),Jt=Math.min(...Yt),Xt=Math.max(...Yt),ea=Math.max(Xt-Jt,1),ta=Math.max((null!==(h=null===(w=i.to)||void 0===w||null===(x=w.valueOf)||void 0===x?void 0:x.call(w))&&void 0!==h?h:Xt)-(null!==(g=null===(k=i.from)||void 0===k||null===(E=k.valueOf)||void 0===E?void 0:E.call(k))&&void 0!==g?g:Jt),1),aa=Math.max(ea,ta),ra=Math.min(...Zt),na=Math.max(...Zt),ia=Math.max(.12*(na-ra),.03*Math.abs(na),1),la=ra-ia,sa=na+ia,oa=(0,c.timeZoneAbbrevation)(Xt,{timeZone:l})||("string"==typeof l?l:"local"),ca=X[Gt.severityLabel],da=Math.max(r-24,320),ma=Math.max(Math.min(!1===t.showSummary?n-72:.54*n,500),340),ua=Et.width>0?Math.max(Et.width,260):da,pa=Et.height>0?Math.max(Et.height,220):ma,ha=R(_({},I),{top:pa<280?18:24,right:"multi"===j.detectionMode?28:24,bottom:pa<280?42:54,left:"multi"===j.detectionMode?ua<720?80:92:ua<720?72:84}),ga=Math.max(ua-ha.left-ha.right,40),fa=Math.max(pa-ha.top-ha.bottom,40),ya=e=>Xt===Jt?ha.left+ga/2:ha.left+(e-Jt)/(Xt-Jt)*ga,ba=e=>sa===la?ha.top+fa/2:ha.top+fa-(e-la)/(sa-la)*fa,va=((e,t,a,r)=>{const n=ue(a,r),i="multi"===t?e/235:e/205,l="compact"===n?.76:"dense"===n?1.35:1,s=Math.round(i*l),o="dense"===n?5:4,c="dense"===n?10:"compact"===n?7:8;return Math.max(o,Math.min(c,s))})(ua,j.detectionMode,j.timeAxisDensity,aa),xa=Math.max(5,Math.min(6,Math.round(fa/72))),wa=Be(Jt,Xt,va),Ea="top_and_bottom"===j.timeAxisPlacement?wa.filter((e,t)=>0===t||t===wa.length-1||t%Math.max(1,Math.ceil(wa.length/3))===0):[],ka=Be(la,sa,xa),Sa=Math.max(64,ga/10),Fa="multi"===j.detectionMode?Pe(De(Ee.filter(e=>e.isAnomaly),ya,Sa,"event"===(null==St?void 0:St.kind)?St.time:null),8,"event"===(null==St?void 0:St.kind)?St.time:null):[],$a=j.showFocusBand?((e,t,a)=>{if(!e||a.length<2)return null;const r=Te(a,e.time);if(r<0)return null;const n=Math.max(3,Math.min(5,Math.floor(a.length/10)||3)),i=Math.max(0,r-n),l=Math.min(a.length-1,r+n),s=a[i],o=a[l];if(o<=s)return null;const c=t.map(e=>({key:e.key,label:e.label,color:e.color,points:e.allPoints.filter(e=>e.time>=s&&e.time<=o)})).filter(e=>e.points.length>0);if(0===c.length)return null;const d=c.flatMap(e=>e.points.flatMap(e=>[e.value,e.expected].filter(e=>null!==e&&Number.isFinite(e))));return 0===d.length?null:{startTime:s,endTime:o,selectedTime:e.time,bucketStart:e.bucketStart,bucketEnd:e.bucketEnd,title:"event"===e.kind?"Focused incident window":`Focused view for ${e.seriesLabel}`,series:c,minValue:Math.min(...d),maxValue:Math.max(...d)}})(At,ye,Kt):null,Na=((e,t,a,r)=>{const n=r.length>=2?ie(r.slice(1).map((e,t)=>Math.max(e-r[t],1))):6e4,i=Math.max(1.25*n,3e4),l="multi"===a?t.filter(e=>e.isAnomaly).map(e=>({start:e.bucketStart,end:Math.max(e.bucketEnd,e.time),center:e.time,severityLabel:e.severityLabel,severityScore:e.severityScore,selection:{kind:"event",time:e.time}})):e.flatMap(e=>e.allPoints.filter(e=>e.isAnomaly).map(t=>({start:t.bucketStart,end:Math.max(t.bucketEnd,t.time),center:t.time,severityLabel:t.severityLabel,severityScore:t.severityScore,selection:{kind:"point",seriesKey:e.key,time:t.time}})));if(0===l.length)return[];l.sort((e,t)=>e.start-t.start);const s=[];let o=[l[0]];const c=()=>{if(0===o.length)return;const e=o.reduce((e,t)=>ke(e,t)===e?e:t,o[0]),t=Math.min(...o.map(e=>e.start)),a=Math.max(...o.map(e=>e.end));s.push({key:`ribbon-${t}-${a}-${s.length}`,start:t,end:a,center:e.center,count:o.length,label:1===o.length?"1 incident":`${o.length} incidents`,severityLabel:e.severityLabel,severityScore:e.severityScore,selection:e.selection}),o=[]};for(let e=1;e<l.length;e+=1){const t=l[e],a=o[o.length-1];t.start<=a.end+i?o.push(t):(c(),o=[t])}return c(),s})(ye,Ee,j.detectionMode,Kt),Ma=$a?Math.max(54,Math.min(76,.2*fa)):0,La=$a?ha.top+fa-Ma-10:ha.top+fa,Aa=$a?La-8:ha.top+fa,Ca=ye.length>8,Ba=Ca?[]:ye.length>4?[...ye].sort((e,t)=>t.maxSeverityScore-e.maxSeverityScore||t.anomalyCount-e.anomalyCount||e.label.localeCompare(t.label)).slice(0,4):ye,Da=j.showInlineSeriesLabels&&!Ca?((e,t,a,r,n,i)=>{const l=e.map(e=>{const r=[...e.points].reverse().find(e=>Number.isFinite(e.value));if(!r)return null;const n=me(`${e.label} • ${le(r.value)}`,28);return{key:e.key,label:n,color:e.color,targetY:a(r.value),labelY:a(r.value),anchorX:i,lastX:t(r.time),lastY:a(r.value),width:Math.max(84,Math.min(168,6.6*n.length+18)),value:r.value}}).filter(e=>null!==e).sort((e,t)=>e.targetY-t.targetY);if(0===l.length)return[];let s=r+14;for(const e of l)e.labelY=Math.max(e.targetY,s),s=e.labelY+20;s=n-12;for(let e=l.length-1;e>=0;e-=1){const t=l[e];t.labelY=Math.min(t.labelY,s),s=t.labelY-20}return l.map(e=>R(_({},e),{labelY:Math.max(r+14,Math.min(n-12,e.labelY))}))})(Ba,ya,ba,ha.top+12,Aa-10,ua-ha.right-10):[],Ta=Ae(j.bucketSpan,ve),Pa=((e,t)=>{const a=Ae(e.bucketSpan,t),r=t?`Dense data is first summarized into ${a} buckets so the panel stays fast.`:"Incoming samples are scored directly for maximum detail.";return`${"custom"===e.effectiveMetricPreset?"Custom profile is active.":`${U[e.effectiveMetricPreset]} profile is active.`} ${"level_shift"===e.algorithm?`It focuses on sustained baseline shifts over the last ${e.baselineWindow} buckets.`:"seasonal"===e.algorithm?`It compares each point with similar historical positions using ${K[e.seasonalRefinement].toLowerCase()} refinement and ${e.seasonalitySamples} seasonal samples.`:"ewma"===e.algorithm?`It keeps a moving baseline over ${e.baselineWindow} buckets and reacts when the live metric keeps pulling away from that baseline.`:"mad"===e.algorithm?`It uses a robust median-based spread over ${e.baselineWindow} buckets so noisy data does not create too many false alarms.`:`It compares each point with a rolling average over ${e.baselineWindow} buckets.`} Current threshold is ${e.sensitivity.toFixed(2)}. ${r}`})(j,ve),_a=At?((e,t)=>{const a=ee[e.confidenceLabel].replace("confidence","signal confidence"),r=ae[e.dataQualityLabel].toLowerCase();if("event"===e.kind)return`${e.activeSeries} metric agreed on this combined anomaly. Strongest reason: ${e.breakdown[0]?Se(e.breakdown[0].scoreDriver,t):"Cross-metric deviation"}. ${a}, data quality is ${r}.`;const n=Se(e.scoreDriver,t),i=null===e.deviation?"moved away from baseline":e.deviation>0?"moved above its baseline":e.deviation<0?"fell below its baseline":"stayed close to its baseline";return`${e.seriesLabel} ${i}. Main reason: ${n}. ${a}, data quality is ${r}.`})(At,j.algorithm):"",Ra=((e,t)=>JSON.stringify(e.map(e=>({time:e.time,text:e.title,tags:Oe(["anomaly-detector",e.severityLabel,e.confidenceLabel,e.dataQualityLabel,t]),detail:e.detail,raw_score:e.score,alarm_score_0_100:e.severityScore,alarm_severity:e.severityLabel,confidence_score:e.confidenceScore,confidence_label:e.confidenceLabel,data_quality:e.dataQualityLabel})),null,2))(He,Ta),Oa=je(ze.registered),Va=Ve(j.severityPreset),Ia=(null==G?void 0:G.folderTitle)||ht(),qa=(null==G?void 0:G.panelTitle)||H,Wa=(null==G?void 0:G.dashboardTitle)||pt()||"Grafana dashboard",za=Qe(null!==(f=null===(S=ze.registered[0])||void 0===S?void 0:S.target)&&void 0!==f?f:t.scoreFeedTarget),ja=((e,t,a)=>{const r=e.trim();let n=t.trim();return r&&n.toLowerCase().endsWith(` - ${r}`.toLowerCase())&&(n=n.slice(0,n.length-r.length-3).trim()),[r,n,a.trim()].filter((e,t,a)=>e.length>0&&a.findIndex(t=>t===e)===t).join(" - ")})(Ia,Wa,qa)||qa,Ua=((e,t,a)=>({alert_family:"anomaly_detector",severity:"major",dashboard_uid:e||"unsaved_dashboard",panel_id:t>0?String(t):"unknown_panel",score_target:Qe(a)}))(Q,null!=e?e:0,za),Ha=(Ga={dashboardUid:Q,folderTitle:Ia,dashboardTitle:Wa,panelId:null!=e?e:0,panelTitle:qa,ruleName:ja},{summary:(Qa=At)?Qa.title:Ga.ruleName,description:Ye(Qa,Ga.panelTitle),folder_title:null!==(Ya=Ga.folderTitle)&&void 0!==Ya?Ya:"",dashboard_title:Ga.dashboardTitle,panel_title:Ga.panelTitle,__dashboardUid__:Ga.dashboardUid,__panelId__:Ga.panelId>0?String(Ga.panelId):""});var Qa,Ga,Ya;const Ka={dashboardUid:Q,folderTitle:Ia,dashboardTitle:Wa,panelId:null!=e?e:0,panelTitle:qa,ruleName:ja,queryLanguage:Pt,alertQuery:Oa,threshold:Va,target:za,labels:Ua,annotations:Ha},Za=Ie(Ua),Ja=((e,t,a,r,n)=>{var i;const l=Ve(t.severityPreset),s=je(r),o=Ue(r);return JSON.stringify({title:n.ruleName,folder_name:null!==(i=n.folderTitle)&&void 0!==i?i:"",dashboard_name:n.dashboardTitle,dashboard_uid:n.dashboardUid,panel_title:n.panelTitle,panel_id:n.panelId,score_feed_ready:r.length>0,paste_into:`Grafana Alerting query editor (${o})`,query_language:o,alert_query:s||"Sync anomaly score feed first to generate an alert-ready score query.",grafana_condition:s?`WHEN QUERY IS ABOVE ${l}`:"Sync anomaly score feed first",for:"10m",evaluate_every:"3m",no_data_state:"Alerting",exec_err_state:"Error",threshold:l,suggested_labels:n.labels,suggested_label_pairs:Ie(n.labels),suggested_annotations:n.annotations,synced_rules:r.map(e=>{var t,a,r,n;return{rule:e.rule,target:null!==(t=e.target)&&void 0!==t?t:"prometheus",query_language:null!==(a=e.queryLanguage)&&void 0!==a?a:o,datasource_type:null!==(r=e.datasourceType)&&void 0!==r?r:"",query:e.query,per_series_query:e.perSeriesQuery,query_variants:null!==(n=e.queryVariants)&&void 0!==n?n:[]}}),rule_scope:r.length>1?"Combined max across synced panel rules":"Single synced panel rule",mode:t.detectionMode,algorithm:t.algorithm,bucket_span:a,history_window:t.baselineWindow,severity_preset:t.severityPreset,selected_severity:e?e.severityLabel:"normal",selected_score:e?e.score:0,selected_raw_score:e?e.score:0,selected_alarm_score_0_100:e?e.severityScore:0,selected_alarm_severity:e?e.severityLabel:"normal",score_scale_note:"Alert queries use the normalized 0-100 alarm score, not the raw detection score.",selected_confidence:e?e.confidenceLabel:"low",selected_confidence_score:e?e.confidenceScore:0,selected_data_quality:e?e.dataQualityLabel:"thin",guidance:e?Fe(e,t.severityPreset):"Select an anomaly to generate a focused alert draft."},null,2)})(At,j,Ta,ze.registered,Ka),Xa=Ze(At,null!=e?e:0,Q,Ta),er=Xa?JSON.stringify(Xa,null,2):"",tr=At?Math.max(1,He.findIndex(e=>we(e.selection)===Mt)+1):0,ar="point"===(null==At?void 0:At.kind)?At.seriesLabel:"event"===(null==At?void 0:At.kind)?At.contributors.slice(0,2).join(", ")||`${At.activeSeries} active series`:null!==(y=null===(F=ye[0])||void 0===F?void 0:F.label)&&void 0!==y?y:"n/a",rr="point"===(null==At?void 0:At.kind)?le(At.actual):"event"===(null==At?void 0:At.kind)?`${At.activeSeries} active`:"n/a",nr="point"===(null==At?void 0:At.kind)?le(At.expected):"event"===(null==At?void 0:At.kind)?`${At.breakdown.length} contributors`:"n/a",ir="point"===(null==At?void 0:At.kind)?null!==At.deviationPercent?oe(At.deviationPercent):le(At.deviation):"event"===(null==At?void 0:At.kind)?le(At.score):"n/a",lr=At?le(At.score):"n/a",sr=At?`${J[At.severityLabel]} ${At.severityScore}`:"n/a",or=At?ee[At.confidenceLabel]:"n/a",cr=At?se(At.confidenceScore):"n/a",dr=At?"healthy"===At.dataQualityLabel?"Good":ae[At.dataQualityLabel].replace(" data",""):"n/a",mr=At?se(At.confidenceScore):"n/a",ur=(null===($=pe[0])||void 0===$?void 0:$.datasourceType)?pe[0].datasourceType.charAt(0).toUpperCase()+pe[0].datasourceType.slice(1):rt[Qe(t.scoreFeedTarget)],pr=ye.length>8?[...ye].sort((e,t)=>t.anomalyCount-e.anomalyCount||t.maxSeverityScore-e.maxSeverityScore||e.label.localeCompare(t.label)).slice(0,8):ye,hr=Math.max(0,ye.length-pr.length),gr=At?{x:ya(At.bucketStart),height:Math.max(24,Aa-ha.top),width:At.bucketEnd>At.bucketStart?Math.max(ya(At.bucketEnd)-ya(At.bucketStart),10):12}:null,fr=Fa.map(e=>{const t=ya(e.bucketStart),a=(e.bucketEnd>e.bucketStart?ya(e.bucketEnd):t)-t,r=Math.max(10,Math.min(ga/80,20)),n=Math.max(10,Math.min(Number.isFinite(a)&&a>0?a:r,24)),i=a>0?t:ya(e.time)-n/2,l=Math.max(ha.left+2,Math.min(i,ua-ha.right-n-2));return{event:e,x:l,width:n,centerX:l+n/2}}),yr=`anomaly-plot-${null!=e?e:"panel"}-${j.detectionMode}`,br=M.isDark?"#CBD5E1":"#334155",vr=M.isDark?"#0B1628":"#F8FAFC",xr=M.isDark?"#0F1C2D":"#FFFFFF",wr=Dt?ya(Dt.time):null,Er=null===wr?0:Math.max(16,Math.min(wr+18,ua-290)),kr=null!==wr&&wr>.62*ua,Sr=null===wr?void 0:{left:kr?void 0:Er,right:kr?Math.max(14,ua-wr+14):void 0},Fr=m().createElement("aside",{className:L.inspectorCard,"aria-label":"Anomaly inspector"},m().createElement("div",{className:L.inspectorTop},m().createElement("div",{className:L.inspectorTitle},"Anomaly inspector"),m().createElement("button",{type:"button",className:L.inspectorClose,"aria-label":"Inspector is pinned in this panel"},"x")),At?m().createElement(m().Fragment,null,m().createElement("div",{className:L.inspectorTimestamp},m().createElement("span",null,ge(At.time,aa,l)),m().createElement("span",{"aria-hidden":"true"},"•"),m().createElement("span",{style:{color:X[At.severityLabel]}},J[At.severityLabel])),m().createElement("div",{className:L.inspectorRows},m().createElement("div",{className:L.inspectorRow},m().createElement("span",{className:L.inspectorRowLabel},"Series"),m().createElement("span",{className:L.inspectorRowValue},me(ar,34))),m().createElement("div",{className:L.inspectorRow},m().createElement("span",{className:L.inspectorRowLabel},"Value"),m().createElement("span",{className:L.inspectorRowValue},rr)),m().createElement("div",{className:L.inspectorRow},m().createElement("span",{className:L.inspectorRowLabel},"Expected"),m().createElement("span",{className:L.inspectorRowValue},nr)),m().createElement("div",{className:L.inspectorRow},m().createElement("span",{className:L.inspectorRowLabel},"Deviation"),m().createElement("span",{className:L.inspectorRowValue},ir)),m().createElement("div",{className:L.inspectorRow},m().createElement("span",{className:L.inspectorRowLabel},"Raw detection score"),m().createElement("span",{className:L.inspectorRowValue},lr)),m().createElement("div",{className:L.inspectorRow},m().createElement("span",{className:L.inspectorRowLabel},"Alert score (0-100)"),m().createElement("span",{className:L.inspectorRowValue,style:{color:X[At.severityLabel]}},sr)),m().createElement("div",{className:L.inspectorRow},m().createElement("span",{className:L.inspectorRowLabel},"Bucket"),m().createElement("span",{className:L.inspectorRowValue},Ta)),m().createElement("div",{className:L.inspectorRow},m().createElement("span",{className:L.inspectorRowLabel},"Incident"),m().createElement("span",{className:L.inspectorRowValue},tr," of ",Math.max(He.length,tr)))),m().createElement("div",null,m().createElement("div",{className:L.inspectorSectionTitle},"Why is this anomalous?"),m().createElement("div",{className:L.recommendationText,style:{marginTop:10}},_a)),m().createElement("div",{className:L.inspectorRows},m().createElement("div",{className:L.inspectorHealthRow},m().createElement("span",{className:L.inspectorRowLabel},"Confidence"),m().createElement("span",null,m().createElement("span",{className:L.inspectorPill,style:{background:`${te[At.confidenceLabel]}33`,color:te[At.confidenceLabel]}},or),m().createElement("span",{className:L.inspectorRowValue,style:{marginLeft:10}},cr,"%"))),m().createElement("div",{className:L.inspectorHealthRow},m().createElement("span",{className:L.inspectorRowLabel},"Data quality"),m().createElement("span",null,m().createElement("span",{className:L.inspectorPill,style:{background:"rgba(34,197,94,0.24)",color:"#86EFAC"}},dr),m().createElement("span",{className:L.inspectorRowValue,style:{marginLeft:10}},mr,"%")))),m().createElement("div",null,m().createElement("div",{className:L.inspectorSectionTitle},"Rule labels"),m().createElement("div",{className:L.labelChipGrid,style:{marginTop:10}},Object.entries(Ua).map(([e,t])=>m().createElement("span",{key:e,className:L.labelChip,title:`${e}=${t}`},m().createElement("span",{className:L.labelChipKey},e),m().createElement("span",null,"="),m().createElement("span",{className:L.labelChipValue},t))))),m().createElement("div",{className:L.inspectorActionStack},m().createElement("button",{type:"button",className:`${L.actionButton} ${L.inspectorActionButton} ${L.inspectorActionButtonPrimary}`,disabled:!Oa,onClick:()=>{if(!Oa)return void mt({tone:"error",message:"Sync anomaly score feed first to generate the alert query."});const e=We(Ka);mt({tone:"success",message:e?"Opened Grafana alert rule builder. Copying the alert draft with labels to your clipboard.":"Copying the alert draft with labels. If the builder did not open, use Alerting > Alert rules > New alert rule."}),Je(Ja).then(()=>mt({tone:"success",message:e?"Opened Grafana alert rule builder and copied the alert draft with labels.":"Copied the alert draft with labels. If the builder did not open, use Alerting > Alert rules > New alert rule."})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert draft."}))}},"Open alert rule builder"),m().createElement("button",{type:"button",className:`${L.actionButtonSecondary} ${L.inspectorActionButton} ${L.inspectorActionButtonSecondary}`,disabled:!Za,onClick:()=>{Je(Za).then(()=>mt({tone:"success",message:"Copied suggested alert labels."})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to copy alert labels."}))}},"Copy rule labels"),m().createElement("button",{type:"button",className:`${L.actionButtonSecondary} ${L.inspectorActionButton} ${L.inspectorActionButtonSecondary}`,disabled:!Xa||!Q,onClick:()=>{Xa?Q?et(Xa).then(()=>mt({tone:"success",message:"Created a Grafana annotation for the selected anomaly."})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to create the Grafana annotation."})):mt({tone:"error",message:"Save the dashboard once before creating Grafana annotations from the panel."}):mt({tone:"error",message:"Select an anomaly first to create an annotation."})}},"Create annotation"),m().createElement("button",{type:"button",className:`${L.actionButtonSecondary} ${L.inspectorActionButton} ${L.inspectorActionButtonSecondary}`,disabled:!Oa,onClick:()=>{Oa?Je(Oa).then(()=>mt({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):mt({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy alert query")),m().createElement("div",null,m().createElement("div",{className:L.inspectorSectionTitle},"Query preview"),m().createElement("pre",{className:L.queryPreview},Oa||`Sync the score feed to generate ${Pt}.`))):m().createElement("div",{className:L.subtitle},"Select a detected incident to see why it was flagged, how strong the signal is, and whether it is ready for alerting."));return m().createElement("div",{className:L.wrapper},m().createElement("div",{className:L.operationalCanvas},m().createElement("main",{className:L.workspacePane},m().createElement("div",{className:L.statusHeader},m().createElement("div",{className:L.statusRail,style:{background:ca}}),m().createElement("div",{className:L.statusIcon,"aria-hidden":"true"},m().createElement("svg",{className:L.statusIconSvg,viewBox:"0 0 24 24",role:"img","aria-hidden":"true"},m().createElement("path",{d:"M2.5 12h4.1l2.1-5.7 3.9 11.4 2.1-5.7h6.8",fill:"none",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"}),m().createElement("circle",{cx:"12",cy:"12",r:"10",fill:"none",stroke:"currentColor",strokeOpacity:"0.28",strokeWidth:"1.4"}))),m().createElement("div",{className:L.statusMain},m().createElement("div",{className:L.title},"Anomaly Detector"),m().createElement("div",{className:L.headerMetaGrid},m().createElement("span",null,"Algorithm: ",m().createElement("span",{className:L.metaAccent},j.algorithm)),m().createElement("span",null,"Bucket: ",Ta),m().createElement("span",null,"Series: ",me(ar,34)),m().createElement("span",null,"Datasource: ",ur)),V?m().createElement("div",{className:L.staleBanner},"Showing the last good snapshot while Grafana refreshes the query result."):null),m().createElement("div",{className:L.statusStats},m().createElement("div",{className:`${L.statCard} ${L.statCardPrimary}`},m().createElement("div",{className:L.statLabel},"Severity"),m().createElement("div",{className:L.statValue},J[Gt.severityLabel]),m().createElement("div",{className:L.statCaption},At?`Since ${ge(At.time,aa,l)}`:`Peak ${se(Qt)}`)),m().createElement("div",{className:L.statCard},m().createElement("div",{className:L.statLabel},"Confidence"),m().createElement("div",{className:L.statValue},cr,"%"),m().createElement("div",{className:L.statCaption},or)),m().createElement("div",{className:L.statCard},m().createElement("div",{className:L.statLabel},"Anomalies"),m().createElement("div",{className:L.statValue},Ut),m().createElement("div",{className:L.statCaption},"clustered")),m().createElement("div",{className:L.statCard},m().createElement("div",{className:L.statLabel},"Data quality"),m().createElement("div",{className:L.statValue,style:{color:"#4ADE80"}},dr),m().createElement("div",{className:L.statCaption},mr,"%")))),m().createElement("div",{className:L.recommendationBanner},m().createElement("div",{className:L.recommendationBadge},j.recommendation.badge),m().createElement("div",{className:L.recommendationCopy},m().createElement("div",{className:L.recommendationTitle},j.recommendation.title),m().createElement("div",{className:L.recommendationText},j.recommendation.reason,j.recommendation.matchedNames.length>0?` Matched metrics: ${j.recommendation.matchedNames.slice(0,3).join(", ")}.`:""))),dt?m().createElement("div",{className:L.actionNotice},m().createElement("span",{className:L.recommendationBadge,style:{background:"success"===dt.tone?`${X.low}22`:`${X.critical}22`,color:"success"===dt.tone?X.low:X.critical}},"success"===dt.tone?"Action complete":"Action needed"),m().createElement("div",{className:L.recommendationCopy},m().createElement("div",{className:L.recommendationTitle},"success"===dt.tone?"Ready to continue":"Could not finish action"),m().createElement("div",{className:L.recommendationText},dt.message))):null,m().createElement("div",{className:L.incidentHeader},m().createElement("div",{className:L.cardTitle},"Detected incidents"),m().createElement("div",{className:L.severityLegend,"aria-label":"Incident severity legend"},["critical","high","medium","low"].map(e=>m().createElement("span",{key:e,className:L.severityLegendItem},m().createElement("span",{className:L.severityLegendSwatch,style:{background:X[e]}}),J[e])))),Na.length>0?m().createElement("div",{className:L.incidentRibbonPanel,"aria-label":"Detected incident overview"},m().createElement("svg",{width:"100%",height:"34",viewBox:`0 0 ${ua} 34`,preserveAspectRatio:"none",role:"img","aria-label":"Detected incident overview"},m().createElement("rect",{x:ha.left,y:11,width:ga,height:12,rx:6,fill:M.isDark?"#252C38":"#E2E8F0",opacity:.88}),Na.map(e=>{const t=Math.max(ha.left,ya(e.start)),a=Math.min(ua-ha.right,ya(e.end)),r=Math.max(8,a-t),n=we(St)===we(e.selection),i=X[e.severityLabel];return m().createElement("g",{key:`overview-${e.key}`,style:{cursor:"pointer"},onClick:()=>{Xe(e.selection),ct(e.center),nt(e.center)}},m().createElement("title",null,`${e.label} | ${J[e.severityLabel]} ${e.severityScore} | ${ge(e.center,aa,l)}`),m().createElement("rect",{x:t,y:11,width:r,height:12,rx:6,fill:i,fillOpacity:n?1:.82,stroke:n?M.isDark?"#F8FAFC":"#0F172A":"none",strokeWidth:n?1.2:0}),e.count>1&&r>=28?m().createElement("g",null,m().createElement("rect",{x:t+r/2-13,y:2,width:26,height:18,rx:8,fill:i,stroke:M.isDark?"#7F1D1D":"#FFFFFF",strokeWidth:1}),m().createElement("text",{x:t+r/2,y:15,textAnchor:"middle",fill:"#FFFFFF",fontSize:"10",fontWeight:"900",pointerEvents:"none"},"x",e.count)):null)}))):m().createElement("div",{className:L.incidentRibbonPanel,"aria-label":"Detected incident overview"},m().createElement("div",{className:L.incidentRibbonEmpty},"No clustered incidents in this time range.")),m().createElement("div",{className:L.chartCard,ref:wt,tabIndex:0,onKeyDown:e=>{if((e=>e instanceof HTMLElement&&(["BUTTON","INPUT","TEXTAREA","SELECT","A"].includes(e.tagName)||e.isContentEditable))(e.target)||0===Nt.length)return;const t=Nt.findIndex(e=>we(e.selection)===Mt),a=t>=0?t:0;if("ArrowRight"===e.key||"ArrowDown"===e.key){e.preventDefault();const t=Nt[(a+1)%Nt.length];return void Lt(t)}if("ArrowLeft"===e.key||"ArrowUp"===e.key){e.preventDefault();const t=Nt[(a-1+Nt.length)%Nt.length];return void Lt(t)}if("Enter"===e.key||" "===e.key){const t=Nt[a];if(!t)return;return e.preventDefault(),ct(e=>e===t.time?null:t.time),void nt(t.time)}"Escape"===e.key&&(e.preventDefault(),ct(null),nt(null))},"aria-label":"Anomaly chart. Use left and right arrows to move between incidents, Enter to pin, and Escape to clear."},m().createElement("svg",{width:"100%",height:"100%",viewBox:`0 0 ${ua} ${pa}`,preserveAspectRatio:"none",role:"img","aria-label":"Anomaly chart",onMouseMove:e=>{const t=e.currentTarget.getBoundingClientRect(),a=(e.clientX-t.left)/t.width*ua;if(a<ha.left||a>ua-ha.right)return void(null===st&&nt(null));const r=(e=>{if(Xt===Jt)return Jt;const t=Math.max(0,Math.min(1,(e-ha.left)/ga));return Jt+t*(Xt-Jt)})(a),n=Te(Kt,r);nt(n>=0?Kt[n]:null)},onMouseLeave:()=>{null===st&&nt(null)},onClick:()=>{Dt&&ct(e=>e===Dt.time?null:Dt.time)},style:{width:"100%",height:"100%",display:"block",cursor:"crosshair"}},m().createElement("defs",null,m().createElement("clipPath",{id:yr},m().createElement("rect",{x:ha.left,y:ha.top,width:ga,height:fa,rx:12}))),m().createElement("rect",{x:0,y:0,width:ua,height:pa,fill:M.isDark?"#08111F":"#FFFFFF"}),m().createElement("rect",{x:8,y:ha.top-8,width:ha.left-16,height:fa+16,rx:16,fill:vr,opacity:.96}),m().createElement("text",{transform:`translate(22 ${ha.top+fa/2}) rotate(-90)`,textAnchor:"middle",fill:br,fontSize:"11",fontWeight:"700",letterSpacing:"0.08em"},"VALUE"),m().createElement("text",{x:ua-ha.right,y:pa-16,textAnchor:"end",fill:br,fontSize:"11",fontWeight:"700",letterSpacing:"0.08em"},"TIME (",oa,")"),Ea.map((e,t)=>{const a=ya(e),r=0===t?"start":t===Ea.length-1?"end":"middle";return m().createElement("g",{key:`top-x-${t}`},m().createElement("text",{x:a,y:ha.top-10,textAnchor:r,fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},((e,t,a)=>t<=2592e5?(0,c.dateTimeFormat)(e,{format:"ddd DD/MM",timeZone:a}):(0,c.dateTimeFormat)(e,{format:"DD/MM/YYYY",timeZone:a}))(e,aa,l)))}),gr?m().createElement("rect",{x:Math.max(ha.left,gr.x),y:ha.top,width:Math.min(gr.width,ga),height:gr.height,fill:M.isDark?"rgba(59,130,246,0.10)":"rgba(37,99,235,0.08)",stroke:M.isDark?"rgba(96,165,250,0.35)":"rgba(37,99,235,0.25)",rx:8}):null,m().createElement("rect",{x:ha.left,y:ha.top,width:ga,height:fa,rx:12,fill:M.isDark?"#06101E":"#FFFFFF",stroke:M.isDark?"#142033":"#E2E8F0"}),ka.map((e,t)=>{const a=ba(e);return m().createElement("g",{key:`y-${t}`},m().createElement("line",{x1:ha.left,y1:a,x2:ua-ha.right,y2:a,stroke:M.isDark?"#1E293B":"#E2E8F0",strokeOpacity:.78,strokeDasharray:"3 6"}),m().createElement("rect",{x:14,y:a-10,width:ha.left-28,height:20,rx:10,fill:xr,opacity:M.isDark?.84:.96}),m().createElement("text",{x:ha.left-18,y:a+4,textAnchor:"end",fill:M.isDark?"#E2E8F0":"#0F172A",fontSize:"12",fontWeight:"700"},(e=>{if(!Number.isFinite(e))return"";const t=Math.abs(e);return t>=1e3?e.toLocaleString(void 0,{notation:"compact",maximumFractionDigits:1}):t>=100?e.toLocaleString(void 0,{maximumFractionDigits:0}):t>=10?e.toLocaleString(void 0,{maximumFractionDigits:1}):t>=1?e.toLocaleString(void 0,{maximumFractionDigits:2}):e.toLocaleString(void 0,{maximumFractionDigits:3})})(e)))}),wa.map((e,t)=>{const a=ya(e),r=0===t?"start":t===wa.length-1?"end":"middle";return m().createElement("g",{key:`x-${t}`},t>0&&t<wa.length-1?m().createElement("line",{x1:a,y1:ha.top,x2:a,y2:pa-ha.bottom,stroke:M.isDark?"#162336":"#E2E8F0",strokeOpacity:.45}):null,m().createElement("text",{x:a,y:pa-12,textAnchor:r,fill:M.isDark?"#94A3B8":"#64748B",fontSize:"11"},he(e,aa,j.timeAxisDensity,l)))}),null!==wr?m().createElement("g",{pointerEvents:"none"},m().createElement("line",{x1:wr,y1:ha.top,x2:wr,y2:Aa,stroke:M.isDark?"#93C5FD":"#2563EB",strokeDasharray:"5 5",strokeOpacity:.72,strokeWidth:1.35}),m().createElement("rect",{x:Math.max(ha.left+6,Math.min(wr-52,ua-ha.right-104)),y:ha.top+24,width:104,height:20,rx:10,fill:M.isDark?"#0F172A":"#FFFFFF",stroke:M.isDark?"#334155":"#CBD5E1"}),m().createElement("text",{x:Math.max(ha.left+58,Math.min(wr,ua-ha.right-52)),y:ha.top+38,textAnchor:"middle",fill:M.isDark?"#E2E8F0":"#0F172A",fontSize:"11",fontWeight:"700"},he(null!==(b=null==Dt?void 0:Dt.time)&&void 0!==b?b:Jt,aa,"dense",l))):null,"multi"===j.detectionMode&&fr.length>0?m().createElement("g",null,fr.map(({event:e,x:t,width:a,centerX:r})=>{const n="event"===(null==St?void 0:St.kind)&&St.time===e.time,i=X[e.severityLabel],l=fe(e.severityLabel,j.markerShapeMode),s="high"===e.confidenceLabel?.18:"medium"===e.confidenceLabel?.12:.08,o=ha.top+18;return m().createElement("g",{key:`event-${e.time}`,style:{cursor:"pointer"},onClick:()=>{Xe({kind:"event",time:e.time}),ct(e.time)}},m().createElement("title",null,`Combined anomaly at ${ce(e.time)} | Score ${le(e.score)} | ${J[e.severityLabel]} | ${ee[e.confidenceLabel]}`),m().createElement("rect",{x:t,y:ha.top+1,width:a,height:fa-2,rx:n?10:8,fill:i,fillOpacity:n?.18:s}),m().createElement("rect",{x:t,y:ha.top+4,width:a,height:4,rx:2,fill:i,fillOpacity:n?.95:"high"===e.confidenceLabel?.8:.62}),m().createElement("rect",{x:t,y:ha.top+fa-6,width:a,height:3,rx:1.5,fill:i,fillOpacity:n?.9:"high"===e.confidenceLabel?.72:.5}),m().createElement("line",{x1:r,y1:o+8,x2:r,y2:Aa-8,stroke:i,strokeOpacity:n?.74:.38,strokeWidth:n?1.8:1.25,strokeDasharray:"4 5"}),be(l,r,o,n?7.5:6.2,M.isDark?"#08111F":"#FFFFFF",i,n?2.8:2.2),be(l,r,o,n?3:2.5,i))})):null,m().createElement("g",{clipPath:`url(#${yr})`},ye.map(e=>{const a=!1===t.showBands?"":((e,t,a)=>{const r=e.filter(e=>null!==e.lower&&null!==e.upper);if(r.length<2)return"";const n=r.map(e=>`${t(e.time).toFixed(2)},${a(e.upper).toFixed(2)}`),i=[...r].reverse().map(e=>`${t(e.time).toFixed(2)},${a(e.lower).toFixed(2)}`);return`M${n.join(" L")} L${i.join(" L")} Z`})(e.points,ya,ba),r=Ce(e.points,ya,ba,e=>e.value),n=j.showExpectedLine?Ce(e.points,ya,ba,e=>e.expected):"",i="point"===(null==St?void 0:St.kind)&&St.seriesKey===e.key?St.time:null,l=j.markerShapeMode,s=Math.max(54,ga/12),o=Math.max(12,ga/44),c="multi"===j.detectionMode?[]:Pe(De(e.points.filter(e=>e.isAnomaly),ya,Ca?s:o,i),Ca?2:8,i);return m().createElement("g",{key:e.key},a?m().createElement("path",{d:a,fill:e.color,opacity:At&&"point"===At.kind&&At.seriesKey===e.key?.14:.07}):null,n?m().createElement("path",{d:n,fill:"none",stroke:e.color,strokeOpacity:.32,strokeWidth:1.3,strokeDasharray:"6 6"}):null,m().createElement("path",{d:r,fill:"none",stroke:e.color,strokeWidth:2.6,strokeLinecap:"round",strokeLinejoin:"round"}),c.map(t=>{const a="point"===(null==St?void 0:St.kind)&&St.seriesKey===e.key&&St.time===t.time,r=ya(t.time),n=ba(t.value),i=fe(t.severityLabel,l),s=a?11:"high"===t.confidenceLabel?8.4:"medium"===t.confidenceLabel?7.4:6.2;return m().createElement("g",{key:`${e.key}-${t.time}`,style:{cursor:"pointer"},onClick:()=>{Xe({kind:"point",seriesKey:e.key,time:t.time}),ct(t.time)}},m().createElement("title",null,`${e.label} | ${ce(t.time)} | ${J[t.severityLabel]} | ${ee[t.confidenceLabel]}`),m().createElement("line",{x1:r,y1:ha.top+18,x2:r,y2:Math.max(ha.top+26,n-10),stroke:X[t.severityLabel],strokeOpacity:a?.72:.3,strokeWidth:a?1.7:1.2,strokeDasharray:"4 5"}),m().createElement("circle",{cx:r,cy:n,r:s,fill:te[t.confidenceLabel],opacity:a?.28:.18}),be(i,r,n,a?7.2:5.4,M.isDark?"#111827":"#FFFFFF",X[t.severityLabel],a?2.8:2.4),be(i,r,n,a?3.2:2.6,X[t.severityLabel],void 0,0,"high"===t.confidenceLabel?.96:.8),m().createElement("circle",{cx:r,cy:n,r:11,fill:"transparent"}))}))})),Da.map(e=>{const t=Math.max(ha.left+8,e.anchorX-e.width),a=t-8;return m().createElement("g",{key:`inline-${e.key}`},m().createElement("line",{x1:e.lastX,y1:e.lastY,x2:a,y2:e.labelY,stroke:e.color,strokeOpacity:.78,strokeWidth:1.4}),m().createElement("rect",{x:t,y:e.labelY-11,width:e.width,height:22,rx:11,fill:M.isDark?"#0F172A":"#FFFFFF",stroke:e.color,strokeOpacity:.48}),m().createElement("circle",{cx:t+11,cy:e.labelY,r:3,fill:e.color}),m().createElement("text",{x:t+19,y:e.labelY+4,fill:M.isDark?"#E2E8F0":"#0F172A",fontSize:"11",fontWeight:"700"},e.label))}),$a?(()=>{const e=ha.left+14,t=Math.max(ga-28,48),a=La,r=Math.max(Ma-28,18),n=$a.minValue,i=$a.maxValue,s=Math.max(i-n,1e-6),o=a=>e+(a-$a.startTime)/Math.max($a.endTime-$a.startTime,1)*t,c=e=>a+18+r-(e-n)/s*r,d=o($a.bucketStart),u=o(Math.max($a.bucketEnd,$a.selectedTime));return m().createElement("g",null,m().createElement("rect",{x:ha.left+6,y:a,width:ga-12,height:Ma,rx:14,fill:M.isDark?"rgba(8,17,31,0.92)":"rgba(255,255,255,0.94)",stroke:M.isDark?"#1E293B":"#D7E3F4"}),m().createElement("text",{x:e,y:a+14,fill:M.isDark?"#CBD5E1":"#334155",fontSize:"10",fontWeight:"700",letterSpacing:"0.08em"},"FOCUSED ANOMALY WINDOW"),m().createElement("text",{x:ua-ha.right-8,y:a+14,textAnchor:"end",fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},$a.title),m().createElement("rect",{x:Math.min(d,u),y:a+18,width:Math.max(Math.abs(u-d),8),height:r,rx:8,fill:M.isDark?"rgba(59,130,246,0.14)":"rgba(37,99,235,0.10)",stroke:M.isDark?"rgba(96,165,250,0.28)":"rgba(37,99,235,0.22)"}),$a.series.map(e=>{const t=Ce(e.points,o,c,e=>e.value);return m().createElement("path",{key:`focus-${e.key}`,d:t,fill:"none",stroke:e.color,strokeWidth:1.8,strokeOpacity:"point"===(null==St?void 0:St.kind)&&St.seriesKey===e.key?1:.78,strokeLinecap:"round",strokeLinejoin:"round"})}),m().createElement("line",{x1:o($a.selectedTime),y1:a+18,x2:o($a.selectedTime),y2:a+18+r,stroke:M.isDark?"#93C5FD":"#2563EB",strokeDasharray:"4 4",strokeWidth:1.4}),m().createElement("text",{x:e,y:a+Ma-8,fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10"},he($a.startTime,$a.endTime-$a.startTime,"dense",l)),m().createElement("text",{x:o($a.selectedTime),y:a+Ma-8,textAnchor:"middle",fill:M.isDark?"#E2E8F0":"#0F172A",fontSize:"10",fontWeight:"700"},he($a.selectedTime,$a.endTime-$a.startTime,"dense",l)),m().createElement("text",{x:ua-ha.right-8,y:a+Ma-8,textAnchor:"end",fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10"},he($a.endTime,$a.endTime-$a.startTime,"dense",l)))})():null,m().createElement("rect",{x:ha.left,y:ha.top,width:ga,height:fa,rx:12,fill:"none",stroke:M.isDark?"#22314A":"#D7E3F4"})),Dt?m().createElement("div",{style:R(_({position:"absolute",top:18},null!=Sr?Sr:{}),{width:272,pointerEvents:null!==st?"auto":"none",borderRadius:16,border:"1px solid "+(M.isDark?"#334155":"#CBD5E1"),background:M.isDark?"rgba(8,17,31,0.96)":"rgba(255,255,255,0.96)",boxShadow:M.isDark?"0 18px 42px rgba(2,6,23,0.42)":"0 18px 42px rgba(15,23,42,0.12)",padding:"12px 14px",display:"flex",flexDirection:"column",gap:8,backdropFilter:"blur(8px)"})},m().createElement("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:8}},m().createElement("div",{style:{minWidth:0}},m().createElement("div",{style:{fontSize:12,fontWeight:800,color:M.isDark?"#F8FAFC":"#0F172A"}},ge(Dt.time,aa,l)),m().createElement("div",{style:{fontSize:11,color:M.isDark?"#94A3B8":"#64748B"}},(null===(N=Dt.event)||void 0===N?void 0:N.isAnomaly)?`Cross-metric incident | ${Dt.event.activeSeries} aligned metric${1===Dt.event.activeSeries?"":"s"}`:Dt.anomalyCount>0?`${Dt.anomalyCount} flagged signal${1===Dt.anomalyCount?"":"s"} at this time`:"Live metric snapshot")),m().createElement("div",{style:{display:"flex",alignItems:"center",gap:8}},m().createElement("span",{style:{display:"inline-flex",alignItems:"center",borderRadius:999,padding:"4px 8px",fontSize:10,fontWeight:800,background:`${X[Dt.severityLabel]}22`,color:X[Dt.severityLabel]}},J[Dt.severityLabel]," ",Dt.severityScore),null!==st?m().createElement("button",{type:"button",onClick:e=>{e.stopPropagation(),ct(null)},style:{border:"1px solid "+(M.isDark?"#334155":"#CBD5E1"),background:M.isDark?"#0F172A":"#F8FAFC",color:M.isDark?"#E2E8F0":"#334155",borderRadius:999,padding:"4px 8px",fontSize:10,fontWeight:700,cursor:"pointer"}},"Unpin"):null)),m().createElement("div",{style:{display:"flex",flexDirection:"column",gap:6}},Dt.series.slice(0,4).map(e=>m().createElement("div",{key:`tooltip-${e.key}`,style:{display:"grid",gridTemplateColumns:"minmax(0,1fr) auto auto",gap:8,alignItems:"center",padding:"6px 8px",borderRadius:12,background:M.isDark?"rgba(15,23,42,0.72)":"#F8FAFC",border:"1px solid "+(M.isDark?"#1E293B":"#E2E8F0")}},m().createElement("div",{style:{minWidth:0,display:"flex",alignItems:"center",gap:8}},m().createElement("span",{style:{width:8,height:8,borderRadius:999,background:e.color,flex:"0 0 auto"}}),m().createElement("span",{style:{fontSize:11,fontWeight:700,color:M.isDark?"#E2E8F0":"#0F172A",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}},me(e.label,24))),m().createElement("span",{style:{fontSize:11,fontWeight:700,color:M.isDark?"#F8FAFC":"#0F172A"}},le(e.actual)),m().createElement("span",{style:{fontSize:10,fontWeight:700,color:e.isAnomaly?X[e.severityLabel]:M.isDark?"#94A3B8":"#64748B"}},e.isAnomaly?J[e.severityLabel]:"normal"))))):null),m().createElement("div",{className:L.bottomDock},m().createElement("div",{className:L.legendTable,"aria-label":"Series anomaly summary"},m().createElement("div",{className:L.legendTableHeader},m().createElement("span",null,"Series (",jt,")"),m().createElement("span",null,"Flagged"),m().createElement("span",null,"Max"),m().createElement("span",null,"Last")),pr.map(e=>{var t;const a=null!==(t=e.allPoints[e.allPoints.length-1])&&void 0!==t?t:null;return m().createElement("div",{key:e.key,className:L.legendTableRow,title:`${e.label} | ${e.anomalyCount} flagged buckets | max ${se(e.maxSeverityScore)}`},m().createElement("span",{className:L.legendSeriesName},m().createElement("span",{className:L.legendSwatch,style:{background:e.color}}),m().createElement("span",{style:{minWidth:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}},e.label)),m().createElement("span",{className:L.legendValue,style:{color:e.anomalyCount>0?X[e.maxSeverityLabel]:void 0}},e.anomalyCount),m().createElement("span",{className:L.legendValue},se(e.maxSeverityScore)),m().createElement("span",{className:L.legendValue},a?le(a.value):"n/a"))}),hr>0?m().createElement("div",{className:L.legendTableFooter},m().createElement("span",null,"Showing top ",pr.length," active series"),m().createElement("span",null,"+",hr," more hidden to keep the panel readable")):null),Wt),!1!==t.showSummary?m().createElement("div",{className:L.secondaryDock},m().createElement("div",{className:L.card},m().createElement("div",{className:L.cardTitle},"Detected incidents"),Nt.length>0?m().createElement("div",{className:L.summaryTimeline},m().createElement("div",{className:L.subtitle},"Incident timeline"),m().createElement("svg",{width:"100%",height:"56",viewBox:"0 0 320 56",role:"img","aria-label":"Incident timeline overview"},m().createElement("line",{x1:18,y1:28,x2:302,y2:28,stroke:M.isDark?"#22314A":"#CBD5E1",strokeWidth:4,strokeLinecap:"round"}),Nt.map((e,t)=>{const a=Xt===Jt?160:18+(e.time-Jt)/Math.max(Xt-Jt,1)*284,r=we(e.selection)===Mt,n=fe(e.severityLabel,j.markerShapeMode);return m().createElement("g",{key:`summary-timeline-${e.key}`,style:{cursor:"pointer"},onClick:()=>Lt(e)},m().createElement("title",null,`${e.title} | ${ge(e.time,aa,l)}`),m().createElement("line",{x1:a,y1:16,x2:a,y2:40,stroke:X[e.severityLabel],strokeOpacity:r?.85:.4,strokeWidth:r?2:1.3}),be(n,a,28,r?7:5.4,M.isDark?"#08111F":"#FFFFFF",X[e.severityLabel],r?2.5:2),r?m().createElement("circle",{cx:a,cy:28,r:10.5,fill:"none",stroke:M.isDark?"#E2E8F0":"#0F172A",strokeOpacity:.4,strokeWidth:1.3}):null,0===t?m().createElement("text",{x:a,y:50,textAnchor:"start",fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},he(e.time,aa,"compact",l)):t===Nt.length-1?m().createElement("text",{x:a,y:50,textAnchor:"end",fill:M.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},he(e.time,aa,"compact",l)):null)}))):null,m().createElement("div",{className:L.summaryList},0===He.length?m().createElement("div",{className:L.subtitle},"No operationally relevant incidents crossed the active threshold in the selected time range."):He.map(e=>m().createElement("button",{key:e.key,type:"button","aria-label":`Detected incident ${e.title}`,className:`${L.summaryRow} ${Mt===we(e.selection)?L.summaryRowSelected:""}`,onClick:()=>Lt(e),style:{textAlign:"left",color:"inherit"}},m().createElement("div",{className:L.summaryMeta},m().createElement("span",{className:L.summaryTitle,title:e.title},e.title),m().createElement("span",{className:L.severityBadge,style:{background:`${X[e.severityLabel]}22`,color:X[e.severityLabel]}},J[e.severityLabel]," ",e.severityScore)),m().createElement("div",{className:L.subtitle},e.subtitle),m().createElement("div",{className:L.recommendationText},e.detail))))),m().createElement("div",{className:`${L.card} ${L.inlineInspectorLegacy}`},m().createElement("div",{className:L.cardTitle},"Legacy inspector details"),At?m().createElement(m().Fragment,null,m().createElement("div",{className:L.recommendationText},At.title),m().createElement("div",{className:L.subtitle},At.subtitle),m().createElement("div",{className:L.recommendationText},_a),m().createElement("div",{className:L.actionRow},m().createElement("button",{type:"button",className:L.actionButton,disabled:!Xa||!Q,onClick:()=>{Xa?Q?et(Xa).then(()=>mt({tone:"success",message:"Created a Grafana annotation for the selected anomaly."})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to create the Grafana annotation."})):mt({tone:"error",message:"Save the dashboard once before creating Grafana annotations from the panel."}):mt({tone:"error",message:"Select an anomaly first to create an annotation."})}},"Create annotation"),m().createElement("button",{type:"button",className:L.actionButtonSecondary,disabled:!Oa,onClick:()=>{Oa?Je(Oa).then(()=>mt({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):mt({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy alert query"),m().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{er?Je(er).then(()=>mt({tone:"success",message:"Copied the selected anomaly annotation JSON."})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the annotation JSON."})):mt({tone:"error",message:"Select an anomaly first to copy its annotation JSON."})}},"Copy annotation JSON")),Q?null:m().createElement("div",{className:L.subtitle},"Save the dashboard once so Grafana knows which dashboard the new annotation belongs to."),m().createElement("div",{className:L.detailGrid},m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Raw detection score"),m().createElement("div",{className:L.detailValue},le(At.score))),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Alert score (0-100)"),m().createElement("div",{className:L.detailValue,style:{color:X[At.severityLabel]}},J[At.severityLabel]," ",At.severityScore)),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Confidence"),m().createElement("div",{className:L.detailValue,style:{color:te[At.confidenceLabel]}},ee[At.confidenceLabel])),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Data quality"),m().createElement("div",{className:L.detailValue},ae[At.dataQualityLabel])),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Bucket span"),m().createElement("div",{className:L.detailValue},de(At.bucketStart,At.bucketEnd))),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Recommended action"),m().createElement("div",{className:L.detailValue},Fe(At,j.severityPreset)))),"point"===At.kind?m().createElement("div",{className:L.detailGrid},m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Current value"),m().createElement("div",{className:L.detailValue},le(At.actual))),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Expected value"),m().createElement("div",{className:L.detailValue},le(At.expected))),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Change"),m().createElement("div",{className:L.detailValue},le(At.deviation))),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Change %"),m().createElement("div",{className:L.detailValue},oe(At.deviationPercent))),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Expected range"),m().createElement("div",{className:L.detailValue},($r=At.rangeLower,Nr=At.rangeUpper,null===$r||null===Nr?"n/a":`${le($r)} - ${le(Nr)}`))),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Samples in bucket"),m().createElement("div",{className:L.detailValue},At.sampleCount)),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Instant signal"),m().createElement("div",{className:L.detailValue},le(At.pointScore))),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Sustained signal"),m().createElement("div",{className:L.detailValue},le(At.windowScore))),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Main reason"),m().createElement("div",{className:L.detailValue},Se(At.scoreDriver,j.algorithm)))):m().createElement("div",{className:L.metricBreakdownList},m().createElement("div",{className:L.subtitle},"Metric breakdown"),At.breakdown.map(e=>m().createElement("div",{key:e.label,className:L.metricBreakdownCard,style:{borderColor:M.isDark?`${e.color}55`:`${e.color}66`}},m().createElement("div",{className:L.metricBreakdownHeader},m().createElement("div",null,m().createElement("div",{className:L.metricBreakdownTitle,style:{color:e.color}},e.label),m().createElement("div",{className:L.metricBreakdownReason},Se(e.scoreDriver,j.algorithm)," | ",ee[e.confidenceLabel])),m().createElement("span",{className:L.severityBadge,style:{background:`${X[e.severityLabel]}22`,color:X[e.severityLabel]}},J[e.severityLabel]," ",e.severityScore)),m().createElement("div",{className:L.metricBreakdownGrid},m().createElement("div",{className:L.metricBreakdownStat},m().createElement("div",{className:L.metricBreakdownStatLabel},"Current"),m().createElement("div",{className:L.metricBreakdownStatValue},le(e.actual))),m().createElement("div",{className:L.metricBreakdownStat},m().createElement("div",{className:L.metricBreakdownStatLabel},"Expected"),m().createElement("div",{className:L.metricBreakdownStatValue},le(e.expected))),m().createElement("div",{className:L.metricBreakdownStat},m().createElement("div",{className:L.metricBreakdownStatLabel},"Change"),m().createElement("div",{className:L.metricBreakdownStatValue},le(e.deviation))),m().createElement("div",{className:L.metricBreakdownStat},m().createElement("div",{className:L.metricBreakdownStatLabel},"Main reason"),m().createElement("div",{className:L.metricBreakdownStatValue},Se(e.scoreDriver,j.algorithm))),m().createElement("div",{className:L.metricBreakdownStat},m().createElement("div",{className:L.metricBreakdownStatLabel},"Confidence"),m().createElement("div",{className:L.metricBreakdownStatValue,style:{color:te[e.confidenceLabel]}},ee[e.confidenceLabel])),m().createElement("div",{className:L.metricBreakdownStat},m().createElement("div",{className:L.metricBreakdownStatLabel},"Strength"),m().createElement("div",{className:L.metricBreakdownStatValue,style:{color:X[e.severityLabel]}},le(e.score)))))))):m().createElement("div",{className:L.subtitle},"Select a detected incident to see why it was flagged, how strong the signal is, and whether it is ready for alerting.")),m().createElement("div",{className:L.sideUtilityStack},m().createElement("div",{className:`${L.card} ${L.profileCard}`},m().createElement("div",{className:L.cardTitle},"Active detection profile"),m().createElement("div",{className:`${L.recommendationText} ${L.profileSummary}`},Pa),m().createElement("div",{className:L.profileDetailGrid},m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Setup mode"),m().createElement("div",{className:L.detailValue},z[j.setupMode])),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Metric preset"),m().createElement("div",{className:L.detailValue},U[j.metricPreset])),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Effective preset"),m().createElement("div",{className:L.detailValue},"custom"===j.effectiveMetricPreset?"Custom":U[j.effectiveMetricPreset])),m().createElement("div",{className:L.detailStat},m().createElement("div",{className:L.detailLabel},"Severity preset"),m().createElement("div",{className:L.detailValue},Z[j.severityPreset])))),!1!==t.showExports?m().createElement("div",{className:`${L.card} ${L.handoffCard}`},m().createElement("div",{className:L.handoffHeader},m().createElement("div",{style:{minWidth:0,flex:"1 1 220px"}},m().createElement("div",{className:L.cardTitle},"Alerting & automation"),m().createElement("div",{className:L.subtitle},"Optional handoff only. Daily alert setup should use the inspector buttons; expand this when you need raw JSON.")),m().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>vt(e=>!e)},bt?"Hide exports":"Show exports")),bt?m().createElement(m().Fragment,null,m().createElement("div",{className:L.feedRuleCard},m().createElement("div",{className:L.handoffHeader},m().createElement("div",{className:L.cardTitle},"Annotation export"),m().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{Je(Ra).then(()=>mt({tone:"success",message:"Copied the annotation export JSON."})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the annotation export JSON."}))}},"Copy JSON")),m().createElement("div",{className:L.subtitle},"Use this JSON as a ready annotation or incident handoff payload."),m().createElement("pre",{className:L.monoBlock},Ra)),m().createElement("div",{className:L.feedRuleCard},m().createElement("div",{className:L.handoffHeader},m().createElement("div",{style:{minWidth:0,flex:"1 1 220px"}},m().createElement("div",{className:L.cardTitle},"Alert rule export"),m().createElement("div",{className:L.subtitle},Oa?`Paste this ${Pt} into Grafana Alerting, then set WHEN QUERY IS ABOVE ${Va} FOR 10m and evaluate every 3m.`:"Sync anomaly score feed first to generate an alert-ready anomaly score query.")),m().createElement("button",{type:"button",className:L.actionButtonSecondary,disabled:!Oa,onClick:()=>{Oa?Je(Oa).then(()=>mt({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>mt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):mt({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy query")),m().createElement("div",null,m().createElement("div",{className:L.subtitle},"Suggested labels"),m().createElement("div",{className:L.labelChipGrid,style:{marginTop:8}},Object.entries(Ua).map(([e,t])=>m().createElement("span",{key:e,className:L.labelChip,title:`${e}=${t}`},m().createElement("span",{className:L.labelChipKey},e),m().createElement("span",null,"="),m().createElement("span",{className:L.labelChipValue},t))))),m().createElement("div",{className:L.codeLine},Oa||"Sync anomaly score feed first to generate an alert-ready query."),m().createElement("pre",{className:L.monoBlock},Ja))):null):null)):null),m().createElement("aside",{className:L.inspectorRail},Fr)));var $r,Nr}).setPanelOptions(e=>e.addTextInput({path:"title",name:"Panel title",description:"Short label shown above the anomaly chart.",defaultValue:"Anomaly detector",category:Nt}).addRadio({path:"setupMode",name:"Setup mode",description:"Recommended mode keeps the UI simple. Advanced mode unlocks manual algorithm controls.",defaultValue:"recommended",settings:{options:Bt},category:Nt}).addSelect({path:"metricPreset",name:"Metric type",description:"Start with Auto unless you already know the metric family.",defaultValue:"auto",settings:{options:_t},category:Nt,showIf:e=>"advanced"!==e.setupMode&&"custom"!==e.metricPreset}).addRadio({path:"detectionMode",name:"Detection mode",description:"Single metric scores each series independently. Multi metric combines same-timestamp signals into one event score.",defaultValue:"single",settings:{options:Dt},category:Nt}).addSelect({path:"scoreFeedMode",name:"Score feed mode",description:"Publish the anomaly scores detected by this plugin panel to Prometheus metrics or an exporter sink.",defaultValue:"auto",settings:{options:Tt},category:Mt}).addSelect({path:"scoreFeedTarget",name:"Score feed target",description:"Choose where the plugin-computed anomaly score snapshot is published.",defaultValue:"prometheus",settings:{options:Pt},category:Mt,showIf:e=>"off"!==e.scoreFeedMode}).addTextInput({path:"scoreFeedEndpoint",name:"Exporter endpoint",description:"Browser-side endpoint for the anomaly exporter. The plugin posts detected score snapshots here.",defaultValue:"http://127.0.0.1:9110",category:Mt,showIf:e=>"off"!==e.scoreFeedMode}).addTextInput({path:"scoreFeedRuleNamePrefix",name:"Rule name prefix",description:"Optional short prefix used when naming the published anomaly score feed for this panel.",defaultValue:"",category:Mt,showIf:e=>"off"!==e.scoreFeedMode}).addSelect({path:"bucketSpan",name:"Bucket span",description:"Optional pre-aggregation before anomaly scoring. Auto keeps the panel responsive on large or live queries.",defaultValue:"auto",settings:{options:Rt},category:Lt}).addSelect({path:"algorithm",name:"Algorithm",description:"Visible in Advanced mode when you want to pick the scoring strategy yourself.",defaultValue:"zscore",settings:{options:Ot},category:At,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"sensitivity",name:"Anomaly threshold",description:"Higher values flag fewer anomalies across all algorithms.",defaultValue:4,category:At,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"baselineWindow",name:"History window",description:"Lookback for z-score and MAD, smoothing horizon for EWMA, and peer depth for seasonal mode.",defaultValue:12,category:At,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"seasonalitySamples",name:"Season length (samples)",description:"Used by cycle-based seasonal mode. Example: 24 for an hourly pattern or 288 for a daily pattern in 5-minute data.",defaultValue:24,category:At,showIf:e=>("advanced"===e.setupMode||"custom"===e.metricPreset)&&"seasonal"===e.algorithm}).addSelect({path:"seasonalRefinement",name:"Seasonal refinement",description:"Choose whether seasonal matching is based on fixed cycles, hour-of-day, or weekday plus hour.",defaultValue:"cycle",settings:{options:Vt},category:At,showIf:e=>("advanced"===e.setupMode||"custom"===e.metricPreset)&&"seasonal"===e.algorithm}).addSelect({path:"severityPreset",name:"Severity preset",description:"Controls how severity scores are translated into warning, high, and critical style labels.",defaultValue:"balanced",settings:{options:It},category:At,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"maxAnomalies",name:"Max anomalies in summary",description:"Limits the number of highest scoring anomalies listed below the chart.",defaultValue:8,category:Ct}).addBooleanSwitch({path:"showBands",name:"Show expected band",defaultValue:!0,category:Ct}).addBooleanSwitch({path:"showExpectedLine",name:"Show expected line",defaultValue:!0,category:Ct}).addBooleanSwitch({path:"showSummary",name:"Show anomaly summary",defaultValue:!0,category:Ct}).addBooleanSwitch({path:"showInlineSeriesLabels",name:"Show inline series labels",description:"Show each series name at the right edge of the chart so the line identity stays visible without scanning the legend.",defaultValue:!0,category:Ct}).addBooleanSwitch({path:"showFocusBand",name:"Show anomaly focus band",description:"Render a zoomed local band around the selected anomaly for faster incident review.",defaultValue:!1,category:Ct}).addSelect({path:"timeAxisDensity",name:"Time axis density",description:"Control how many time labels are shown on the chart.",defaultValue:"auto",settings:{options:qt},category:Ct}).addSelect({path:"timeAxisPlacement",name:"Time axis placement",description:"Choose whether time labels are shown only at the bottom or on both top and bottom edges.",defaultValue:"top_and_bottom",settings:{options:Wt},category:Ct}).addSelect({path:"markerShapeMode",name:"Anomaly marker style",description:"Choose whether severity is communicated with different marker shapes or with classic circular markers.",defaultValue:"severity",settings:{options:zt},category:Ct}).addBooleanSwitch({path:"showExports",name:"Show export blocks",defaultValue:!1,category:Ct,showIf:e=>!1!==e.showSummary}));return o})());
//# sourceMappingURL=module.js.map