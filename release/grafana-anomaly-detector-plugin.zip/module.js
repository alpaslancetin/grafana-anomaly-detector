/* [create-plugin] version: 7.0.7 */
/* [create-plugin] plugin: alpas-anomalydetector-panel@1.5.0 */
define(["@emotion/css","@grafana/data","@grafana/runtime","@grafana/ui","react"],(e,t,a,i,n)=>(()=>{"use strict";var r={89(t){t.exports=e},781(e){e.exports=t},531(e){e.exports=a},7(e){e.exports=i},959(e){e.exports=n}},l={};function o(e){var t=l[e];if(void 0!==t)return t.exports;var a=l[e]={exports:{}};return r[e](a,a.exports,o),a.exports}o.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return o.d(t,{a:t}),t},o.d=(e,t)=>{for(var a in t)o.o(t,a)&&!o.o(e,a)&&Object.defineProperty(e,a,{enumerable:!0,get:t[a]})},o.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),o.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var s={};o.r(s),o.d(s,{plugin:()=>ma});var c=o(781);const d=.2,m=10,u=4;var p=o(959),h=o.n(p),g=o(89),y=o(7),f=o(531);function v(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}function b(e){for(var t=1;t<arguments.length;t++){var a=null!=arguments[t]?arguments[t]:{},i=Object.keys(a);"function"==typeof Object.getOwnPropertySymbols&&(i=i.concat(Object.getOwnPropertySymbols(a).filter(function(e){return Object.getOwnPropertyDescriptor(a,e).enumerable}))),i.forEach(function(t){v(e,t,a[t])})}return e}function x(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);t&&(i=i.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),a.push.apply(a,i)}return a}(Object(t)).forEach(function(a){Object.defineProperty(e,a,Object.getOwnPropertyDescriptor(t,a))}),e}const w=e=>Math.max(3,Math.floor(Number.isFinite(e)?e:3)),E={"1m":6e4,"5m":3e5,"15m":9e5,"1h":36e5},k=(Object.values(E).sort((e,t)=>e-t),{warning_first:{low:35,medium:55,high:72,critical:88},balanced:{low:40,medium:60,high:75,critical:90},page_first:{low:45,medium:65,high:82,critical:95}}),S=e=>{if(!Number.isFinite(e.time)||!Number.isFinite(e.value))return null;const t=Number.isFinite(e.sampleCount)?Math.max(1,Math.floor(e.sampleCount)):1,a=Number.isFinite(e.minValue)?e.minValue:e.value,i=Number.isFinite(e.maxValue)?e.maxValue:e.value;return x(b({},e),{bucketStart:Number.isFinite(e.bucketStart)?e.bucketStart:e.time,bucketEnd:Number.isFinite(e.bucketEnd)?e.bucketEnd:e.time,sampleCount:t,minValue:Math.min(a,i,e.value),maxValue:Math.max(a,i,e.value)})},F=e=>e.map(S).filter(e=>null!==e).sort((e,t)=>e.time-t.time),$=e=>Number.isFinite(e)?Math.max(0,Math.min(100,e)):0,M=e=>e.reduce((e,t)=>e+t,0)/e.length,N=e=>{const t=[...e].sort((e,t)=>e-t),a=Math.floor(t.length/2);return t.length%2==0?(t[a-1]+t[a])/2:t[a]},L=(e,t)=>{if(0===e.length)return 0;const a=null!=t?t:N(e);return 1.4826*N(e.map(e=>Math.abs(e-a)))},A=(e,t)=>{if(e.length<=1)return 0;const a=null!=t?t:M(e),i=e.reduce((e,t)=>e+Math.pow(t-a,2),0)/e.length;return Math.sqrt(i)},C=(e,t)=>Number.isFinite(e)&&e>1e-9?e:Math.max(.02*Math.abs(t),1e-6),B=e=>{const t=[];for(const a of e){const e=t[t.length-1];if(e&&e.time===a.time){const t=e.sampleCount+a.sampleCount;e.value=(e.value*e.sampleCount+a.value*a.sampleCount)/t,e.sampleCount=t,e.minValue=Math.min(e.minValue,a.minValue),e.maxValue=Math.max(e.maxValue,a.maxValue),e.bucketStart=Math.min(e.bucketStart,a.bucketStart),e.bucketEnd=Math.max(e.bucketEnd,a.bucketEnd);continue}t.push(b({},a))}return t},D=(e,t,a)=>{const i=k[a],n=e/Math.max(t,1e-4);if(n<1)return{severityScore:Math.min(i.low-1,Math.round(n*(i.low-1))),severityLabel:"normal"};const r=Math.min(100,Math.round(i.low+30*(n-1)));return r>=i.critical?{severityScore:r,severityLabel:"critical"}:r>=i.high?{severityScore:r,severityLabel:"high"}:r>=i.medium?{severityScore:r,severityLabel:"medium"}:{severityScore:r,severityLabel:"low"}},T=(e,t,a)=>{const i=e.slice(Math.max(0,t-a),t+1),n=i.map(e=>e.value),r=i.slice(-Math.max(4,Math.min(a,8)));if(n.length<Math.max(3,Math.floor(a/2)))return"thin";if(r.length>=3){const e=r.slice(1).map((e,t)=>e.time-r[t].time).filter(e=>e>0),t=e.length>0?N(e):null,a=e.length>0?Math.min(...e):null,i=e.length>0?Math.max(...e):null;if(t&&e.some(e=>e>2.4*t)||a&&i&&i>1.8*a)return"gappy"}if(r.length>=4){const e=r.map(e=>e.value),t=Math.max(.002*Math.abs(M(e)),1e-6);if(Math.max(...e)-Math.min(...e)<=t)return"flatline"}return"healthy"},P=(e,t,a,i,n,r)=>{const l=Math.max(t,1e-6);let o=Math.min(e/l,2.5)/2.5*100;i>a&&(o+=8),n>=8&&(o+=4),"thin"===r?o-=18:"flatline"===r?o-=22:"gappy"===r&&(o-=12);const s=Math.max(5,Math.min(100,Math.round(10*o)/10));return{confidenceScore:s,confidenceLabel:s>=80?"high":s>=55?"medium":"low",dataQualityLabel:r}},_=(e,t,a)=>{const i=D(0,t,a);return x(b(x(b({},e),{expected:null,upper:null,lower:null,score:0,pointScore:0,windowScore:0,scoreDriver:"point",isAnomaly:!1,decisionState:"warming_up"}),i),{confidenceScore:5,confidenceLabel:"low",dataQualityLabel:"thin"})},R=(e,t,a,i)=>{const n=[],r=2/(Math.max(a,2)+1);let l=null;const o=[];return e.forEach((s,c)=>{if(0===c||null===l)return l=s.value,void n.push(_(s,t,i));const d=l,m=C(N(o.slice(-a))||A(e.slice(Math.max(0,c-a),c).map(e=>e.value)),d),u=e.slice(Math.max(0,c-a),c).map(e=>e.value);if(o.push(Math.abs(s.value-d)),l=r*s.value+(1-r)*d,u.length<w(a))return void n.push(_(s,t,i));const p=Math.abs(s.value-d)/m,h=((e,t,a,i,n)=>{const r=Math.min(Math.max(3,Math.floor(n/3)),10),l=[...e.slice(-(r-1)),t];return l.length<3?0:Math.abs(M(l)-a)/i})(u,s.value,d,m,a),g=Math.max(p,h),y=D(g,t,i),f=P(g,t,p,h,u.length+1,T(e,c,a));n.push(b(x(b({},s),{expected:d,lower:d-t*m,upper:d+t*m,score:g,pointScore:p,windowScore:h,scoreDriver:h>p?"window":"point",isAnomaly:g>=t,decisionState:g>=t?"open":"normal"}),y,f))}),n},I=(e,t,a,i,n,r)=>{const l=new Map,o=new Map;return e.map((s,c)=>{let d=[];if("cycle"===n)for(let t=c-i;t>=0&&d.length<a;t-=i)d.push(e[t].value);else{var m,u,p,h;const e=(e=>{const t=new Date(e);return{hour_of_day:`hour:${t.getHours()}`,weekday_hour:`weekday:${t.getDay()}-${t.getHours()}`}})(s.time);var g;if(d="hour_of_day"===n?[...null!==(m=l.get(e.hour_of_day))&&void 0!==m?m:[]].slice(-a):[...null!==(u=o.get(e.weekday_hour))&&void 0!==u?u:[]].slice(-a),"weekday_hour"===n&&d.length<3)d=[...null!==(g=l.get(e.hour_of_day))&&void 0!==g?g:[]].slice(-a);const t=null!==(p=l.get(e.hour_of_day))&&void 0!==p?p:[];t.push(s.value),l.set(e.hour_of_day,t);const i=null!==(h=o.get(e.weekday_hour))&&void 0!==h?h:[];i.push(s.value),o.set(e.weekday_hour,i)}if(d.length<3)return _(s,t,r);const y=e.slice(Math.max(0,c-a),c).map(e=>e.value),{expected:f,spread:v}=((e,t)=>{const a=N(e),i=C(L(e,a),a),n=e.slice(1).map((t,a)=>t-e[a]),r=n.length>=2?N(n):0,l=n.length>=2?C(L(n,r),a):0,o=t.length>0?C(L(t),N(t)):0,s=Math.max(i,l,.75*o);return{expected:a+r,spread:C(s,a+r)}})(d,y),w=Math.abs(s.value-f)/v,E=w,k=D(E,t,r),S=P(E,t,w,0,y.length+1,T(e,c,a));return b(x(b({},s),{expected:f,lower:f-t*v,upper:f+t*v,score:E,pointScore:w,windowScore:0,scoreDriver:0>w?"window":"point",isAnomaly:E>=t,decisionState:E>=t?"open":"normal"}),k,S)})},V=(e,t,a,i)=>{const n=e.map(e=>e.value),r=Math.min(Math.max(3,Math.floor(a/3)),12),l=Math.max(1,r-1),o=Math.max(6*a,a+r),s=Math.max(w(a),6,r+3);return e.map((r,c)=>{const d=Math.max(0,c-o);if(c-d<s)return _(r,t,i);const m=c-l;if(m-d<3)return _(r,t,i);const u=((e,t,a,i)=>{const n=Math.min(t+i,a);return n-t>=3?e.slice(t,n):e.slice(Math.max(t,a-i),a)})(n,d,m,a),p=M(u),h=C(A(u,p),p),g=Math.abs(r.value-p)/h,y=Math.max(0,c-l);let f=r.value,v=Math.abs(r.value-p)>h?1:0;for(let e=y;e<c;e+=1){const t=n[e];f+=t,Math.abs(t-p)>h&&(v+=1)}const w=c-y+1,E=f/w,k=v/w,S=Math.abs(E-p)/h*(1+Math.max(0,k-.4)),F=Math.max(.85*g,S),$=D(F,t,i),N=P(F,t,g,S,u.length+1,T(e,c,a));return b(x(b({},r),{expected:p,lower:p-t*h,upper:p+t*h,score:F,pointScore:g,windowScore:S,scoreDriver:S>=.85*g?"window":"point",isAnomaly:F>=t,decisionState:F>=t?"open":"normal"}),$,N)})},O=(e,t)=>{var a,i,n,r,l,o,s,c,d;const m=Math.max(t.baselineWindow,3),u=Math.max(t.sensitivity,.2),p=B(F(e));let h;switch(t.algorithm){case"mad":h=((e,t,a,i)=>e.map((n,r)=>{const l=e.slice(Math.max(0,r-a),r).map(e=>e.value);if(l.length<w(a))return _(n,t,i);const o=N(l),s=l.map(e=>Math.abs(e-o)),c=C(1.4826*N(s),o),d=Math.abs(n.value-o)/c,m=d,u=D(m,t,i),p=P(m,t,d,0,l.length+1,T(e,r,a));return b(x(b({},n),{expected:o,lower:o-t*c,upper:o+t*c,score:m,pointScore:d,windowScore:0,scoreDriver:0>d?"window":"point",isAnomaly:m>=t,decisionState:m>=t?"open":"normal"}),u,p)}))(p,u,m,t.severityPreset);break;case"ewma":h=R(p,u,m,t.severityPreset);break;case"level_shift":h=V(p,u,m,t.severityPreset);break;case"seasonal":h=I(p,u,m,Math.max(t.seasonalitySamples,2),t.seasonalRefinement,t.severityPreset);break;default:h=((e,t,a,i)=>e.map((n,r)=>{const l=e.slice(Math.max(0,r-a),r).map(e=>e.value);if(l.length<w(a))return _(n,t,i);const o=M(l),s=C(A(l,o),o),c=Math.abs(n.value-o)/s,d=c,m=D(d,t,i),u=P(d,t,c,0,l.length+1,T(e,r,a));return b(x(b({},n),{expected:o,lower:o-t*s,upper:o+t*s,score:d,pointScore:c,windowScore:0,scoreDriver:0>c?"window":"point",isAnomaly:d>=t,decisionState:d>=t?"open":"normal"}),m,u)}))(p,u,m,t.severityPreset)}const g=null!==(a=t.anomalyDirection)&&void 0!==a?a:"high_or_low",y=Math.max(0,null!==(i=t.minimumAbsoluteDeviation)&&void 0!==i?i:0),f=Math.max(0,null!==(n=t.minimumRelativeDeviation)&&void 0!==n?n:0),v=Math.max(0,null!==(r=t.minimumActivity)&&void 0!==r?r:0),E=Math.max(1,Math.round(null!==(l=t.persistenceWindow)&&void 0!==l?l:1)),k=Math.max(1,Math.min(E,Math.round(null!==(o=t.persistenceBuckets)&&void 0!==o?o:1))),S=Math.max(0,Math.min(u,null!==(s=t.recoveryThreshold)&&void 0!==s?s:0)),L=Math.max(1,Math.round(null!==(c=t.recoveryBuckets)&&void 0!==c?c:1)),O=Math.max(0,Math.round(null!==(d=t.cooldownBuckets)&&void 0!==d?d:0));if(!("high_or_low"!==g||y>0||f>0||v>0||k>1||S>0||L>1||O>0||!0===t.dataQualityGate))return h.map(e=>x(b({},e),{score:$(e.score),pointScore:$(e.pointScore),windowScore:$(e.windowScore),decisionState:e.isAnomaly?"open":null===e.expected?"warming_up":"normal"}));const q=(e,a)=>{var i;const n=null===e.expected?0:e.value-e.expected,r="high_or_low"===g||"high_mean"===g&&n>0||"low_mean"===g&&n<0,l=Math.abs(n),o=null===e.expected?0:l/Math.max(Math.abs(e.expected),1e-9),s=!0!==t.dataQualityGate||"healthy"===e.dataQualityLabel;return e.score>=a&&r&&l>=y&&o>=f&&Math.max(Math.abs(e.value),Math.abs(null!==(i=e.expected)&&void 0!==i?i:0))>=v&&s},W=h.map(e=>q(e,u)),z=S>0?S:u,j=h.map(e=>q(e,z)),U=[];let H=!1,Q=0,G=0;return h.map((e,t)=>{const a=x(b({},e),{score:$(e.score),pointScore:$(e.pointScore),windowScore:$(e.windowScore)}),i=W[t],n=j[t];if(U.push(i),U.length>E&&U.shift(),H){if(n)return Q=0,x(b({},a),{isAnomaly:!0,decisionState:"open"});if(Q+=1,Q<L)return x(b({},a),{isAnomaly:!0,decisionState:"recovering"});H=!1,Q=0,G=O}return G>0?(G-=1,x(b({},a),{isAnomaly:!1,severityScore:0,severityLabel:"normal",decisionState:"cooldown"})):i&&U.filter(Boolean).length>=k?(H=!0,x(b({},a),{isAnomaly:!0,decisionState:"open"})):x(b({},a),{isAnomaly:!1,severityScore:0,severityLabel:"normal",decisionState:i?"candidate":null===e.expected?"warming_up":"normal"})})};function q(e,t,a,i,n,r,l){try{var o=e[r](l),s=o.value}catch(e){return void a(e)}o.done?t(s):Promise.resolve(s).then(i,n)}function W(e){return function(){var t=this,a=arguments;return new Promise(function(i,n){var r=e.apply(t,a);function l(e){q(r,i,n,l,o,"next",e)}function o(e){q(r,i,n,l,o,"throw",e)}l(void 0)})}}function z(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}function j(e){for(var t=1;t<arguments.length;t++){var a=null!=arguments[t]?arguments[t]:{},i=Object.keys(a);"function"==typeof Object.getOwnPropertySymbols&&(i=i.concat(Object.getOwnPropertySymbols(a).filter(function(e){return Object.getOwnPropertyDescriptor(a,e).enumerable}))),i.forEach(function(t){z(e,t,a[t])})}return e}function U(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);t&&(i=i.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),a.push.apply(a,i)}return a}(Object(t)).forEach(function(a){Object.defineProperty(e,a,Object.getOwnPropertyDescriptor(t,a))}),e}const H=["#7EB26D","#EAB839","#6ED0E0","#EF843C","#E24D42","#1F78C1"],Q=720,G={top:18,right:20,bottom:42,left:64},Y={"1m":6e4,"5m":3e5,"15m":9e5,"1h":36e5},K=Object.values(Y).sort((e,t)=>e-t),J={recommended:"Recommended",advanced:"Advanced"},Z={zscore:"Rolling z-score",mad:"Rolling MAD",ewma:"EWMA baseline",seasonal:"Seasonal baseline",level_shift:"Level shift detector"},X={auto:"Auto",custom:"Custom",traffic:"Traffic / throughput",latency:"Latency / duration",error_rate:"Error rate",resource:"Resource usage",business:"Business KPI",level_shift:"Subtle level shift"},ee={auto:"Auto",raw:"Raw samples","1m":"1 minute","5m":"5 minutes","15m":"15 minutes","1h":"1 hour"},te={traffic:{algorithm:"ewma",anomalyDirection:"high_or_low",sensitivity:4.5,baselineWindow:30,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"warning_first",badge:"Stable default",why:"Traffic and throughput metrics drift with load, so EWMA is usually the safest default for live dashboards."},latency:{algorithm:"mad",anomalyDirection:"high_mean",sensitivity:4,baselineWindow:12,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"page_first",badge:"Noisy data",why:"Latency metrics are often spiky and outlier-heavy, so MAD is more robust than a mean-based baseline."},error_rate:{algorithm:"mad",anomalyDirection:"high_mean",sensitivity:4.5,baselineWindow:12,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"page_first",badge:"Burst errors",why:"Error metrics often stay low and then jump sharply, so MAD isolates bursts without letting them poison the baseline."},resource:{algorithm:"ewma",anomalyDirection:"high_mean",sensitivity:4.5,baselineWindow:24,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Drifting baseline",why:"CPU, memory, and load metrics usually move gradually, so EWMA follows the baseline smoothly without overreacting."},business:{algorithm:"seasonal",anomalyDirection:"high_or_low",sensitivity:4,baselineWindow:8,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Seasonal data",why:"Business KPIs often repeat by hour or weekday, so seasonal matching reduces false positives on recurring patterns."},level_shift:{algorithm:"level_shift",anomalyDirection:"high_or_low",sensitivity:5,baselineWindow:30,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Sustained change",why:"When the baseline shifts gradually or steps into a new level, a level-shift detector is better than a pure spike detector."}},ae=["latency","error_rate","level_shift","resource","business","traffic"],ie=[/(^|[^a-z0-9])(up|healthy|health|availability|uptime)([^a-z0-9]|$)/i,/success[_\s-]?(rate|ratio|percent|percentage)/i,/(free|available|remaining)[_\s-]?(capacity|space|slots?|connections?|bytes?)/i,/(capacity|space|slots?|connections?|bytes?)[_\s-]?(free|available|remaining)/i,/headroom/i],ne=e=>e.map(e=>e.trim()).filter(Boolean).some(e=>ie.some(t=>t.test(e)))?"low_mean":null,re=[{preset:"latency",patterns:[/latency/i,/duration/i,/response/i,/p95/i,/p99/i,/p90/i,/quantile/i,/delay/i,/ms/i,/seconds?/i]},{preset:"error_rate",patterns:[/error/i,/errors/i,/failure/i,/fail/i,/exception/i,/timeout/i,/reject/i,/5xx/i,/4xx/i]},{preset:"resource",patterns:[/cpu/i,/memory/i,/load/i,/utili/i,/usage/i,/heap/i,/rss/i,/disk/i,/iops/i,/saturation/i,/throttle/i]},{preset:"level_shift",patterns:[/queue/i,/backlog/i,/pending/i,/session/i,/connection/i,/thread/i,/pool/i,/worker/i,/lag/i,/offset/i,/buffer/i,/inflight/i,/active/i]},{preset:"business",patterns:[/revenue/i,/order/i,/orders/i,/signup/i,/conversion/i,/checkout/i,/cart/i,/booking/i,/payment/i,/sales/i,/gmv/i]},{preset:"traffic",patterns:[/request/i,/requests/i,/throughput/i,/traffic/i,/volume/i,/events?/i,/rps/i,/qps/i,/ops/i,/hits?/i,/ingress/i,/egress/i,/count/i]}],le={cycle:"Cycle only",hour_of_day:"Hour of day",weekday_hour:"Weekday + hour"},oe={balanced:"Balanced",warning_first:"Warning first",page_first:"Page first"},se={normal:"Normal",low:"Low",medium:"Medium",high:"High",critical:"Critical"},ce={normal:"#94A3B8",low:"#EAB308",medium:"#F59E0B",high:"#F97316",critical:"#DC2626"},de={low:"Low confidence",medium:"Medium confidence",high:"High confidence"},me={low:"#F59E0B",medium:"#2563EB",high:"#16A34A"},ue={healthy:"Healthy data",thin:"Thin history",flatline:"Flatline risk",gappy:"Gappy sampling"},pe=e=>{if("number"==typeof e&&Number.isFinite(e))return e;if("string"==typeof e){const t=Number(e);return Number.isFinite(t)?t:null}return null},he=(e,t)=>{if(e)return"function"==typeof e.get?e.get(t):e[t]},ge=e=>{const t=[...e].sort((e,t)=>e-t),a=Math.floor(t.length/2);return t.length%2==0?(t[a-1]+t[a])/2:t[a]},ye=e=>{if(null===e||!Number.isFinite(e))return"n/a";const t=Math.abs(e);return t>=1e3?e.toLocaleString(void 0,{maximumFractionDigits:1}):t>=10?e.toLocaleString(void 0,{maximumFractionDigits:2}):e.toLocaleString(void 0,{maximumFractionDigits:3})},fe=e=>null!==e&&Number.isFinite(e)?Math.round(e).toLocaleString(void 0,{maximumFractionDigits:0}):"n/a",ve=e=>null!==e&&Number.isFinite(e)?`${e.toLocaleString(void 0,{maximumFractionDigits:1})}%`:"n/a",be=e=>new Date(e).toLocaleString(void 0,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}),xe=(e,t)=>t<=e?be(e):`${be(e)} - ${be(t)}`,we=(e,t=26)=>e.length<=t?e:`${e.slice(0,Math.max(1,t-1)).trimEnd()}…`,Ee=(e,t)=>"auto"!==e?e:t<=216e5?"dense":t<=1296e5?"balanced":"compact",ke=(e,t)=>{const a=Ee(t,e);return e<=432e5||"dense"===a?"HH:mm":e<=2592e5?"DD/MM HH:mm":"DD/MM"},Se=(e,t,a,i)=>(0,c.dateTimeFormat)(e,{format:ke(t,a),timeZone:i}),Fe=(e,t,a)=>(0,c.dateTimeFormat)(e,{format:t<=2592e5?"DD/MM HH:mm":"DD/MM/YYYY HH:mm",timeZone:a}),$e=(e,t)=>{if("classic"===t)return"circle";switch(e){case"medium":return"diamond";case"high":return"triangle";case"critical":return"square";default:return"circle"}},Me=(e,t,a,i)=>"diamond"===e?`M ${t} ${a-i} L ${t+i} ${a} L ${t} ${a+i} L ${t-i} ${a} Z`:`M ${t} ${a-i} L ${t+.92*i} ${a+.9*i} L ${t-.92*i} ${a+.9*i} Z`,Ne=(e,t,a,i,n,r,l=0,o)=>"circle"===e?h().createElement("circle",{cx:t,cy:a,r:i,fill:n,stroke:r,strokeWidth:l,opacity:o}):"square"===e?h().createElement("rect",{x:t-i,y:a-i,width:2*i,height:2*i,rx:Math.max(1.5,.32*i),fill:n,stroke:r,strokeWidth:l,opacity:o}):h().createElement("path",{d:Me(e,t,a,i),fill:n,stroke:r,strokeWidth:l,opacity:o}),Le=(e,t)=>{var a,i;if("advanced"===e.setupMode||"custom"===e.effectiveMetricPreset)return{source:"manual",badge:"Manual tuning",title:"Advanced controls are active",reason:`Algorithm ${Z[e.algorithm]} with ${oe[e.severityPreset]} severity mapping is applied directly.`,matchedNames:[],confidence:"matched"};const n=te[e.effectiveMetricPreset],r="auto"===e.metricPreset?"auto":"selected",l="auto"===r?`Auto selected ${X[e.effectiveMetricPreset]}`:`${X[e.effectiveMetricPreset]} preset is active`;return{source:r,badge:n.badge,title:l,reason:n.why,matchedNames:null!==(a=null==t?void 0:t.matchedNames)&&void 0!==a?a:[],confidence:null!==(i=null==t?void 0:t.confidence)&&void 0!==i?i:"matched"}},Ae=(e,t)=>{var a,i,n,r,l,o,s;const c=null!==(a=e.setupMode)&&void 0!==a?a:"recommended",d=null!==(i=e.metricPreset)&&void 0!==i?i:"auto",m=Math.max(3,Math.min(20,Math.round(null!==(n=e.maxAnomalies)&&void 0!==n?n:8))),u=e.bucketSpan||"auto";if("advanced"===c||"custom"===d){var p,h,g,y,f,v,b,x,w,E,k,S,F,$,M,N,L,A,C,B,D;const t={setupMode:c,metricPreset:d,effectiveMetricPreset:"custom",detectionMode:null!==(p=e.detectionMode)&&void 0!==p?p:"single",algorithm:null!==(h=e.algorithm)&&void 0!==h?h:"zscore",anomalyDirection:null!==(g=e.anomalyDirection)&&void 0!==g?g:"high_or_low",minimumAbsoluteDeviation:Math.max(0,null!==(y=e.minimumAbsoluteDeviation)&&void 0!==y?y:0),minimumRelativeDeviation:Math.max(0,null!==(f=e.minimumRelativeDeviation)&&void 0!==f?f:0),minimumActivity:Math.max(0,null!==(v=e.minimumActivity)&&void 0!==v?v:0),persistenceBuckets:Math.min(Math.max(1,Math.round(null!==(b=e.persistenceBuckets)&&void 0!==b?b:3)),Math.max(1,Math.round(null!==(x=e.persistenceWindow)&&void 0!==x?x:4))),persistenceWindow:Math.max(1,Math.round(null!==(w=e.persistenceWindow)&&void 0!==w?w:4)),recoveryThreshold:Math.min(Math.max(0,null!==(E=e.recoveryThreshold)&&void 0!==E?E:3),Math.max(.2,null!==(k=e.sensitivity)&&void 0!==k?k:4)),recoveryBuckets:Math.max(1,Math.round(null!==(S=e.recoveryBuckets)&&void 0!==S?S:2)),cooldownBuckets:Math.max(0,Math.round(null!==(F=e.cooldownBuckets)&&void 0!==F?F:2)),dataQualityGate:!1!==e.dataQualityGate,sensitivity:Math.max(.2,null!==($=e.sensitivity)&&void 0!==$?$:4),baselineWindow:Math.max(3,Math.round(null!==(M=e.baselineWindow)&&void 0!==M?M:12)),seasonalitySamples:Math.max(2,Math.round(null!==(N=e.seasonalitySamples)&&void 0!==N?N:24)),seasonalRefinement:null!==(L=e.seasonalRefinement)&&void 0!==L?L:"cycle",severityPreset:null!==(A=e.severityPreset)&&void 0!==A?A:"balanced",bucketSpan:u,showExpectedLine:!1!==e.showExpectedLine,showInlineSeriesLabels:!1!==e.showInlineSeriesLabels,showFocusBand:!0===e.showFocusBand,timeAxisDensity:null!==(C=e.timeAxisDensity)&&void 0!==C?C:"auto",timeAxisPlacement:null!==(B=e.timeAxisPlacement)&&void 0!==B?B:"top_and_bottom",markerShapeMode:null!==(D=e.markerShapeMode)&&void 0!==D?D:"severity",maxAnomalies:m};return U(j({},t),{recommendation:Le(t,null)})}const T="auto"===d?(e=>{const t=new Map;for(const i of e)for(const e of re)if(e.patterns.some(e=>e.test(i))){var a;const n=null!==(a=t.get(e.preset))&&void 0!==a?a:[];n.push(i),t.set(e.preset,n)}for(const e of ae){var i;const a=null!==(i=t.get(e))&&void 0!==i?i:[];if(a.length>0)return{preset:e,matchedNames:a,confidence:a.length>=2?"matched":"weak"}}return{preset:"traffic",matchedNames:[],confidence:"fallback"}})(t):null,P="auto"===d?null==T?void 0:T.preset:d,_=te[P],R="auto"===d?ne(t):null,I={setupMode:c,metricPreset:d,effectiveMetricPreset:P,detectionMode:null!==(r=e.detectionMode)&&void 0!==r?r:"single",algorithm:_.algorithm,anomalyDirection:null!=R?R:_.anomalyDirection,minimumAbsoluteDeviation:0,minimumRelativeDeviation:0,minimumActivity:0,persistenceBuckets:3,persistenceWindow:4,recoveryThreshold:Math.max(.2,.75*_.sensitivity),recoveryBuckets:2,cooldownBuckets:2,dataQualityGate:!0,sensitivity:_.sensitivity,baselineWindow:_.baselineWindow,seasonalitySamples:_.seasonalitySamples,seasonalRefinement:_.seasonalRefinement,severityPreset:_.severityPreset,bucketSpan:u,showExpectedLine:!1!==e.showExpectedLine,showInlineSeriesLabels:!1!==e.showInlineSeriesLabels,showFocusBand:!0===e.showFocusBand,timeAxisDensity:null!==(l=e.timeAxisDensity)&&void 0!==l?l:"auto",timeAxisPlacement:null!==(o=e.timeAxisPlacement)&&void 0!==o?o:"top_and_bottom",markerShapeMode:null!==(s=e.markerShapeMode)&&void 0!==s?s:"severity",maxAnomalies:m};return U(j({},I),{recommendation:Le(I,T)})},Ce=e=>e?"point"===e.kind?`point:${e.seriesKey}:${e.time}`:`event:${e.time}`:"none",Be=e=>["normal","low","medium","high","critical"].indexOf(e),De=(e,t)=>Be(t.severityLabel)>Be(e.severityLabel)||Be(t.severityLabel)===Be(e.severityLabel)&&t.severityScore>e.severityScore?t:e,Te=(e,t)=>"level_shift"===t?"window"===e?"Sustained baseline shift":"Fresh step change":"seasonal"===t?"Seasonal pattern break":"window"===e?"ewma"===t?"Short sustained drift":"Sustained deviation":"Sharp point deviation",Pe=(e,t)=>{const a="warning_first"===t?"Warning-first preset surfaces operator-visible severity earlier.":"page_first"===t?"Page-first preset keeps high and critical stricter for paging workflows.":"Balanced preset aims to work for both dashboards and alert handoff.",i="low"===e.confidenceLabel?" Confidence is still low, so verify with nearby metrics before paging.":"thin"===e.dataQualityLabel?" History is still thin, so treat this as early signal rather than hard evidence.":"flatline"===e.dataQualityLabel?" The series looks nearly flat, so verify the metric is still reporting healthy samples.":"gappy"===e.dataQualityLabel?" Recent samples are gappy, so confirm the data source timing before escalating.":"";return"critical"===e.severityLabel||"high"===e.severityLabel?`${a} This anomaly is already in the investigate-now range.${i}`:"medium"===e.severityLabel?`${a} This anomaly looks strong enough for triage or warning workflows.${i}`:`${a} This anomaly is currently better suited to watchlists or dashboard review.${i}`},_e=e=>{const t=[];for(const a of e){const e=t[t.length-1];if(e&&e.time===a.time){const t=e.sampleCount+a.sampleCount;e.value=(e.value*e.sampleCount+a.value*a.sampleCount)/t,e.sampleCount=t,e.minValue=Math.min(e.minValue,a.minValue),e.maxValue=Math.max(e.maxValue,a.maxValue),e.bucketStart=Math.min(e.bucketStart,a.bucketStart),e.bucketEnd=Math.max(e.bucketEnd,a.bucketEnd);continue}t.push(j({},a))}return t},Re=(e,t)=>{if("raw"===t)return null;if("auto"!==t)return Y[t];const a=e.map(e=>e.rawPoints.length).filter(e=>e>0);if(0===a.length)return null;const i=Math.max(...a),n=e.flatMap(e=>e.rawPoints.map(e=>e.time)),r=Math.min(...n),l=Math.max(...n),o=Math.max(l-r,0),s=e.map(e=>(e=>{if(e.length<2)return null;const t=[];for(let a=1;a<e.length&&t.length<120;a+=1){const i=e[a].time-e[a-1].time;i>0&&t.push(i)}return t.length>0?ge(t):null})(e.rawPoints)).filter(e=>null!==e),c=s.length>0?ge(s):null;if(i<=640||o<=0)return null;const d=Math.ceil(o/640),m=c?Math.max(1.5*c,d):d,u=K.find(e=>e>=m);return null!=u?u:K[K.length-1]},Ie=(e,t)=>({time:e,value:t,bucketStart:e,bucketEnd:e,sampleCount:1,minValue:t,maxValue:t}),Ve=e=>"string"!=typeof e?null:e.trim().length>0?e:null,Oe=(e,t,a="Series")=>{var i,n,r,l,o,s,c,d;return null!==(i=null!==(n=null!==(r=null!==(l=null!==(o=Ve(null===(s=e.config)||void 0===s?void 0:s.displayNameFromDS))&&void 0!==o?o:Ve(null===(c=e.config)||void 0===c?void 0:c.displayName))&&void 0!==l?l:Ve(null===(d=e.state)||void 0===d?void 0:d.displayName))&&void 0!==r?r:Ve(e.name))&&void 0!==n?n:Ve(t))&&void 0!==i?i:a},qe=e=>{var t,a,i,n,r;return Boolean(null!==(t=null!==(a=Ve(null===(i=e.config)||void 0===i?void 0:i.displayNameFromDS))&&void 0!==a?a:Ve(null===(n=e.config)||void 0===n?void 0:n.displayName))&&void 0!==t?t:Ve(null===(r=e.state)||void 0===r?void 0:r.displayName))},We=e=>{const t=!1!==e.showSummary;return{initialLabels:!1!==e.showInitialLabels,statistics:!1!==e.showStatistics,mainChart:!1!==e.showMainChart,inspector:!1!==e.showInspector,anomalyFeed:t&&!1!==e.showAnomalyFeed,seriesSummary:!1!==e.showSeriesSummary,scoreFeed:!1!==e.showScoreFeed,detectionProfile:t&&!1!==e.showDetectionProfile,exports:t&&!1!==e.showExports}},ze=e=>{const t=[];e.forEach((e,a)=>{const i=e.fields.find(e=>e.type===c.FieldType.time);if(!i)return;e.fields.filter(e=>e.type===c.FieldType.number).forEach((n,r)=>{var l,o,s,c,d;const m=[],u=Math.min(null!==(l=i.values.length)&&void 0!==l?l:0,null!==(o=n.values.length)&&void 0!==o?o:0);for(let e=0;e<u;e+=1){const t=pe(he(i.values,e)),a=pe(he(n.values,e));null!==t&&null!==a&&m.push(Ie(t,a))}if(0===m.length)return;m.sort((e,t)=>e.time-t.time);const p=Oe(n,e.name,`Series ${t.length+1}`),h=null===(d=n.config.color)||void 0===d?void 0:d.fixedColor;t.push({key:`${null!==(s=e.name)&&void 0!==s?s:a}-${null!==(c=n.name)&&void 0!==c?c:r}-${a}-${r}`,label:p,preservesGrafanaDisplayName:qe(n),color:h||H[t.length%H.length],rawPoints:_e(m)})})});const a=new Map;t.forEach(e=>{var t;a.set(e.label,(null!==(t=a.get(e.label))&&void 0!==t?t:0)+1)});const i=new Map;return t.map(e=>{var t,n;if((null!==(t=a.get(e.label))&&void 0!==t?t:1)<=1||e.preservesGrafanaDisplayName)return e;const r=(null!==(n=i.get(e.label))&&void 0!==n?n:0)+1;return i.set(e.label,r),U(j({},e),{label:`${e.label} (${r})`})})},je=(e,t)=>{const a=Re(e,t.bucketSpan),i=e.map(e=>{const i=((e,t)=>{if(!t||0===e.length)return _e(e.map(e=>j({},e)));const a=new Map;for(const n of e){var i;const e=Math.floor(n.time/t)*t,r=null!==(i=a.get(e))&&void 0!==i?i:{sum:0,count:0,min:Number.POSITIVE_INFINITY,max:Number.NEGATIVE_INFINITY,end:e+t};r.sum+=n.value,r.count+=n.sampleCount,r.min=Math.min(r.min,n.minValue),r.max=Math.max(r.max,n.maxValue),a.set(e,r)}return[...a.entries()].sort((e,t)=>e[0]-t[0]).map(([e,a])=>({time:e+Math.round(t/2),value:a.sum/a.count,bucketStart:e,bucketEnd:a.end,sampleCount:a.count,minValue:a.min,maxValue:a.max}))})(e.rawPoints,a),n=((e,t)=>O(e,{algorithm:t.algorithm,anomalyDirection:t.anomalyDirection,minimumAbsoluteDeviation:t.minimumAbsoluteDeviation,minimumRelativeDeviation:t.minimumRelativeDeviation,minimumActivity:t.minimumActivity,persistenceBuckets:Math.min(t.persistenceBuckets,t.persistenceWindow),persistenceWindow:t.persistenceWindow,recoveryThreshold:t.recoveryThreshold,recoveryBuckets:t.recoveryBuckets,cooldownBuckets:t.cooldownBuckets,dataQualityGate:t.dataQualityGate,sensitivity:t.sensitivity,baselineWindow:t.baselineWindow,seasonalitySamples:t.seasonalitySamples,seasonalRefinement:t.seasonalRefinement,severityPreset:t.severityPreset}))(i,t),r=(e=>{if(e.length<=Q)return e;const t=new Set,a=(e.length-1)/719;for(let e=0;e<Q;e+=1)t.add(Math.round(e*a));return e.forEach((e,a)=>{e.isAnomaly&&t.add(a)}),[...t].sort((e,t)=>e-t).slice(0,Q+Math.min(60,e.filter(e=>e.isAnomaly).length)).map(t=>e[t])})(n),l=n.filter(e=>e.isAnomaly),o=l.reduce((e,t)=>De(e,t),{severityLabel:"normal",severityScore:0});return{key:e.key,label:e.label,color:e.color,points:r,allPoints:n,anomalyCount:l.length,maxScore:l.reduce((e,t)=>Math.max(e,t.score),0),maxSeverityScore:o.severityScore,maxSeverityLabel:o.severityLabel,sourcePointCount:e.rawPoints.length,aggregatedPointCount:i.length,processedPointCount:n.length}});return{analyses:i,effectiveBucketSpanMs:a}},Ue=(e,t)=>"raw"===e?ee.raw:"auto"!==e?ee[e]:t?`Auto -> ${(e=>{const t=Math.round(e/6e4);if(t<60)return`${t}m`;const a=Math.round(e/36e5*10)/10;return a<24?`${a}h`:Math.round(e/864e5*10)/10+"d"})(t)}`:"Auto -> raw",He=(e,t,a,i)=>{let n="";return e.forEach(e=>{const r=i(e);if(null===r||!Number.isFinite(r))return;const l=0===n.length?"M":"L";n+=`${l}${t(e.time).toFixed(2)},${a(r).toFixed(2)} `}),n.trim()},Qe=(e,t,a)=>Number.isFinite(e)&&Number.isFinite(t)?a<=1||t===e?[e]:Array.from({length:a},(i,n)=>e+(t-e)*n/(a-1)):[],Ge=(e,t,a,i=null)=>{if(e.length<=1)return e;const n=[];let r=[],l=Number.NEGATIVE_INFINITY;const o=()=>{if(0===r.length)return;let e=r[0];for(const t of r){if(null!==i&&t.time===i){e=t;break}t.score>e.score&&(e=t)}n.push(e),r=[]};for(const i of e){const e=t(i.time);0!==r.length?e-l<a?r.push(i):(o(),r=[i],l=e):(r=[i],l=e)}if(o(),null!==i&&!n.some(e=>e.time===i)){const t=e.find(e=>e.time===i);t&&(n.push(t),n.sort((e,t)=>e.time-t.time))}return n},Ye=(e,t)=>{if(0===e.length)return-1;let a=0,i=Math.abs(e[0]-t);for(let n=1;n<e.length;n+=1){const r=Math.abs(e[n]-t);r<i&&(i=r,a=n)}return a},Ke=(e,t,a=null)=>{var i;if(e.length<=t)return e;const n=null!==a&&null!==(i=e.find(e=>e.time===a))&&void 0!==i?i:null,r=[...e].sort((e,t)=>t.score-e.score||e.time-t.time),l=[];n&&l.push(n);for(const e of r){if(l.length>=t)break;l.some(t=>t.time===e.time)||l.push(e)}return l.sort((e,t)=>e.time-t.time)},Je=(e,t,a)=>"multi"===a.detectionMode?t.filter(e=>e.isAnomaly).sort((e,t)=>t.score-e.score).slice(0,a.maxAnomalies).map((e,t)=>({key:`event-${e.time}-${t}`,time:e.time,title:`Cross-metric incident at ${be(e.time)}`,subtitle:`${e.activeSeries} metric${1===e.activeSeries?"":"s"} aligned${e.contributors.length>0?` | ${e.contributors.join(", ")}`:""}`,detail:`${se[e.severityLabel]} ${e.severityScore} | ${de[e.confidenceLabel]} | ${ue[e.dataQualityLabel]}`,score:e.score,severityLabel:e.severityLabel,severityScore:e.severityScore,confidenceScore:e.confidenceScore,confidenceLabel:e.confidenceLabel,dataQualityLabel:e.dataQualityLabel,selection:{kind:"event",time:e.time}})):e.flatMap(e=>(e=>{const t=e.filter(e=>e.isAnomaly).sort((e,t)=>e.time-t.time);if(0===t.length)return[];const a=[];let i=[t[0]];for(let e=1;e<t.length;e+=1){const n=i[i.length-1],r=t[e],l=Math.max(n.bucketEnd-n.bucketStart,1),o=Math.max(r.bucketEnd-r.bucketStart,1),s=1.25*Math.max(l,o);r.bucketStart<=n.bucketEnd+s?i.push(r):(a.push(i),i=[r])}return a.push(i),a})(e.allPoints).map((t,i)=>{const n=t.reduce((e,t)=>t.score>e.score?t:e),r=t[0].bucketStart,l=t[t.length-1].bucketEnd;return{key:`${e.key}-${n.time}-${i}`,time:n.time,title:(o=e.label,s=a.algorithm,c=n.scoreDriver,`${Te(c,s)} in ${o}`),subtitle:t.length>1?`${t.length} consecutive buckets | ${xe(r,l)}`:xe(r,l),detail:`${se[n.severityLabel]} ${n.severityScore} | ${de[n.confidenceLabel]} | Current ${ye(n.value)} vs expected ${ye(n.expected)}`,score:n.score,severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel,selection:{kind:"point",seriesKey:e.key,time:n.time}};var o,s,c})).sort((e,t)=>t.score-e.score).slice(0,a.maxAnomalies),Ze=(e,t,a)=>{if(!e)return null;if("point"===e.kind){const a=((e,t)=>{var a;const i=null!==(a=t.find(t=>t.key===e.seriesKey))&&void 0!==a?a:null,n=i?[i,...t.filter(e=>e.key!==i.key)]:t;for(const t of n){const a=t.allPoints.find(t=>t.time===e.time);if(a)return{analysis:t,point:a}}let r=null,l=null;for(const t of n)for(const a of t.allPoints){const i=Math.max(a.bucketEnd-a.bucketStart,1),n=Math.abs(a.time-e.time);a.isAnomaly&&(!l||n<l.distance)&&(l={analysis:t,point:a,distance:n}),n<=1.5*i&&(!r||n<r.distance)&&(r={analysis:t,point:a,distance:n})}const o=null!=r?r:l;return o?{analysis:o.analysis,point:o.point}:null})(e,t);if(!a)return null;const{analysis:i,point:n}=a,r=null===n.expected?null:n.value-n.expected,l=n.expected&&Math.abs(n.expected)>1e-9?r/n.expected*100:null;return{kind:"point",title:`${"window"===n.scoreDriver?"Sustained change":"Sharp change"} in ${i.label}`,subtitle:xe(n.bucketStart,n.bucketEnd),seriesKey:i.key,seriesLabel:i.label,color:i.color,time:n.time,bucketStart:n.bucketStart,bucketEnd:n.bucketEnd,actual:n.value,expected:n.expected,deviation:r,deviationPercent:l,rangeLower:n.lower,rangeUpper:n.upper,sampleCount:n.sampleCount,minValue:n.minValue,maxValue:n.maxValue,score:n.score,pointScore:n.pointScore,windowScore:n.windowScore,scoreDriver:n.scoreDriver,severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel}}const i=a.find(t=>t.time===e.time);if(!i)return null;const n=t.map(e=>{const t=e.allPoints.find(e=>e.time===i.time);return t?{label:e.label,color:e.color,actual:t.value,expected:t.expected,deviation:null===t.expected?null:t.value-t.expected,rangeLower:t.lower,rangeUpper:t.upper,score:t.score,pointScore:t.pointScore,windowScore:t.windowScore,scoreDriver:t.scoreDriver,severityLabel:t.severityLabel,severityScore:t.severityScore,confidenceScore:t.confidenceScore,confidenceLabel:t.confidenceLabel,dataQualityLabel:t.dataQualityLabel}:null}).filter(e=>null!==e).sort((e,t)=>t.score-e.score);return{kind:"event",title:`Cross-metric incident at ${be(i.time)}`,subtitle:xe(i.bucketStart,i.bucketEnd),time:i.time,bucketStart:i.bucketStart,bucketEnd:i.bucketEnd,score:i.score,activeSeries:i.activeSeries,contributors:i.contributors,breakdown:n,severityLabel:i.severityLabel,severityScore:i.severityScore,confidenceScore:i.confidenceScore,confidenceLabel:i.confidenceLabel,dataQualityLabel:i.dataQualityLabel}},Xe=e=>{const t=new Set;return e.map(e=>(null!=e?e:"").trim()).filter(e=>!(!e||t.has(e))&&(t.add(e),!0))},et=e=>{switch(e){case"warning_first":return 60;case"page_first":return 75;default:return 70}},tt=e=>Object.entries(e).filter(([,e])=>e.length>0).map(([e,t])=>`${e}=${t}`).join("\n"),at=(e,t,a)=>{const i=e.document.querySelector(t);if(!i)return!1;const n=i.tagName.toLowerCase();if("input"!==n&&"textarea"!==n)return!1;return i.value=a,i.dispatchEvent(new Event("input",{bubbles:!0})),i.dispatchEvent(new Event("change",{bubbles:!0})),!0},it=e=>{if("undefined"==typeof window)return!1;const t=new URL("/alerting/new",window.location.origin),a=new URLSearchParams(window.location.search).get("orgId");a&&t.searchParams.set("orgId",a),e.dashboardUid&&t.searchParams.set("dashboardUid",e.dashboardUid),e.panelId>0&&t.searchParams.set("panelId",String(e.panelId)),t.searchParams.set("title",e.ruleName),t.searchParams.set("ruleName",e.ruleName),e.folderTitle&&t.searchParams.set("folderTitle",e.folderTitle),t.searchParams.set("dashboardTitle",e.dashboardTitle),t.searchParams.set("panelTitle",e.panelTitle),t.searchParams.set("queryLanguage",e.queryLanguage),t.searchParams.set("threshold",String(e.threshold)),t.searchParams.set("for","10m"),t.searchParams.set("evaluateEvery","3m"),t.searchParams.set("labels",tt(e.labels)),Object.entries(e.labels).forEach(([e,a])=>{a&&t.searchParams.set(`label_${e}`,a)}),e.alertQuery&&e.alertQuery.length<=1400&&t.searchParams.set("query",e.alertQuery),t.searchParams.set("returnTo",`${window.location.pathname}${window.location.search}`);try{window.sessionStorage.setItem("grafana-anomaly-alert-draft",JSON.stringify(e))}catch(e){}const i=window.open(t.toString(),"_blank");return!!i&&(((e,t)=>{let a=0;const i=()=>{a+=1;try{var n,r;const i=e.document;if(!i||e.closed)return;if(at(e,'[data-testid="data-testid alert-rule name-field"], input[name="name"], input[placeholder="Give your alert rule a name"]',t.ruleName),at(e,'input[type="number"]',String(t.threshold)),at(e,'[data-testid="annotation-value-0"], textarea[name="annotations.0.value"]',null!==(n=t.annotations.summary)&&void 0!==n?n:t.ruleName),at(e,'[data-testid="annotation-value-1"], textarea[name="annotations.1.value"]',null!==(r=t.annotations.description)&&void 0!==r?r:""),"promql"===t.queryLanguage.toLowerCase()){const n=i.querySelector('input[id^="option-code-radiogroup"]');n&&a<=2&&"function"==typeof n.click&&n.click();const r=['textarea[placeholder*="PromQL"]','textarea[aria-label*="Query"]','textarea[aria-label*="Editor content"]','input[placeholder*="PromQL"]','input[aria-label*="Query"]','textarea[name*="expr"]','input[name*="expr"]'].join(",");at(e,r,t.alertQuery)}}catch(e){}a<18&&!e.closed&&e.setTimeout(i,450)};e.setTimeout(i,450)})(i,e),!0)},nt=e=>{var t,a;const i=(null!==(t=e.queryLanguage)&&void 0!==t?t:"").toLowerCase(),n=(null!==(a=e.target)&&void 0!==a?a:"").toLowerCase();return"promql"===i||"prometheus"===n||!i&&e.query.includes("grafana_anomaly_rule_score")},rt=e=>{if(0===e.length)return"";if(1===e.length)return e[0].query;if(!e.every(nt))return e.map(e=>e.query).join("\n\n");return`max(max_over_time(grafana_anomaly_rule_score{rule=~"${e.map(e=>e.rule.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")}"}[5m]))`},lt=e=>{if(0===e.length)return"query";const t=Array.from(new Set(e.map(e=>e.queryLanguage).filter(e=>Boolean(e))));return 1===t.length?t[0]:e.every(nt)?"PromQL":"target-specific query"},ot=["prometheus","loki","influxdb","postgresql","clickhouse","elasticsearch"],st=e=>{const t=String(null!=e?e:"").toLowerCase();return ot.includes(t)?t:"prometheus"},ct=e=>{const t=st(e.target);return`${vt[t]}${e.queryLanguage?` (${e.queryLanguage})`:""}`},dt=(e,t)=>e?"point"===e.kind?`${e.title}. Raw detection score ${ye(e.score)}; alert score ${e.severityScore}/100 (${se[e.severityLabel]}). Current ${ye(e.actual)} vs expected ${ye(e.expected)}.`:`${e.title}. Raw detection score ${ye(e.score)} across ${e.activeSeries} active series; alert score ${e.severityScore}/100 (${se[e.severityLabel]}): ${e.contributors.slice(0,4).join(", ")}.`:`Anomaly score alert for ${t}.`,mt=e=>e.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"")||"metric",ut=(e,t,a,i)=>{if(!e)return null;const n=Xe(["anomaly-detector",e.severityLabel,e.confidenceLabel,e.dataQualityLabel,mt(i),e.kind]),r={time:e.bucketStart,tags:n,text:""};if(a&&(r.dashboardUID=a,r.dashboardUid=a),t>0&&(r.panelId=t),e.bucketEnd>e.bucketStart&&(r.timeEnd=e.bucketEnd,r.isRegion=!0),"point"===e.kind){const t=mt(e.seriesLabel);return n.includes(t)||n.push(t),r.text=[e.title,`Window: ${xe(e.bucketStart,e.bucketEnd)}`,`Raw detection score: ${ye(e.score)}`,`Alert score (0-100): ${se[e.severityLabel]} ${e.severityScore}`,`Confidence: ${de[e.confidenceLabel]} (${ye(e.confidenceScore)})`,`Data quality: ${ue[e.dataQualityLabel]}`,`Actual: ${ye(e.actual)} | Expected: ${ye(e.expected)}`,`Deviation: ${ye(e.deviation)}${null===e.deviationPercent?"":` (${ye(e.deviationPercent)}%)`}`,`Expected range: ${ye(e.rangeLower)} to ${ye(e.rangeUpper)}`].join("\n"),r}return r.text=[e.title,`Window: ${xe(e.bucketStart,e.bucketEnd)}`,`Raw detection score: ${ye(e.score)}`,`Alert score (0-100): ${se[e.severityLabel]} ${e.severityScore}`,`Confidence: ${de[e.confidenceLabel]} (${ye(e.confidenceScore)})`,`Data quality: ${ue[e.dataQualityLabel]}`,`Active series: ${e.activeSeries}`,`Top contributors: ${e.contributors.join(", ")||"No contributors found"}`].join("\n"),r},pt=e=>W(function*(){var t;if("undefined"!=typeof navigator&&(null===(t=navigator.clipboard)||void 0===t?void 0:t.writeText))try{return void(yield Promise.race([navigator.clipboard.writeText(e),new Promise((e,t)=>{("undefined"!=typeof window?window.setTimeout:setTimeout)(()=>t(new Error("Clipboard API timed out.")),900)})]))}catch(e){}if("undefined"==typeof document)throw new Error("Clipboard access is not available in this environment.");const a=document.createElement("textarea");a.value=e,a.setAttribute("readonly","true"),a.style.position="fixed",a.style.opacity="0",document.body.appendChild(a),a.select();const i=document.execCommand("copy");if(document.body.removeChild(a),!i)throw new Error("The browser blocked clipboard access.")})(),ht=(e,t)=>{if(e&&"object"==typeof e){const t=e,a=t.data,i=a&&"object"==typeof a?a:null,n="string"==typeof(null==i?void 0:i.message)&&i.message||"string"==typeof t.statusText&&t.statusText||"string"==typeof t.message&&t.message||"",r="number"!=typeof t.status||String(n).includes(String(t.status))?"":` (HTTP ${t.status})`;if(n)return`${n}${r}`}return e instanceof Error&&e.message?e.message:t},gt=e=>W(function*(){try{yield(0,f.getBackendSrv)().post("/api/annotations",e)}catch(e){throw new Error(ht(e,"Failed to create the Grafana annotation."))}})(),yt="http://127.0.0.1:9110",ft={off:"Off",manual:"Manual sync",auto:"Auto sync"},vt={prometheus:"Prometheus metrics",loki:"Loki",influxdb:"InfluxDB",postgresql:"PostgreSQL",clickhouse:"ClickHouse",elasticsearch:"Elasticsearch"},bt={prometheus:"Prometheus",loki:"Loki",influxdb:"InfluxDB",postgresql:"PostgreSQL",clickhouse:"ClickHouse",elasticsearch:"Elastic"},xt={prometheus:"#94A3B8",loki:"#F59E0B",influxdb:"#3B82F6",postgresql:"#60A5FA",clickhouse:"#FACC15",elasticsearch:"#22D3EE"},wt=e=>bt[st(e)],Et=({target:e})=>{switch(st(e)){case"loki":return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("path",{d:"M7 20V7.6l3.3-.9V20H7Z",fill:"#D97706"}),h().createElement("path",{d:"M11.3 20V3.8l3.4-.9V20h-3.4Z",fill:"#F59E0B"}),h().createElement("path",{d:"M15.8 20V10.2l3.2-.86V20h-3.2Z",fill:"#FBBF24"}),h().createElement("path",{d:"M5.2 20.4h15.1",stroke:"#B45309",strokeWidth:"1.8",strokeLinecap:"round"}));case"influxdb":return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("path",{d:"M12 2.8 20 7.3v9.4l-8 4.5-8-4.5V7.3l8-4.5Z",fill:"none",stroke:"#3B82F6",strokeWidth:"1.8"}),h().createElement("path",{d:"m12 2.8 3.9 7.1L12 21.2 8.1 9.9 12 2.8Z",fill:"none",stroke:"#60A5FA",strokeWidth:"1.3"}),h().createElement("path",{d:"M4 7.3 12 12l8-4.7M4 16.7 12 12l8 4.7",fill:"none",stroke:"#2563EB",strokeWidth:"1.2"}));case"postgresql":return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("path",{d:"M6.2 10.6c0-4.4 2.4-7 6.1-7 3.9 0 6.5 2.7 6.5 7 0 2.9-1.2 5.1-3.3 6.3l.3 3.1-2.9-1.8c-.8.15-1.7.15-2.6-.03L7.2 20l.43-3.35c-.95-.7-1.43-2.55-1.43-6.05Z",fill:"#3B82F6",opacity:"0.9"}),h().createElement("path",{d:"M9 10.1c.45-.5 1.25-.5 1.7 0M14 10.1c.45-.5 1.25-.5 1.7 0",stroke:"#DBEAFE",strokeWidth:"1.2",strokeLinecap:"round"}),h().createElement("path",{d:"M12.8 11.3c-.4 1.2-.15 2.1.75 2.7.85.6.95 1.55.15 2.45",fill:"none",stroke:"#DBEAFE",strokeWidth:"1.3",strokeLinecap:"round"}));case"clickhouse":return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("path",{d:"M4 4h3v16H4V4Zm5 0h3v16H9V4Zm5 0h3v16h-3V4Z",fill:"#FACC15"}),h().createElement("path",{d:"M19 4h1.8v16H19V4Z",fill:"#EF4444"}));case"elasticsearch":return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("circle",{cx:"9",cy:"7",r:"4",fill:"#F59E0B"}),h().createElement("circle",{cx:"15.2",cy:"7.7",r:"3.3",fill:"#22C55E"}),h().createElement("circle",{cx:"16.1",cy:"14.8",r:"4",fill:"#06B6D4"}),h().createElement("circle",{cx:"8.2",cy:"15.5",r:"3.5",fill:"#EF4444"}),h().createElement("circle",{cx:"12",cy:"11.5",r:"3.3",fill:"#64748B",opacity:"0.72"}));default:return h().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("ellipse",{cx:"12",cy:"5.4",rx:"7.2",ry:"3.1",fill:"#64748B"}),h().createElement("path",{d:"M4.8 5.4v4.5c0 1.7 3.2 3.1 7.2 3.1s7.2-1.4 7.2-3.1V5.4",fill:"#475569"}),h().createElement("ellipse",{cx:"12",cy:"9.9",rx:"7.2",ry:"3.1",fill:"#94A3B8"}),h().createElement("path",{d:"M4.8 9.9v4.5c0 1.7 3.2 3.1 7.2 3.1s7.2-1.4 7.2-3.1V9.9",fill:"#475569"}),h().createElement("ellipse",{cx:"12",cy:"14.4",rx:"7.2",ry:"3.1",fill:"#CBD5E1"}))}},kt=e=>h().createElement(Et,{target:e}),St=e=>(null!=e?e:yt).trim().replace(/\/+$/,"")||yt;class Ft extends Error{constructor(e,t,a){super(e),z(this,"status",void 0),z(this,"requestId",void 0),this.status=t,this.requestId=a,this.name="ExporterApiError"}}const $t=(e,t,a,i)=>{var n,r;const l=null!==(n=a.headers.get("Content-Type"))&&void 0!==n?n:"unknown",o=null!==(r=a.headers.get("X-Request-ID"))&&void 0!==r?r:"unavailable",s=t.split(/[?#]/,1)[0];if(!i.trim())return`${e} ${s} returned HTTP ${a.status} with an empty body. Check the exporter base path and reverse-proxy route. Request ID: ${o}.`;if(l.includes("text/plain")&&i.includes("grafana_anomaly_"))return`${e} ${s} reached the Prometheus metrics endpoint instead of the exporter JSON API. Check the configured base path. Request ID: ${o}.`;if(l.includes("text/html"))return`${e} ${s} returned HTTP ${a.status} HTML from a proxy or upstream. Request ID: ${o}.`;const c=i.replace(/\s+/g," ").trim().slice(0,200);return`${e} ${s} returned HTTP ${a.status} (${l}): ${c}. Request ID: ${o}.`},Mt=(e,t={})=>W(function*(){var a,i,n;const r=String(null!==(a=t.method)&&void 0!==a?a:"GET").toUpperCase();let l;try{l=yield fetch(e,t)}catch(t){throw new Ft(`${r} ${e.split(/[?#]/,1)[0]} did not receive an HTTP response. Check network reachability, TLS/mixed-content rules, and CORS. ${t instanceof Error?t.message:""}`.trim(),0,"unavailable")}const o=yield l.text(),s=null!==(i=l.headers.get("X-Request-ID"))&&void 0!==i?i:"unavailable";if(!(null!==(n=l.headers.get("Content-Type"))&&void 0!==n?n:"").toLowerCase().includes("application/json")||!o.trim())throw new Ft($t(r,e,l,o),l.status,s);let c;try{c=JSON.parse(o)}catch(t){throw new Ft($t(r,e,l,o),l.status,s)}if(!l.ok){var d;const t="string"==typeof c.error?c.error:null===(d=c.error)||void 0===d?void 0:d.message;throw new Ft(t||$t(r,e,l,o),l.status,s)}return c})(),Nt=e=>{if("saved"===e.source)return"saved";const t=e.targets.map(e=>`${e.refId}|${e.datasourceUid}|${e.expr}`).sort().join("||");let a=2166136261;for(let e=0;e<t.length;e+=1)a^=t.charCodeAt(e),a=Math.imul(a,16777619);return`runtime-${(a>>>0).toString(16).padStart(8,"0")}`},Lt=(e,t)=>{if(e.length!==t.length)return!1;const a=e=>[e.refId,e.datasourceUid,e.datasourceType,e.expr].map(e=>e.trim()).join("|"),i=e.map(a).sort(),n=t.map(a).sort();return i.every((e,t)=>e===n[t])},At=e=>e.trim().toLowerCase().replace(/[^a-z0-9_]+/g,"_").replace(/^_+|_+$/g,"")||"anomaly_panel",Ct=(e,t)=>{const a=At(e||"anomaly_panel"),i=At(null!=t?t:"");return i?`${i}_${a}`:a},Bt=()=>{var e;if("undefined"==typeof window)return"";const t=window.location.pathname.match(/\/d\/([^/]+)/);return null!==(e=null==t?void 0:t[1])&&void 0!==e?e:""},Dt=()=>"undefined"==typeof document?"":document.title.replace(/\s+-\s+Grafana$/i,"").replace(/^View panel\s+-\s+/i,"").replace(/^Edit panel\s+-\s+/i,"").replace(/\s+-\s+Dashboards$/i,"").trim(),Tt=()=>{if("undefined"==typeof document)return"";const e=Array.from(document.querySelectorAll('nav[aria-label="Breadcrumbs"] a')).map(e=>{var t,a;return null!==(t=null===(a=e.textContent)||void 0===a?void 0:a.trim())&&void 0!==t?t:""}).filter(Boolean);return e.length>=3&&"dashboards"===e[0].toLowerCase()?e[1]:""},Pt=(e,t)=>{const a=e.trim(),i=t.trim().toLowerCase();return a&&("postgres"!==i&&"postgresql"!==i&&!i.includes("postgresql")||/^postgres(?:ql)?:\/\//i.test(a))?a:""},_t=e=>e.flatMap((e,t)=>{var a,i,n,r,l,o,s,c,d,m,u,p,h,g,y,f,v,b;if(!e||"object"!=typeof e)return[];const x=e;if(!0===x.hide)return[];const w=(e=>{var t,a,i,n;if("string"==typeof e)return{uid:e,type:"",url:""};if(!e||"object"!=typeof e)return{uid:"",type:"",url:""};const r=e;return{uid:String(null!==(t=null!==(a=r.uid)&&void 0!==a?a:r.name)&&void 0!==t?t:""),type:String(null!==(i=r.type)&&void 0!==i?i:""),url:String(null!==(n=r.url)&&void 0!==n?n:"")}})(x.datasource),E=String(null!==(a=null!==(i=x.datasourceUid)&&void 0!==i?i:w.uid)&&void 0!==a?a:"").trim(),k=String(null!==(n=null!==(r=x.datasourceType)&&void 0!==r?r:w.type)&&void 0!==n?n:"").trim().toLowerCase(),S=Pt(String(null!==(l=null!==(o=null!==(s=x.datasourceUrl)&&void 0!==s?s:x.url)&&void 0!==o?o:w.url)&&void 0!==l?l:"").trim(),k),F=String(null!==(c=null!==(d=null!==(m=null!==(u=null!==(p=x.expr)&&void 0!==p?p:x.expression)&&void 0!==u?u:x.query)&&void 0!==m?m:x.rawSql)&&void 0!==d?d:x.rawQuery)&&void 0!==c?c:"").trim(),$="elasticsearch"===k&&(x.metrics||x.bucketAggs||x.timeField)?JSON.stringify({query:F,metrics:null!==(h=x.metrics)&&void 0!==h?h:[],bucketAggs:null!==(g=x.bucketAggs)&&void 0!==g?g:[],timeField:null!==(y=x.timeField)&&void 0!==y?y:"@timestamp"}):F;return $?"__expr__"===E||"__expr__"===k||"expression"===k?[]:[{refId:String(null!==(f=x.refId)&&void 0!==f?f:`Q${t+1}`).trim()||`Q${t+1}`,expr:$,legend:String(null!==(v=null!==(b=x.legendFormat)&&void 0!==b?b:x.legend)&&void 0!==v?v:"").trim(),datasourceUid:E,datasourceType:k,datasourceUrl:S}]:[]}).filter((e,t,a)=>a.findIndex(t=>t.refId===e.refId&&t.expr===e.expr)===t),Rt=(e,t)=>W(function*(){if(!e||"__expr__"===e||"undefined"==typeof fetch)return"";try{var a,i;const n=yield fetch(`/api/datasources/uid/${encodeURIComponent(e)}`,{credentials:"same-origin"});if(!n.ok)return"";const r=yield n.json();return Pt(String(null!==(a=r.url)&&void 0!==a?a:"").trim(),String(null!==(i=r.type)&&void 0!==i?i:t))}catch(e){return""}})(),It=e=>W(function*(){if(0===e.length)return e;const t=Array.from(new Set(e.filter(e=>!e.datasourceUrl&&e.datasourceUid).map(e=>`${e.datasourceUid}:::${e.datasourceType}`))),a=yield Promise.all(t.map(e=>W(function*(){const[t,a]=e.split(":::");return[t,yield Rt(t,a)]})())),i=new Map(a);return e.map(e=>U(j({},e),{datasourceUrl:e.datasourceUrl||i.get(e.datasourceUid)||""}))})(),Vt=e=>{const t=[];return e.forEach(e=>{if(!e||"object"!=typeof e)return;const a=e;void 0!==a.id&&t.push(a),Array.isArray(a.panels)&&t.push(...Vt(a.panels))}),t},Ot=(e,t,a,i)=>{var n,r;return JSON.stringify({dashboardUid:e.dashboardUid,panelTitle:e.panelTitle,source:e.source,ruleNamePrefix:a,target:i,rangeSeconds:null!==(n=e.rangeSeconds)&&void 0!==n?n:0,stepSeconds:null!==(r=e.stepSeconds)&&void 0!==r?r:0,targets:e.targets.map(e=>{var t;return{refId:e.refId,expr:e.expr,datasourceUid:e.datasourceUid,datasourceType:e.datasourceType,datasourceUrl:null!==(t=e.datasourceUrl)&&void 0!==t?t:""}}),resolvedOptions:{setupMode:t.setupMode,metricPreset:t.metricPreset,effectiveMetricPreset:t.effectiveMetricPreset,detectionMode:t.detectionMode,algorithm:t.algorithm,anomalyDirection:t.anomalyDirection,minimumAbsoluteDeviation:t.minimumAbsoluteDeviation,minimumRelativeDeviation:t.minimumRelativeDeviation,minimumActivity:t.minimumActivity,persistenceBuckets:t.persistenceBuckets,persistenceWindow:t.persistenceWindow,recoveryThreshold:t.recoveryThreshold,recoveryBuckets:t.recoveryBuckets,cooldownBuckets:t.cooldownBuckets,dataQualityGate:t.dataQualityGate,sensitivity:t.sensitivity,baselineWindow:t.baselineWindow,seasonalitySamples:t.seasonalitySamples,seasonalRefinement:t.seasonalRefinement,severityPreset:t.severityPreset}})},qt=e=>{switch(e){case"1m":return 60;case"5m":return 300;case"15m":return 900;case"1h":return 3600;default:return 0}},Wt=(e,t,a,i,n,r)=>{var l,o;const s=e.targets.filter(e=>e.expr.trim().length>0);if(0===s.length)return null;const c=qt(n.bucketSpan),d=Math.max(0,Math.round(null!==(l=e.stepSeconds)&&void 0!==l?l:0)),m=d>0?d:c>0?Math.max(5,Math.min(c,60)):30,u=Math.max(256,n.baselineWindow*Math.max(n.seasonalitySamples,1)+8,6*n.baselineWindow),p=Math.max(0,Math.round(null!==(o=e.rangeSeconds)&&void 0!==o?o:0)),h=Math.max(3600,u*m);return{schemaVersion:3,pluginVersion:"1.5.0",capabilitiesRequired:["idempotentSync","scopeIdentity","directionPolicy","decisionLifecycle"],dashboardUid:e.dashboardUid,folderTitle:e.folderTitle,dashboardTitle:e.dashboardTitle,panelId:t,panelTitle:e.panelTitle,ruleNamePrefix:Ct(e.panelTitle,a),target:i,source:e.source,syncHash:r,scopeHash:Nt(e),scopePolicy:"saved"===e.source?"saved":"runtime",targets:s.map(e=>{var t;return{refId:e.refId,expr:e.expr,legend:e.legend,datasourceUid:e.datasourceUid,datasourceType:e.datasourceType,datasourceUrl:null!==(t=e.datasourceUrl)&&void 0!==t?t:""}}),resolvedOptions:{setupMode:n.setupMode,metricPreset:n.metricPreset,effectiveMetricPreset:n.effectiveMetricPreset,detectionMode:n.detectionMode,algorithm:n.algorithm,anomalyDirection:n.anomalyDirection,minimumAbsoluteDeviation:n.minimumAbsoluteDeviation,minimumRelativeDeviation:n.minimumRelativeDeviation,minimumActivity:n.minimumActivity,persistenceBuckets:n.persistenceBuckets,persistenceWindow:n.persistenceWindow,recoveryThreshold:n.recoveryThreshold,recoveryBuckets:n.recoveryBuckets,cooldownBuckets:n.cooldownBuckets,dataQualityGate:n.dataQualityGate,sensitivity:n.sensitivity,baselineWindow:n.baselineWindow,seasonalitySamples:n.seasonalitySamples,seasonalRefinement:n.seasonalRefinement,severityPreset:n.severityPreset,rangeSeconds:p>0?Math.max(4*m,p):h,stepSeconds:m,bucketSpanSeconds:c}}},zt=e=>"off"===e?{kind:"off",message:"Anomaly score feed is turned off for this panel.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}:"manual"===e?{kind:"idle",message:"Manual sync is ready. Use the button to publish plugin-computed anomaly scores for this panel.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}:{kind:"idle",message:"Auto sync watches this panel and republishes plugin-computed anomaly scores shortly after data is returned.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""},jt=e=>{switch(e){case"synced":return"Synced";case"syncing":return"Syncing";case"error":return"Error";case"unsupported":return"Action needed";case"off":return"Off";default:return"Ready"}},Ut=({panelId:e,panelTitle:t,options:a,resolvedOptions:i,liveTargets:n,savedContext:r,savedContextReady:l,analyses:o,timeRangeSeconds:s,queryStepSeconds:c})=>{var d;const[m,u]=(0,p.useState)(()=>{var e;return zt(null!==(e=a.scoreFeedMode)&&void 0!==e?e:"auto")}),[h,g]=(0,p.useState)(""),y=null!==(d=a.scoreFeedMode)&&void 0!==d?d:"auto",f=(0,p.useCallback)((d="manual")=>W(function*(){var m;if("off"!==y){if("auto"!==d||l)try{var p,f,v,b,x,w,E,k;let l=((e,t,a,i,n)=>({source:"live",dashboardUid:Bt()||"local_dashboard",folderTitle:Tt(),dashboardTitle:Dt()||"Grafana dashboard",panelTitle:t,targets:a,panelOptions:{},rangeSeconds:i,stepSeconds:n}))(0,t,n,s,c),y=a,$=St(a.scoreFeedEndpoint);if(r){"auto"===d&&(y=j({},a,r.panelOptions),$=St(y.scoreFeedEndpoint));const e="auto"===d?r.targets:n.length>0?n:r.targets;l=U(j({},r),{targets:e,source:"auto"===d||0===n.length||Lt(r.targets,n)?"saved":"live",rangeSeconds:s,stepSeconds:c})}const M=null!==(p="auto"===d?y.scoreFeedRuleNamePrefix:a.scoreFeedRuleNamePrefix)&&void 0!==p?p:"",N=st("auto"===d?y.scoreFeedTarget:a.scoreFeedTarget);l=U(j({},l),{targets:yield It(l.targets),rangeSeconds:s,stepSeconds:c});const L=Ot(l,i,M,N),A=Wt(l,e,M,N,i,L),C=((e,t,a,i,n,r)=>{const l=r.flatMap(e=>{var t;const a=null!==(t=[...e.allPoints].reverse().find(e=>null!==e.expected))&&void 0!==t?t:e.allPoints[e.allPoints.length-1];return a?[{key:e.key,label:e.label,timestamp:a.time/1e3,value:a.value,expected:a.expected,lower:a.lower,upper:a.upper,deviation:null===a.expected?null:a.value-a.expected,rawScore:a.score,pointRawScore:a.pointScore,windowRawScore:a.windowScore,scoreDriver:a.scoreDriver,normalizedScore:a.severityScore,severityLabel:a.severityLabel,isAnomaly:a.isAnomaly,decisionState:a.decisionState,confidenceScore:a.confidenceScore,confidenceLabel:a.confidenceLabel,dataQualityLabel:a.dataQualityLabel,threshold:n.sensitivity}]:[]});if(0===l.length)return null;const o=[...l].sort((e,t)=>t.normalizedScore-e.normalizedScore)[0],s=Array.from(new Map(e.targets.map(e=>[`${e.datasourceUid||"unknown"}:${e.datasourceType||"unknown"}`,{uid:e.datasourceUid||"unknown",type:e.datasourceType||"unknown"}])).values());return{dashboardUid:e.dashboardUid,folderTitle:e.folderTitle,dashboardTitle:e.dashboardTitle,panelId:t,panelTitle:e.panelTitle,ruleName:Ct(e.panelTitle,a),target:i,source:e.source,sourceDatasources:s,series:l,rule:{timestamp:Math.max(...l.map(e=>e.timestamp)),score:o.normalizedScore,rawScore:o.rawScore,breachCount:l.filter(e=>e.isAnomaly).length,seriesCount:l.length,activeSeries:l.length,severityLabel:o.severityLabel},resolvedOptions:{algorithm:n.algorithm,anomalyDirection:n.anomalyDirection,minimumAbsoluteDeviation:n.minimumAbsoluteDeviation,minimumRelativeDeviation:n.minimumRelativeDeviation,minimumActivity:n.minimumActivity,persistenceBuckets:n.persistenceBuckets,persistenceWindow:n.persistenceWindow,recoveryThreshold:n.recoveryThreshold,recoveryBuckets:n.recoveryBuckets,cooldownBuckets:n.cooldownBuckets,dataQualityGate:n.dataQualityGate,severityPreset:n.severityPreset,sensitivity:n.sensitivity}}})(l,e,M,N,i,o);if(!A&&!C)return void u((m="This panel has no query target or computed anomaly score points to publish yet. Refresh the panel after data is returned.",{kind:"unsupported",message:m,source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}));const B=JSON.stringify({registrationHash:L,target:N,ruleName:null!==(f=null!==(v=null==C?void 0:C.ruleName)&&void 0!==v?v:null==A?void 0:A.ruleNamePrefix)&&void 0!==f?f:"",ruleScore:null!==(b=null==C?void 0:C.rule.score)&&void 0!==b?b:null,ruleTimestamp:null!==(x=null==C?void 0:C.rule.timestamp)&&void 0!==x?x:null,series:null!==(w=null==C?void 0:C.series.map(e=>[e.key,e.timestamp,e.normalizedScore,e.isAnomaly]))&&void 0!==w?w:[],algorithm:i.algorithm,severityPreset:i.severityPreset});if("auto"===d&&B===h)return void u(e=>U(j({},e),{kind:"error"===e.kind?e.kind:"synced",message:null!==e.lastSyncedAt?e.message:`Auto sync is active. Latest plugin-computed scores are published to ${vt[N]}.`,source:l.source,syncHash:B}));u(e=>{var t;return U(j({},e),{kind:"syncing",message:"auto"===d?`Registering panel score feed and publishing latest scores to ${vt[N]}.`:`Registering panel score feed and publishing scores to ${vt[N]}.`,source:null!==(t=null==l?void 0:l.source)&&void 0!==t?t:e.source})});let D={};if(A){var S;const e=yield Mt(`${$}/api/capabilities`),t=A.capabilitiesRequired.filter(t=>{var a;return!(null===(a=e.features)||void 0===a?void 0:a.includes(t))});var F;if((null!==(S=e.apiSchemaVersion)&&void 0!==S?S:0)<A.schemaVersion||t.length>0)throw new Error(`Exporter ${null!==(F=e.exporterVersion)&&void 0!==F?F:"unknown"} is not compatible with this plugin. Missing capabilities: ${t.join(", ")||"API schema v2"}. Upgrade the exporter first.`);D=yield Mt(`${$}/api/sync/panel`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(A)})}let T={};C&&(T=yield Mt(`${$}/api/feed/scores`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(C)}));const P=((e,t)=>{const a=new Map;return e.forEach(e=>{var t;return a.set(`${e.rule}:${null!==(t=e.target)&&void 0!==t?t:""}`,e)}),t.forEach(e=>{var t;return a.set(`${e.rule}:${null!==(t=e.target)&&void 0!==t?t:""}`,e)}),Array.from(a.values())})(Array.isArray(T.registered)?T.registered:[],Array.isArray(D.registered)?D.registered:[]),_=[...Array.isArray(D.removed)?D.removed:[],...Array.isArray(T.removed)?T.removed:[]],R="saved"===l.source?"saved dashboard":"live panel",I=Math.max(0,Math.round(null!==(E=null!==(k=T.acceptedSeries)&&void 0!==k?k:null==C?void 0:C.series.length)&&void 0!==E?E:P.length));g(B),u({kind:"synced",message:P.length>0?C?`Published ${I} plugin-computed score series and registered backend recompute from the ${R} to ${vt[N]}.`:`Registered backend recompute from the ${R} to ${vt[N]}; scores will continue while the dashboard is closed.`:_.length>0?`Removed ${_.length} previous score feed registration${1===_.length?"":"s"} because this panel no longer exposes computed score data.`:`Score feed is active for this panel and targets ${vt[N]}.`,source:l.source,registered:P,removed:_,lastSyncedAt:Date.now(),syncHash:B})}catch(e){u(t=>U(j({},t),{kind:"error",message:e instanceof Error?e.message:"Score feed sync failed unexpectedly."}))}}else u(zt("off"))})(),[o,n,h,a,e,t,c,i,r,l,y,s]);return(0,p.useEffect)(()=>{if("off"===y)return void u(zt("off"));if("manual"===y)return void u(e=>j({},"synced"===e.kind?e:U(j({},zt("manual")),{source:e.source,registered:e.registered,removed:e.removed,lastSyncedAt:e.lastSyncedAt,syncHash:e.syncHash})));if("undefined"==typeof window)return;let e=!1,t=!1;const a=()=>W(function*(){if(!e&&!t){t=!0;try{yield f("auto")}finally{t=!1}}})();a();const i=window.setInterval(()=>{a()},15e3);return()=>{e=!0,window.clearInterval(i)}},[f,y]),U(j({},m),{syncNow:()=>f("manual")})},Ht=["Configuration"],Qt=["Anomaly score feed"],Gt=["Analysis"],Yt=["Advanced tuning"],Kt=["Display"],Jt=["Visible sections"],Zt=[{label:"Recommended",value:"recommended",description:"Pick the metric type and let the plugin choose the algorithm and severity tuning."},{label:"Advanced",value:"advanced",description:"Expose manual algorithm, threshold, and severity controls."}],Xt=[{label:"Single metric",value:"single"},{label:"Multi metric",value:"multi"}],ea=[{label:"High mean",value:"high_mean",description:"Flag only sustained or unusual increases above the learned baseline."},{label:"Low mean",value:"low_mean",description:"Flag only sustained or unusual decreases below the learned baseline."},{label:"High or low",value:"high_or_low",description:"Flag meaningful deviations in either direction."}],ta=[{label:"Auto sync (Recommended)",value:"auto",description:"Continuously publish plugin-computed anomaly scores to the selected score feed target."},{label:"Manual sync",value:"manual",description:"Show a sync button so users can publish the current plugin-computed score snapshot on demand."},{label:"Off",value:"off",description:"Disable anomaly score feed publishing for this panel."}],aa=[{label:"Prometheus metrics",value:"prometheus",description:"Expose the plugin-computed anomaly scores from the exporter /metrics endpoint."},{label:"Loki",value:"loki",description:"Write plugin-computed anomaly scores to the Loki sink."},{label:"InfluxDB",value:"influxdb",description:"Write plugin-computed anomaly scores to the InfluxDB sink."},{label:"PostgreSQL",value:"postgresql",description:"Write plugin-computed anomaly scores to the PostgreSQL sink."},{label:"ClickHouse",value:"clickhouse",description:"Write plugin-computed anomaly scores to the ClickHouse sink."},{label:"Elasticsearch",value:"elasticsearch",description:"Write plugin-computed anomaly scores to the Elasticsearch sink."}],ia=[{label:"Auto (Recommended)",value:"auto",description:"Inspect the metric names and choose the safest starting algorithm automatically."},{label:"Traffic / throughput",value:"traffic",description:"Good starting point for request rate, throughput, and volume metrics."},{label:"Latency / duration",value:"latency",description:"Tuned for latency, p95, and response-time style metrics."},{label:"Error rate",value:"error_rate",description:"Tuned for error percentage and error-count spikes."},{label:"Resource usage",value:"resource",description:"Useful for CPU, memory, load, saturation, and host metrics."},{label:"Business KPI",value:"business",description:"Useful for revenue, signups, conversions, and other cyclical business metrics."},{label:"Subtle level shift / drift",value:"level_shift",description:"Best when the baseline changes gradually or steps up/down without a single sharp spike."}],na=[{label:"Auto",value:"auto",description:"Choose an efficient pre-aggregation span automatically on dense or live data."},{label:"Raw samples",value:"raw",description:"Analyze every incoming sample without pre-aggregation."},{label:"1 minute",value:"1m",description:"Aggregate close samples into 1-minute buckets before scoring."},{label:"5 minutes",value:"5m",description:"Aggregate samples into 5-minute buckets before scoring."},{label:"15 minutes",value:"15m",description:"Aggregate samples into 15-minute buckets before scoring."},{label:"1 hour",value:"1h",description:"Aggregate samples into 1-hour buckets before scoring."}],ra=[{label:"Rolling z-score",value:"zscore",description:"Fast default for spikes and dips in streaming metrics."},{label:"Rolling MAD",value:"mad",description:"Robust against noisy outliers and uneven distributions."},{label:"EWMA baseline",value:"ewma",description:"Tracks gradual baseline shifts while still catching sudden jumps."},{label:"Seasonal baseline",value:"seasonal",description:"Compares each point with similar positions from earlier cycles."},{label:"Level shift detector",value:"level_shift",description:"Looks for sustained baseline changes and subtle step-ups that build over several buckets."}],la=[{label:"Cycle only",value:"cycle",description:"Uses a fixed sample lag such as 24 or 288 samples."},{label:"Hour of day",value:"hour_of_day",description:"Matches earlier values from the same hour bucket."},{label:"Weekday + hour",value:"weekday_hour",description:"Matches earlier values from the same weekday and hour bucket."}],oa=[{label:"Balanced",value:"balanced",description:"General-purpose default for dashboards and alert handoff."},{label:"Warning first",value:"warning_first",description:"Promotes warning and medium severity earlier for watchlist-heavy teams."},{label:"Page first",value:"page_first",description:"Keeps high and critical severities stricter for paging workflows."}],sa=[{label:"Auto (Recommended)",value:"auto",description:"Choose a readable time tick density automatically from the panel width and visible range."},{label:"Compact",value:"compact",description:"Use fewer time labels for dense dashboards and smaller panels."},{label:"Balanced",value:"balanced",description:"Keep a mid-density time axis for general dashboard use."},{label:"Dense",value:"dense",description:"Show more time labels for close operational tracking."}],ca=[{label:"Bottom only",value:"bottom",description:"Show time labels only on the bottom axis."},{label:"Top + bottom",value:"top_and_bottom",description:"Add a second time guide on top for faster cross-checking during incident review."}],da=[{label:"Severity shapes (Recommended)",value:"severity",description:"Use different marker shapes for low, medium, high, and critical anomalies."},{label:"Classic circles",value:"classic",description:"Keep the previous circle-style anomaly markers."}],ma=new c.PanelPlugin(({id:e,options:t,data:a,width:i,height:n,timeRange:r,timeZone:l})=>{var o,s,d,m,u,f,v,b,x,w,E,k,S,F,$,M;const N=(0,y.useTheme2)(),L=(A=N.isDark,{wrapper:g.css`
    width: 100%;
    height: 100%;
    min-height: 0;
    container-type: inline-size;
    padding: 10px;
    box-sizing: border-box;
    overflow: auto;
    font-family: 'Segoe UI', sans-serif;
    color: ${A?"#F3F4F6":"#111827"};
    background: ${A?"radial-gradient(circle at 8% 0%, rgba(220,38,38,0.12), transparent 26%), linear-gradient(180deg, #060A12 0%, #0B111C 100%)":"linear-gradient(180deg, #F8FAFC 0%, #EEF4FF 100%)"};
  `,operationalCanvas:g.css`
    width: 100%;
    min-height: 100%;
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(300px, 360px);
    gap: 12px;
    align-items: stretch;
    @media (max-width: 1100px) {
      grid-template-columns: 1fr;
    }
    @container (max-width: 1040px) {
      grid-template-columns: 1fr;
    }
  `,workspacePane:g.css`
    min-width: 0;
    min-height: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,inspectorRail:g.css`
    min-width: 0;
    min-height: 0;
    @media (min-width: 1101px) {
      position: sticky;
      top: 0;
      align-self: start;
      max-height: calc(100vh - 24px);
      overflow: auto;
    }
    @container (max-width: 1040px) {
      position: static;
      max-height: none;
      overflow: visible;
    }
  `,header:g.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
  `,statusHeader:g.css`
    position: relative;
    display: grid;
    grid-template-columns: minmax(260px, 0.9fr) minmax(340px, 1.1fr);
    gap: 18px;
    align-items: stretch;
    padding: 14px 16px 14px 22px;
    border-radius: 18px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(135deg, rgba(17,24,39,0.94) 0%, rgba(12,18,29,0.98) 62%, rgba(8,13,22,0.98) 100%)":"linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%)"};
    overflow: hidden;
    box-shadow: ${A?"0 22px 70px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.04)":"0 16px 34px rgba(15,23,42,0.06)"};
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
    @container (max-width: 760px) {
      grid-template-columns: 1fr;
      gap: 14px;
    }
  `,statusRail:g.css`
    position: absolute;
    inset: 0 auto 0 0;
    width: 5px;
    border-radius: 18px 0 0 18px;
  `,statusMain:g.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 10px;
    padding-left: 48px;
    @media (max-width: 700px) {
      padding-left: 34px;
    }
    @container (max-width: 520px) {
      padding-left: 34px;
    }
  `,statusIcon:g.css`
    position: absolute;
    left: 18px;
    top: 50%;
    width: 30px;
    height: 30px;
    transform: translateY(-50%);
    display: grid;
    place-items: center;
    border-radius: 999px;
    color: #FCA5A5;
    border: 1px solid rgba(248,113,113,0.62);
    background: rgba(127,29,29,0.22);
    box-shadow: 0 0 0 5px rgba(220,38,38,0.08);
    @container (max-width: 760px) {
      top: 34px;
      transform: none;
    }
  `,statusIconSvg:g.css`
    width: 18px;
    height: 18px;
    overflow: visible;
  `,statusTitleRow:g.css`
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
  `,statusBadge:g.css`
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 6px 10px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    border: 1px solid currentColor;
  `,statusDot:g.css`
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: currentColor;
    box-shadow: 0 0 0 3px ${A?"rgba(148,163,184,0.18)":"rgba(15,23,42,0.10)"};
  `,titleBlock:g.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
  `,title:g.css`
    font-size: clamp(22px, 1.65vw, 30px);
    font-weight: 800;
    letter-spacing: 0.01em;
  `,subtitle:g.css`
    font-size: 12px;
    color: ${A?"#94A3B8":"#475569"};
    line-height: 1.5;
  `,headerMetaGrid:g.css`
    display: grid;
    grid-template-columns: repeat(2, minmax(140px, max-content));
    gap: 8px 24px;
    color: ${A?"#C7D2E4":"#334155"};
    font-size: 12px;
    font-weight: 700;
    @media (max-width: 700px) {
      grid-template-columns: 1fr;
    }
    @container (max-width: 520px) {
      grid-template-columns: 1fr;
    }
  `,metaAccent:g.css`
    color: #F87171;
    font-weight: 900;
  `,recommendationBanner:g.css`
    display: none;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 12px;
    border-radius: 14px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
  `,recommendationBadge:g.css`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 78px;
    padding: 6px 10px;
    border-radius: 999px;
    background: ${A?"#172554":"#DBEAFE"};
    color: ${A?"#BFDBFE":"#1D4ED8"};
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
  `,recommendationCopy:g.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  `,recommendationTitle:g.css`
    font-size: 13px;
    font-weight: 700;
    color: ${A?"#F8FAFC":"#0F172A"};
  `,recommendationText:g.css`
    font-size: 12px;
    line-height: 1.55;
    color: ${A?"#CBD5E1":"#334155"};
  `,stats:g.css`
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
  `,statusStats:g.css`
    display: grid;
    grid-template-columns: 1.18fr repeat(3, minmax(82px, 1fr));
    gap: 10px;
    align-content: stretch;
    min-width: 0;
    @media (max-width: 700px) {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    @container (max-width: 520px) {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  `,statCard:g.css`
    min-width: 0;
    padding: 12px 13px;
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.12)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(30,41,59,0.62), rgba(15,23,42,0.82))":"#F8FAFC"};
    box-shadow: ${A?"inset 0 1px 0 rgba(255,255,255,0.04)":"none"};
  `,statCardPrimary:g.css`
    border-color: rgba(248,113,113,0.38);
    background: linear-gradient(145deg, #B91C1C 0%, #7F1D1D 100%);
    color: #FFFFFF !important;
    box-shadow: 0 12px 26px rgba(220,38,38,0.22), inset 0 1px 0 rgba(255,255,255,0.12);
  `,statLabel:g.css`
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: ${A?"#94A3B8":"#64748B"};
  `,statValue:g.css`
    margin-top: 6px;
    font-size: clamp(18px, 1.35vw, 22px);
    font-weight: 850;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  `,statCaption:g.css`
    margin-top: 3px;
    font-size: 11px;
    color: ${A?"#94A3B8":"#64748B"};
    font-weight: 800;
  `,chartCard:g.css`
    flex: 1 1 auto;
    min-height: clamp(340px, 45vh, 520px);
    position: relative;
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, #0A1321 0%, #07101D 100%)":"#FFFFFF"};
    overflow: hidden;
    box-shadow: ${A?"inset 0 1px 0 rgba(255,255,255,0.04), 0 18px 44px rgba(0,0,0,0.22)":"0 14px 28px rgba(15,23,42,0.05)"};
    outline: none;
    &:focus-visible {
      border-color: ${A?"#60A5FA":"#2563EB"};
      box-shadow: ${A?"0 0 0 1px rgba(96,165,250,0.55), inset 0 1px 0 rgba(148,163,184,0.05)":"0 0 0 1px rgba(37,99,235,0.35), 0 14px 28px rgba(15,23,42,0.05)"};
    }
  `,incidentRibbonPanel:g.css`
    position: relative;
    min-height: 34px;
    padding: 5px 10px;
    border-radius: 13px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.92), rgba(8,13,22,0.98))":"#FFFFFF"};
    box-shadow: ${A?"inset 0 1px 0 rgba(255,255,255,0.035)":"0 10px 22px rgba(15,23,42,0.04)"};
  `,incidentRibbonEmpty:g.css`
    display: flex;
    align-items: center;
    min-height: 24px;
    padding: 0 4px;
    color: ${A?"#94A3B8":"#64748B"};
    font-size: 12px;
    font-weight: 700;
  `,legend:g.css`
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    align-items: center;
  `,legendTable:g.css`
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.94), rgba(10,16,26,0.98))":"#FFFFFF"};
    overflow: hidden;
    min-width: 0;
  `,legendTableHeader:g.css`
    display: grid;
    grid-template-columns: minmax(180px, 1fr) 96px 84px 104px;
    gap: 10px;
    padding: 8px 12px;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: ${A?"#94A3B8":"#64748B"};
    border-bottom: 1px solid ${A?"#1E293B":"#D7E3F4"};
    @media (max-width: 700px) {
      grid-template-columns: minmax(0, 1fr) 72px 72px;
      & > span:last-child {
        display: none;
      }
    }
  `,legendToolbar:g.css`
    display: grid;
    grid-template-columns: minmax(0, 1fr) 150px;
    gap: 8px;
    padding: 9px 10px;
    border-bottom: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"rgba(8, 13, 22, 0.55)":"#F8FAFC"};
    @media (max-width: 560px) {
      grid-template-columns: 1fr;
    }
  `,legendControl:g.css`
    width: 100%;
    min-width: 0;
    height: 30px;
    border-radius: 8px;
    border: 1px solid ${A?"#334155":"#CBD5E1"};
    background: ${A?"#0B1220":"#FFFFFF"};
    color: ${A?"#E2E8F0":"#0F172A"};
    padding: 0 9px;
    font-size: 11px;
    font-weight: 650;
    outline: none;
    &:focus {
      border-color: ${A?"#60A5FA":"#2563EB"};
      box-shadow: 0 0 0 2px ${A?"rgba(96,165,250,0.16)":"rgba(37,99,235,0.12)"};
    }
  `,legendTableRow:g.css`
    width: 100%;
    display: grid;
    grid-template-columns: minmax(180px, 1fr) 96px 84px 104px;
    gap: 10px;
    align-items: center;
    padding: 9px 12px;
    border-top: 0;
    border-left: 0;
    border-right: 0;
    border-bottom: 1px solid ${A?"rgba(30,41,59,0.7)":"rgba(215,227,244,0.8)"};
    background: transparent;
    color: inherit;
    text-align: left;
    cursor: pointer;
    font-size: 12px;
    &:hover {
      background: ${A?"rgba(59,130,246,0.09)":"rgba(37,99,235,0.06)"};
    }
    &:focus-visible {
      outline: 2px solid ${A?"#60A5FA":"#2563EB"};
      outline-offset: -2px;
    }
    &:last-child {
      border-bottom: 0;
    }
    @media (max-width: 700px) {
      grid-template-columns: minmax(0, 1fr) 72px 72px;
      & > span:last-child {
        display: none;
      }
    }
  `,legendTableFooter:g.css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 9px 12px;
    border-top: 1px solid ${A?"rgba(30,41,59,0.8)":"rgba(215,227,244,0.9)"};
    color: ${A?"#94A3B8":"#64748B"};
    font-size: 11px;
    font-weight: 750;
  `,legendSeriesName:g.css`
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 700;
    color: ${A?"#E2E8F0":"#0F172A"};
  `,legendValue:g.css`
    font-variant-numeric: tabular-nums;
    font-weight: 700;
    color: ${A?"#CBD5E1":"#334155"};
  `,legendItem:g.css`
    display: inline-flex;
    align-items: center;
    gap: 8px;
    max-width: 100%;
    min-width: 0;
    font-size: 12px;
    padding: 6px 10px;
    border-radius: 999px;
    background: ${A?"#111827":"#EFF6FF"};
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,legendSwatch:g.css`
    width: 10px;
    height: 10px;
    border-radius: 999px;
  `,grid:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
    gap: 12px;
  `,bottomDock:g.css`
    display: grid;
    grid-template-columns: minmax(360px, 1.1fr) minmax(280px, 0.9fr);
    gap: 10px;
    align-items: stretch;
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
  `,secondaryDock:g.css`
    display: grid;
    grid-template-columns: minmax(420px, 1.35fr) minmax(260px, 0.65fr);
    gap: 10px;
    align-items: start;
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
  `,sideUtilityStack:g.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,card:g.css`
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.94), rgba(10,16,26,0.98))":"#FFFFFF"};
    padding: 14px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    min-height: 0;
    box-shadow: ${A?"inset 0 1px 0 rgba(255,255,255,0.035)":"0 10px 24px rgba(15,23,42,0.045)"};
  `,cardTitle:g.css`
    font-size: 15px;
    font-weight: 700;
    line-height: 1.4;
  `,summaryList:g.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
    max-height: min(360px, 42vh);
    overflow-y: auto;
    padding-right: 4px;
  `,summaryTimeline:g.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 10px 12px 12px;
    border-radius: 14px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#0F172A":"#F8FAFC"};
  `,summaryRow:g.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
    cursor: pointer;
    transition: transform 120ms ease, border-color 120ms ease;
    &:hover {
      transform: translateY(-1px);
      border-color: ${A?"#334155":"#93C5FD"};
    }
  `,summaryRowSelected:g.css`
    border-color: ${A?"#3B82F6":"#2563EB"};
    box-shadow: inset 0 0 0 1px ${A?"#3B82F6":"#2563EB"};
  `,summaryTitle:g.css`
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
  `,summaryMeta:g.css`
    display: flex;
    justify-content: space-between;
    gap: 8px;
    flex-wrap: wrap;
    font-size: 12px;
    color: ${A?"#94A3B8":"#475569"};
  `,severityBadge:g.css`
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  `,compactHealthStrip:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(118px, 1fr));
    gap: 8px;
  `,scoreFeedTargetGrid:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(168px, 1fr));
    gap: 8px;
  `,scoreFeedTargetCard:g.css`
    min-width: 0;
    min-height: 96px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: 7px;
    padding: 10px;
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.82) 0%, rgba(8,13,22,0.72) 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,scoreFeedTargetTop:g.css`
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 9px;
  `,scoreFeedTargetIcon:g.css`
    flex: 0 0 auto;
    width: 27px;
    height: 27px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    background: ${A?"rgba(15,23,42,0.92)":"#F8FAFC"};
    border: 1px solid ${A?"rgba(148,163,184,0.16)":"#D7E3F4"};
    font-size: 16px;
    font-weight: 900;
    line-height: 1;

    svg {
      display: block;
      width: 18px;
      height: 18px;
    }
  `,scoreFeedTargetTitle:g.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 12px;
    font-weight: 850;
    color: ${A?"#E2E8F0":"#0F172A"};
  `,scoreFeedTargetStatus:g.css`
    align-self: flex-start;
    min-width: 62px;
    display: inline-flex;
    justify-content: center;
    padding: 5px 10px;
    border-radius: 7px;
    font-size: 11px;
    font-weight: 850;
  `,scoreFeedTargetMeta:g.css`
    font-size: 11px;
    font-weight: 750;
    color: ${A?"#AAB7CA":"#64748B"};
  `,healthChip:g.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: space-between;
    gap: 6px;
    min-height: 68px;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${A?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.82) 0%, rgba(8,13,22,0.68) 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,healthChipCompact:g.css`
    min-height: 58px;
    padding: 9px 10px;
  `,healthChipText:g.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  `,healthChipLabel:g.css`
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    color: ${A?"#94A3B8":"#64748B"};
  `,healthChipValue:g.css`
    font-size: 12px;
    font-weight: 800;
    color: ${A?"#E2E8F0":"#0F172A"};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,targetBadge:g.css`
    min-width: 0;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    max-width: 100%;
  `,targetIcon:g.css`
    flex: 0 0 auto;
    width: 28px;
    height: 28px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    background: ${A?"rgba(37,99,235,0.18)":"#EFF6FF"};
    border: 1px solid ${A?"rgba(96,165,250,0.22)":"#BFDBFE"};
    font-size: 15px;
    line-height: 1;

    svg {
      display: block;
      width: 18px;
      height: 18px;
    }
  `,targetText:g.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 1px;
  `,targetName:g.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 12px;
    font-weight: 850;
    color: ${A?"#E2E8F0":"#0F172A"};
  `,targetLanguage:g.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 10px;
    font-weight: 750;
    color: ${A?"#94A3B8":"#64748B"};
  `,labelChipGrid:g.css`
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  `,labelChip:g.css`
    max-width: 100%;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 8px;
    border-radius: 999px;
    border: 1px solid ${A?"rgba(96,165,250,0.24)":"#BFDBFE"};
    background: ${A?"rgba(30,64,175,0.24)":"#EFF6FF"};
    color: ${A?"#DBEAFE":"#1D4ED8"};
    font-size: 11px;
    font-weight: 800;
  `,labelChipKey:g.css`
    opacity: 0.72;
  `,labelChipValue:g.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,staleBanner:g.css`
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 9px 12px;
    border-radius: 14px;
    border: 1px solid ${A?"#92400E":"#FDBA74"};
    background: ${A?"rgba(146,64,14,0.22)":"#FFF7ED"};
    color: ${A?"#FDBA74":"#9A3412"};
    font-size: 12px;
    font-weight: 700;
  `,incidentHeader:g.css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 2px 8px 0;
    flex-wrap: wrap;
  `,severityLegend:g.css`
    display: inline-flex;
    align-items: center;
    gap: 18px;
    flex-wrap: wrap;
    font-size: 12px;
    font-weight: 800;
    color: ${A?"#AAB7CA":"#475569"};
  `,severityLegendItem:g.css`
    display: inline-flex;
    align-items: center;
    gap: 7px;
  `,severityLegendSwatch:g.css`
    width: 10px;
    height: 10px;
    border-radius: 2px;
  `,inlineInspectorLegacy:g.css`
    display: none;
  `,inspectorCard:g.css`
    min-height: 100%;
    border-radius: 16px;
    border: 1px solid ${A?"rgba(148,163,184,0.15)":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, rgba(15,23,42,0.98), rgba(8,13,22,0.99))":"#FFFFFF"};
    box-shadow: ${A?"0 24px 70px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.045)":"0 18px 34px rgba(15,23,42,0.08)"};
    padding: 18px;
    display: flex;
    flex-direction: column;
    gap: 16px;
  `,inspectorTop:g.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
  `,inspectorTitle:g.css`
    font-size: 20px;
    font-weight: 850;
    letter-spacing: -0.01em;
  `,inspectorClose:g.css`
    width: 28px;
    height: 28px;
    display: grid;
    place-items: center;
    border: 0;
    border-radius: 999px;
    background: transparent;
    color: ${A?"#94A3B8":"#64748B"};
    font-size: 22px;
    cursor: default;
  `,inspectorTimestamp:g.css`
    display: flex;
    align-items: center;
    gap: 8px;
    padding-bottom: 12px;
    border-bottom: 1px solid ${A?"rgba(148,163,184,0.13)":"#E2E8F0"};
    color: ${A?"#D6DEEB":"#334155"};
    font-size: 15px;
    font-weight: 800;
  `,inspectorRows:g.css`
    display: grid;
    gap: 10px;
    padding-bottom: 12px;
    border-bottom: 1px solid ${A?"rgba(148,163,184,0.13)":"#E2E8F0"};
  `,inspectorRow:g.css`
    display: grid;
    grid-template-columns: minmax(110px, 0.72fr) minmax(0, 1fr);
    gap: 12px;
    align-items: baseline;
    font-size: 13px;
  `,inspectorRowLabel:g.css`
    color: ${A?"#94A3B8":"#64748B"};
    font-weight: 750;
  `,inspectorRowValue:g.css`
    min-width: 0;
    color: ${A?"#E2E8F0":"#0F172A"};
    font-weight: 800;
    text-align: right;
    overflow-wrap: anywhere;
  `,inspectorSectionTitle:g.css`
    font-size: 14px;
    font-weight: 850;
    color: ${A?"#EEF2FF":"#0F172A"};
  `,inspectorHealthRow:g.css`
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    gap: 12px;
  `,inspectorPill:g.css`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 5px 9px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 850;
  `,inspectorActionStack:g.css`
    display: grid;
    gap: 8px;
  `,inspectorActionButton:g.css`
    display: inline-flex;
    align-items: center;
    width: 100%;
    min-height: 42px;
    justify-content: center;
    border-radius: 9px;
    font-size: 13px;
    box-shadow: none;
  `,inspectorActionButtonPrimary:g.css`
    border-color: #2563EB;
    background: linear-gradient(180deg, #3B82F6 0%, #2563EB 100%);
    color: #FFFFFF;
  `,inspectorActionButtonSecondary:g.css`
    border-color: ${A?"rgba(148,163,184,0.18)":"#CBD5E1"};
    background: ${A?"rgba(15,23,42,0.72)":"#F8FAFC"};
    color: ${A?"#D6DEEB":"#334155"};
  `,queryPreview:g.css`
    max-height: 170px;
    overflow: auto;
    margin: 0;
    padding: 12px;
    border-radius: 10px;
    border: 1px solid ${A?"rgba(148,163,184,0.14)":"#D7E3F4"};
    background: ${A?"#101820":"#F8FAFC"};
    color: ${A?"#FBBF24":"#92400E"};
    font-family: 'Cascadia Code', Consolas, monospace;
    font-size: 10.5px;
    line-height: 1.5;
    white-space: pre-wrap;
  `,scoreFeedCard:g.css`
    min-width: 0;
    position: relative;
    overflow: hidden;
    &::before {
      content: '';
      position: absolute;
      inset: 0 auto 0 0;
      width: 3px;
      background: ${A?"linear-gradient(180deg, #38BDF8 0%, #2563EB 55%, #22C55E 100%)":"linear-gradient(180deg, #0EA5E9 0%, #2563EB 55%, #16A34A 100%)"};
      opacity: 0.9;
    }
  `,profileCard:g.css`
    gap: 10px;
  `,profileSummary:g.css`
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  `,profileDetailGrid:g.css`
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 8px;
    @media (max-width: 520px) {
      grid-template-columns: 1fr;
    }
  `,handoffCard:g.css`
    padding: 12px;
    gap: 10px;
    background: ${A?"linear-gradient(180deg, rgba(8,13,22,0.88), rgba(6,10,18,0.96))":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,handoffHeader:g.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
  `,detailGrid:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 10px;
  `,detailStat:g.css`
    min-width: 0;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
  `,detailLabel:g.css`
    font-size: 11px;
    color: ${A?"#94A3B8":"#64748B"};
    text-transform: uppercase;
    letter-spacing: 0.06em;
  `,detailValue:g.css`
    margin-top: 6px;
    font-size: 14px;
    font-weight: 700;
    line-height: 1.4;
    overflow-wrap: anywhere;
  `,detailTable:g.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
  `,metricBreakdownList:g.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,metricBreakdownCard:g.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;
    border-radius: 14px;
    border: 1px solid ${A?"#22314A":"#D7E3F4"};
    background: ${A?"linear-gradient(180deg, #101A2B 0%, #0E1625 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,metricBreakdownHeader:g.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
  `,metricBreakdownTitle:g.css`
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
  `,metricBreakdownReason:g.css`
    margin-top: 4px;
    font-size: 11px;
    line-height: 1.45;
    color: ${A?"#94A3B8":"#64748B"};
  `,metricBreakdownGrid:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(112px, 1fr));
    gap: 8px;
  `,metricBreakdownStat:g.css`
    min-width: 0;
    padding: 8px 10px;
    border-radius: 10px;
    border: 1px solid ${A?"#1E293B":"#E2E8F0"};
    background: ${A?"rgba(2, 6, 23, 0.58)":"rgba(255, 255, 255, 0.82)"};
  `,metricBreakdownStatLabel:g.css`
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: ${A?"#94A3B8":"#64748B"};
  `,metricBreakdownStatValue:g.css`
    margin-top: 5px;
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
    color: ${A?"#F8FAFC":"#0F172A"};
    overflow-wrap: anywhere;
  `,actionRow:g.css`
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    align-items: center;
  `,actionButton:g.css`
    border: 1px solid ${A?"#1D4ED8":"#93C5FD"};
    background: ${A?"#172554":"#EFF6FF"};
    color: ${A?"#DBEAFE":"#1D4ED8"};
    border-radius: 999px;
    padding: 8px 14px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 120ms ease, transform 120ms ease;
    &:hover:enabled {
      transform: translateY(-1px);
    }
    &:disabled {
      cursor: not-allowed;
      opacity: 0.55;
    }
  `,actionButtonSecondary:g.css`
    border: 1px solid ${A?"#334155":"#CBD5E1"};
    background: ${A?"#111827":"#F8FAFC"};
    color: ${A?"#E2E8F0":"#334155"};
    border-radius: 999px;
    padding: 8px 14px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 120ms ease, transform 120ms ease;
    &:hover:enabled {
      transform: translateY(-1px);
    }
    &:disabled {
      cursor: not-allowed;
      opacity: 0.55;
    }
  `,actionNotice:g.css`
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 12px;
    border-radius: 14px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
  `,feedRuleList:g.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,wideCard:g.css`
    grid-column: 1 / -1;
  `,feedRuleCard:g.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;
    border-radius: 12px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
  `,codeLine:g.css`
    border-radius: 10px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#020617":"#F8FAFC"};
    padding: 10px 12px;
    font-family: 'Cascadia Code', 'Consolas', monospace;
    font-size: 11px;
    line-height: 1.55;
    word-break: break-word;
  `,detailRow:g.css`
    display: grid;
    grid-template-columns: minmax(0, 1.3fr) repeat(4, minmax(0, 1fr));
    gap: 10px;
    align-items: center;
    font-size: 12px;
  `,detailHeaderRow:g.css`
    color: ${A?"#94A3B8":"#64748B"};
    text-transform: uppercase;
    letter-spacing: 0.04em;
    font-size: 11px;
  `,monoBlock:g.css`
    width: 100%;
    min-height: 170px;
    max-height: 320px;
    overflow: auto;
    border-radius: 12px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#020617":"#F8FAFC"};
    padding: 12px;
    box-sizing: border-box;
    font-family: 'Cascadia Code', 'Consolas', monospace;
    font-size: 11px;
    line-height: 1.55;
    white-space: pre-wrap;
    word-break: break-word;
  `,emptyState:g.css`
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 240px;
    border-radius: 16px;
    border: 1px dashed ${A?"#334155":"#CBD5E1"};
    background: ${A?"#020617":"#FFFFFF"};
    color: ${A?"#94A3B8":"#64748B"};
    text-align: center;
    padding: 20px;
    line-height: 1.6;
  `,skeletonShell:g.css`
    display: grid;
    grid-template-rows: auto minmax(240px, 1fr) auto;
    gap: 12px;
  `,skeletonBlock:g.css`
    position: relative;
    overflow: hidden;
    min-height: 20px;
    border-radius: 14px;
    border: 1px solid ${A?"#1E293B":"#D7E3F4"};
    background: ${A?"#111827":"#F8FAFC"};
    &::after {
      content: '';
      position: absolute;
      inset: 0;
      transform: translateX(-100%);
      background: linear-gradient(90deg, transparent, ${A?"rgba(148,163,184,0.12)":"rgba(148,163,184,0.22)"}, transparent);
      animation: anomaly-shimmer 1.45s infinite;
    }
    @keyframes anomaly-shimmer {
      100% {
        transform: translateX(100%);
      }
    }
  `,skeletonHeader:g.css`
    height: 86px;
  `,skeletonChart:g.css`
    min-height: 320px;
  `,skeletonRows:g.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
  `,skeletonRow:g.css`
    height: 128px;
  `});var A;const C=(0,p.useMemo)(()=>ze(a.series),[a.series]),B=(e=>{const t=String(null!=e?e:"").toLowerCase();return t.includes("loading")||t.includes("streaming")||t.includes("notstarted")})(a.state),[D,T]=(0,p.useState)([]);(0,p.useEffect)(()=>{if(0===C.length||"undefined"==typeof window)return;const e=window.setTimeout(()=>{T(C)},0);return()=>window.clearTimeout(e)},[C]);const P=C.length>0?C:B?D:C,_=B&&0===C.length&&D.length>0,R=B&&0===P.length,I=(0,p.useMemo)(()=>P.map(e=>e.label),[P]),V=(0,p.useMemo)(()=>Ae(t,I),[t,I]),O=(0,p.useMemo)(()=>We(t),[t]),q=t.title||"Anomaly detector",z=Bt(),[H,Q]=(0,p.useState)(null),Y=(null==H?void 0:H.dashboardUid)===z?H.context:null,K=!z||(null==H?void 0:H.dashboardUid)===z,Z=(0,p.useMemo)(()=>{var e,t;return _t(null!==(e=null===(t=a.request)||void 0===t?void 0:t.targets)&&void 0!==e?e:[])},[a]);(0,p.useEffect)(()=>{let t=!1;return z?((a=null!=e?e:0,i=q,W(function*(){var e,t,n,r,l,o,s,c;const d=Bt();if(!d||"undefined"==typeof fetch)return null;const m=yield fetch(`/api/dashboards/uid/${encodeURIComponent(d)}`,{credentials:"same-origin"});if(!m.ok)throw new Error(`Could not read the saved dashboard definition (${m.status}).`);const u=yield m.json(),p=null!==(e=u.dashboard)&&void 0!==e?e:{},h=String(null!==(t=null!==(n=null===(c=u.meta)||void 0===c?void 0:c.folderTitle)&&void 0!==n?n:Tt())&&void 0!==t?t:"").trim(),g=Vt(Array.isArray(p.panels)?p.panels:[]).find(e=>{var t;return Number(null!==(t=e.id)&&void 0!==t?t:-1)===a});if(!g)return null;const y=yield It(_t(Array.isArray(g.targets)?g.targets:[]));return{source:"saved",dashboardUid:d,folderTitle:h,dashboardTitle:String(null!==(r=null!==(l=p.title)&&void 0!==l?l:Dt())&&void 0!==r?r:d).trim()||d,panelTitle:String(null!==(o=g.title)&&void 0!==o?o:i).trim()||i,targets:y,panelOptions:null!==(s=g.options)&&void 0!==s?s:{}}})()).then(e=>{t||Q({dashboardUid:z,context:e})}).catch(()=>{t||Q({dashboardUid:z,context:null})}),()=>{t=!0}):()=>{t=!0};var a,i},[z,e,q]);const{analyses:ee,effectiveBucketSpanMs:te}=(0,p.useMemo)(()=>je(P,V),[P,V]),[ae,ie]=(0,p.useState)(()=>new Set),[ne,re]=(0,p.useState)(null),[pe,he]=(0,p.useState)(""),[ke,Me]=(0,p.useState)("flagged");(0,p.useEffect)(()=>{if("undefined"==typeof window)return;const e=window.setTimeout(()=>{const e=new Set(ee.map(e=>e.key));ie(t=>{const a=new Set([...t].filter(t=>e.has(t)));return a.size===t.size?t:a}),re(t=>t&&!e.has(t)?null:t)},0);return()=>window.clearTimeout(e)},[ee]);const Le=(0,p.useMemo)(()=>ne?ee.filter(e=>e.key===ne):ee.filter(e=>!ae.has(e.key)),[ee,ae,ne]),Be=(0,p.useMemo)(()=>"multi"===V.detectionMode?((e,t)=>{const a=new Map;return e.forEach(e=>{e.allPoints.forEach(t=>{var i;if(null===t.expected)return;const n=null!==(i=a.get(t.time))&&void 0!==i?i:[];n.push({point:t,label:e.label}),a.set(t.time,n)})}),[...a.entries()].map(([e,a])=>{var i,n,r;const l=[...a].sort((e,t)=>t.point.score-e.point.score),o=l.slice(0,Math.min(3,l.length)).reduce((e,t)=>e+t.point.score,0)/Math.min(3,l.length||1),s=l.reduce((e,t)=>De(e,t.point),{severityLabel:"normal",severityScore:0}),c=l[0],d=l.slice(0,Math.min(3,l.length)).reduce((e,t)=>e+t.point.confidenceScore,0)/Math.min(3,l.length||1),m=d>=80?"high":d>=55?"medium":"low",u=l.reduce((e,t)=>((e,t)=>{const a=["healthy","gappy","thin","flatline"];return a.indexOf(t)>a.indexOf(e)?t:e})(e,t.point.dataQualityLabel),"healthy");return{time:e,bucketStart:null!==(i=null==c?void 0:c.point.bucketStart)&&void 0!==i?i:e,bucketEnd:null!==(n=null==c?void 0:c.point.bucketEnd)&&void 0!==n?n:e,score:o,contributors:l.filter(e=>e.point.isAnomaly).map(e=>e.label).slice(0,4),activeSeries:a.length,isAnomaly:o>=t.sensitivity||l.some(e=>e.point.isAnomaly),decisionState:null!==(r=null==c?void 0:c.point.decisionState)&&void 0!==r?r:"normal",severityLabel:s.severityLabel,severityScore:s.severityScore,confidenceScore:Math.round(10*d)/10,confidenceLabel:m,dataQualityLabel:u}}).sort((e,t)=>e.time-t.time)})(ee,V):[],[ee,V]),_e=(0,p.useMemo)(()=>{var e,t,a,i,n,l;const o=null!==(e=null==r||null===(i=r.from)||void 0===i||null===(a=i.valueOf)||void 0===a?void 0:a.call(i))&&void 0!==e?e:0,s=null!==(t=null==r||null===(l=r.to)||void 0===l||null===(n=l.valueOf)||void 0===n?void 0:n.call(l))&&void 0!==t?t:0;return o>0&&s>o?Math.max(60,Math.round((s-o)/1e3)):0},[r]),Re=(0,p.useMemo)(()=>{var e;const t=a.request,i=Number(null!==(e=null==t?void 0:t.intervalMs)&&void 0!==e?e:0);return Number.isFinite(i)&&i>0?Math.max(1,Math.round(i/1e3)):0},[a]),Ie=Ut({panelId:null!=e?e:0,panelTitle:q,options:t,resolvedOptions:V,liveTargets:Z,savedContext:Y,savedContextReady:K,analyses:ee,timeRangeSeconds:_e,queryStepSeconds:Re}),Ve=(0,p.useMemo)(()=>O.anomalyFeed?Je(ee,Be,V):[],[ee,Be,V,O.anomalyFeed]),[Oe,qe]=(0,p.useState)(null),[at,nt]=(0,p.useState)(null),[ot,mt]=(0,p.useState)(null),[ht,yt]=(0,p.useState)(null),[bt,Et]=(0,p.useState)(!1),[St,Ft]=(0,p.useState)(!1),$t=(0,p.useRef)(null),[Mt,Nt]=(0,p.useState)({width:0,height:0}),Lt=(0,p.useMemo)(()=>{var e,t;return((e,t,a)=>!!e&&("event"===e.kind?a.some(t=>t.time===e.time):t.some(t=>t.key===e.seriesKey&&t.allPoints.some(t=>t.time===e.time))))(Oe,ee,Be)?Oe:null!==(e=null===(t=Ve[0])||void 0===t?void 0:t.selection)&&void 0!==e?e:null},[ee,Be,Oe,Ve]),At=(0,p.useMemo)(()=>[...Ve].sort((e,t)=>e.time-t.time),[Ve]),Ct=Ce(Lt);(0,p.useLayoutEffect)(()=>{const e=$t.current;if(!e)return;let t=0;const a=()=>{"undefined"!=typeof window&&(window.cancelAnimationFrame(t),t=window.requestAnimationFrame(()=>{const t={width:Math.round(e.clientWidth),height:Math.round(e.clientHeight)};Nt(e=>e.width===t.width&&e.height===t.height?e:t)}))};a();let i=null;return"undefined"!=typeof ResizeObserver?(i=new ResizeObserver(()=>{a()}),i.observe(e)):"undefined"!=typeof window&&window.addEventListener("resize",a),()=>{"undefined"!=typeof window&&(window.cancelAnimationFrame(t),window.removeEventListener("resize",a)),null==i||i.disconnect()}},[i,n,O.inspector,O.mainChart]),(0,p.useEffect)(()=>{if(!ht||"undefined"==typeof window)return;const e=window.setTimeout(()=>{yt(null)},3200);return()=>{window.clearTimeout(e)}},[ht]);const Pt=e=>{e&&(qe(e.selection),mt(e.time),nt(e.time))},Rt=(0,p.useMemo)(()=>{var e,t;const a=Ze(Lt,ee,Be);if(a)return a;const i=null!==(e=null!==(t=Ve.find(e=>Ce(e.selection)===Ct))&&void 0!==t?t:Ve[0])&&void 0!==e?e:null;return(n=i)?{kind:"point",title:n.title,subtitle:n.subtitle,seriesKey:Ce(n.selection),seriesLabel:n.title,color:ce[n.severityLabel],time:n.time,bucketStart:n.time,bucketEnd:n.time+1,actual:n.score,expected:null,deviation:null,deviationPercent:null,rangeLower:null,rangeUpper:null,sampleCount:1,minValue:n.score,maxValue:n.score,score:n.score,pointScore:n.score,windowScore:0,scoreDriver:"point",severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel}:null;var n},[Lt,Ct,ee,Be,Ve]),Ot=(0,p.useMemo)(()=>(Le.length>0?Le:ee).flatMap(e=>e.allPoints),[ee,Le]),qt=null!=ot?ot:at,Wt=(0,p.useMemo)(()=>((e,t,a)=>{var i;if(null===e)return null;const n=t.map(t=>{const a=t.allPoints.find(t=>t.time===e);return a?{key:t.key,label:t.label,color:t.color,actual:a.value,expected:a.expected,score:a.score,isAnomaly:a.isAnomaly,decisionState:a.decisionState,severityLabel:a.severityLabel,severityScore:a.severityScore,confidenceScore:a.confidenceScore,confidenceLabel:a.confidenceLabel,dataQualityLabel:a.dataQualityLabel}:null}).filter(e=>null!==e).sort((e,t)=>t.score-e.score);if(0===n.length)return null;const r=null!==(i=a.find(t=>t.time===e))&&void 0!==i?i:null,l=r?{severityLabel:r.severityLabel,severityScore:r.severityScore}:n.reduce((e,t)=>De(e,t),{severityLabel:"normal",severityScore:0});return{time:e,event:r,series:n,anomalyCount:n.filter(e=>e.isAnomaly).length+((null==r?void 0:r.isAnomaly)?1:0),severityLabel:l.severityLabel,severityScore:l.severityScore}})(qt,Le,Be),[qt,Le,Be]),zt=((e,t)=>{switch(e){case"synced":return t?"#34D399":"#047857";case"syncing":return t?"#FBBF24":"#B45309";case"error":return t?"#F87171":"#B91C1C";case"unsupported":return t?"#F59E0B":"#B45309";case"off":return t?"#94A3B8":"#64748B";default:return t?"#60A5FA":"#1D4ED8"}})(Ie.kind,N.isDark),Ht=lt(Ie.registered),Qt=st(null!==(o=null===(b=Ie.registered[0])||void 0===b?void 0:b.target)&&void 0!==o?o:t.scoreFeedTarget),Gt="error"===Ie.kind?"Error":"syncing"===Ie.kind?"Syncing":"synced"===Ie.kind?"Up":"Ready",Yt="Up"===Gt?"#22C55E":"Syncing"===Gt?"#60A5FA":"Error"===Gt?"#EF4444":"#F59E0B",Kt="Up"===Gt?(Jt=Ie.lastSyncedAt)?new Date(Jt).toLocaleString():"Not synced yet":"Syncing"===Gt?"Publishing":"Error"===Gt?"Check exporter":"Selected target";var Jt;const Zt="synced"===Ie.kind?`${wt(Qt)} healthy`:jt(Ie.kind),Xt="off"!==t.scoreFeedMode?h().createElement("div",{className:`${L.card} ${L.scoreFeedCard}`},h().createElement("div",{style:{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12,flexWrap:"wrap"}},h().createElement("div",{style:{minWidth:0,flex:"1 1 320px"}},h().createElement("div",{className:L.cardTitle},"Anomaly score feed"),h().createElement("div",{className:L.subtitle},Ie.message)),h().createElement("div",{style:{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}},h().createElement("span",{className:L.recommendationBadge,style:{background:`${zt}22`,color:zt}},Zt),h().createElement("button",{type:"button",onClick:()=>{Ie.syncNow()},disabled:"syncing"===Ie.kind,style:{border:"1px solid "+(N.isDark?"#1D4ED8":"#93C5FD"),background:N.isDark?"#172554":"#EFF6FF",color:N.isDark?"#DBEAFE":"#1D4ED8",borderRadius:999,padding:"8px 14px",fontSize:12,fontWeight:700,cursor:"syncing"===Ie.kind?"wait":"pointer",opacity:"syncing"===Ie.kind?.72:1}},"syncing"===Ie.kind?"Syncing...":"Sync score feed"))),h().createElement("div",{className:L.scoreFeedTargetGrid,"aria-label":"Score feed target health"},h().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},h().createElement("span",{"aria-hidden":"true",style:{width:10,height:10,borderRadius:999,background:Yt,boxShadow:`0 0 0 4px ${Yt}1f`}}),h().createElement("div",{className:L.healthChipText},h().createElement("span",{className:L.healthChipLabel},"Status"),h().createElement("span",{className:L.healthChipValue},jt(Ie.kind)))),h().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},h().createElement("div",{className:L.healthChipText},h().createElement("span",{className:L.healthChipLabel},"Mode"),h().createElement("span",{className:L.healthChipValue},ft[null!==(s=t.scoreFeedMode)&&void 0!==s?s:"auto"]))),h().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},h().createElement("div",{className:L.scoreFeedTargetTop},h().createElement("span",{className:L.scoreFeedTargetIcon,style:{color:(ea=Qt,xt[st(ea)])}},kt(Qt)),h().createElement("div",{className:L.healthChipText},h().createElement("span",{className:L.scoreFeedTargetTitle},wt(Qt)),h().createElement("span",{className:L.scoreFeedTargetMeta},"Score target")))),h().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},h().createElement("div",{className:L.healthChipText},h().createElement("span",{className:L.healthChipLabel},"Last sync"),h().createElement("span",{className:L.healthChipValue},Kt))),h().createElement("div",{className:`${L.healthChip} ${L.healthChipCompact}`},h().createElement("div",{className:L.healthChipText},h().createElement("span",{className:L.healthChipLabel},"Feed series"),h().createElement("span",{className:L.healthChipValue},Ie.registered.length>0?Ie.registered.length:"Waiting")))),Ie.registered.length>0?h().createElement(h().Fragment,null,h().createElement("div",{className:L.subtitle},"Published score feed records are ready for alerting from the selected target. Queries below match the store selected in Score feed target."),h().createElement("div",{className:L.actionRow},h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>Et(e=>!e)},bt?"Hide synced rules":"Show synced rules")),bt?h().createElement("div",{className:L.feedRuleList},Ie.registered.map(e=>{var t,a,i;return h().createElement("div",{key:e.rule,className:L.feedRuleCard},h().createElement("div",{className:L.handoffHeader},h().createElement("div",{style:{minWidth:0,flex:"1 1 180px"}},h().createElement("div",{className:L.summaryTitle},e.rule),h().createElement("div",{className:L.subtitle},"Alert rule query")),h().createElement("span",{className:L.targetBadge,title:ct(e)},h().createElement("span",{className:L.targetIcon},kt(null!==(t=e.target)&&void 0!==t?t:"prometheus")),h().createElement("span",{className:L.targetText},h().createElement("span",{className:L.targetName},wt(null!==(a=e.target)&&void 0!==a?a:"prometheus")),h().createElement("span",{className:L.targetLanguage},null!==(i=e.queryLanguage)&&void 0!==i?i:Ht)))),h().createElement("div",{className:L.codeLine},e.query),h().createElement("div",{className:L.subtitle},"Per-series drilldown query"),h().createElement("div",{className:L.codeLine},e.perSeriesQuery),e.activeQuery?h().createElement(h().Fragment,null,h().createElement("div",{className:L.subtitle},"Incident lifecycle query (open or recovering)"),h().createElement("div",{className:L.codeLine},e.activeQuery)):null,e.queryVariants&&e.queryVariants.length>0?h().createElement("div",{className:L.feedRuleList},e.queryVariants.map(t=>h().createElement("div",{key:`${e.rule}-${t.target}-${t.queryLanguage}`,className:L.feedRuleCard},h().createElement("div",{className:L.handoffHeader},h().createElement("div",{className:L.subtitle},"Variant query"),h().createElement("span",{className:L.targetBadge,title:ct(t)},h().createElement("span",{className:L.targetIcon},kt(t.target)),h().createElement("span",{className:L.targetText},h().createElement("span",{className:L.targetName},wt(t.target)),h().createElement("span",{className:L.targetLanguage},t.queryLanguage)))),h().createElement("div",{className:L.codeLine},t.query),t.activeQuery?h().createElement("div",{className:L.codeLine},t.activeQuery):null,h().createElement("div",{className:L.codeLine},t.perSeriesQuery),h().createElement("div",{className:L.actionRow},h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{pt(t.query).then(()=>yt({tone:"success",message:`Copied ${ct(t)} query for ${e.rule}.`})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the target query."}))}},"Copy variant query"))))):null,h().createElement("div",{className:L.actionRow},h().createElement("button",{type:"button",className:L.actionButton,onClick:()=>{pt(e.query).then(()=>yt({tone:"success",message:`Copied alert query for ${e.rule}.`})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."}))}},"Copy alert query"),h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{pt(e.perSeriesQuery).then(()=>yt({tone:"success",message:`Copied per-series query for ${e.rule}.`})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the per-series query."}))}},"Copy series query")))})):null):null):null;var ea;if(R)return h().createElement("div",{className:L.wrapper},h().createElement("div",{className:L.skeletonShell,"aria-label":"Anomaly detector is loading"},h().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonHeader}`}),h().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonChart}`}),h().createElement("div",{className:L.skeletonRows},h().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonRow}`}),h().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonRow}`}),h().createElement("div",{className:`${L.skeletonBlock} ${L.skeletonRow}`}))));if(0===P.length||0===Ot.length)return h().createElement("div",{className:L.wrapper},O.scoreFeed?Xt:null,h().createElement("div",{className:L.emptyState},"Add a time series query with at least one numeric field to start anomaly analysis."));const ta=ee.length,aa="multi"===V.detectionMode?Be.filter(e=>e.isAnomaly).length:ee.reduce((e,t)=>e+t.anomalyCount,0),ia="multi"===V.detectionMode?Be.map(e=>e.severityScore):ee.map(e=>e.maxSeverityScore),na=Math.max(...ia,0),ra=ee.reduce((e,t)=>De(e,{severityLabel:t.maxSeverityLabel,severityScore:t.maxSeverityScore}),{severityLabel:"normal",severityScore:0}),la=Ot.map(e=>e.time),oa=[...new Set(la)].sort((e,t)=>e-t),sa=Ot.flatMap(e=>[e.value,e.expected,e.lower,e.upper]).filter(e=>null!==e&&Number.isFinite(e)),ca=Math.min(...la),da=Math.max(...la),ma=Math.max(da-ca,1),ua=Math.max((null!==(d=null===(w=r.to)||void 0===w||null===(x=w.valueOf)||void 0===x?void 0:x.call(w))&&void 0!==d?d:da)-(null!==(m=null===(k=r.from)||void 0===k||null===(E=k.valueOf)||void 0===E?void 0:E.call(k))&&void 0!==m?m:ca),1),pa=Math.max(ma,ua),ha=((e,t)=>{const a=e.filter(Number.isFinite),i=t.filter(Number.isFinite);if(0===a.length)return{min:0,max:1};const n=Math.min(...a),r=Math.max(...a),l=Math.max(.12*(r-n),.03*Math.abs(r),1);return{min:i.length>0&&i.every(e=>e>=0)?Math.max(0,n-l):n-l,max:r+l}})(sa,Ot.map(e=>e.value).filter(Number.isFinite)),ga=ha.min,ya=ha.max,fa=(0,c.timeZoneAbbrevation)(da,{timeZone:l})||("string"==typeof l?l:"local"),va=ce[ra.severityLabel],ba=O.initialLabels||O.statistics,xa=O.detectionProfile||O.exports,wa=O.anomalyFeed||xa,Ea=O.seriesSummary||O.scoreFeed&&Boolean(Xt),ka=O.mainChart&&!ba&&!O.anomalyFeed&&!Ea&&!xa&&!O.inspector,Sa=Math.max(i-24,320),Fa=ka?Math.max(n-20,220):Math.max(Math.min(wa?.54*n:n-72,500),340),$a=Mt.width>0?Math.max(Mt.width,260):Sa,Ma=Mt.height>0?Math.max(Mt.height,220):Fa,Na=U(j({},G),{top:Ma<280?18:24,right:"multi"===V.detectionMode?28:24,bottom:Ma<280?42:54,left:"multi"===V.detectionMode?$a<720?80:92:$a<720?72:84}),La=Math.max($a-Na.left-Na.right,40),Aa=Math.max(Ma-Na.top-Na.bottom,40),Ca=e=>da===ca?Na.left+La/2:Na.left+(e-ca)/(da-ca)*La,Ba=e=>ya===ga?Na.top+Aa/2:Na.top+Aa-(e-ga)/(ya-ga)*Aa,Da=((e,t,a,i)=>{const n=Ee(a,i),r="multi"===t?e/235:e/205,l="compact"===n?.76:"dense"===n?1.35:1,o=Math.round(r*l),s="dense"===n?5:4,c="dense"===n?10:"compact"===n?7:8;return Math.max(s,Math.min(c,o))})($a,V.detectionMode,V.timeAxisDensity,pa),Ta=Math.max(5,Math.min(6,Math.round(Aa/72))),Pa=Qe(ca,da,Da),_a="top_and_bottom"===V.timeAxisPlacement?Pa.filter((e,t)=>0===t||t===Pa.length-1||t%Math.max(1,Math.ceil(Pa.length/3))===0):[],Ra=Qe(ga,ya,Ta),Ia=Math.max(64,La/10),Va="multi"===V.detectionMode?Ke(Ge(Be.filter(e=>e.isAnomaly),Ca,Ia,"event"===(null==Lt?void 0:Lt.kind)?Lt.time:null),8,"event"===(null==Lt?void 0:Lt.kind)?Lt.time:null):[],Oa=V.showFocusBand?((e,t,a)=>{if(!e||a.length<2)return null;const i=Ye(a,e.time);if(i<0)return null;const n=Math.max(3,Math.min(5,Math.floor(a.length/10)||3)),r=Math.max(0,i-n),l=Math.min(a.length-1,i+n),o=a[r],s=a[l];if(s<=o)return null;const c=t.map(e=>({key:e.key,label:e.label,color:e.color,points:e.allPoints.filter(e=>e.time>=o&&e.time<=s)})).filter(e=>e.points.length>0);if(0===c.length)return null;const d=c.flatMap(e=>e.points.flatMap(e=>[e.value,e.expected].filter(e=>null!==e&&Number.isFinite(e))));return 0===d.length?null:{startTime:o,endTime:s,selectedTime:e.time,bucketStart:e.bucketStart,bucketEnd:e.bucketEnd,title:"event"===e.kind?"Focused incident window":`Focused view for ${e.seriesLabel}`,series:c,minValue:Math.min(...d),maxValue:Math.max(...d)}})(Rt,Le,oa):null,qa=((e,t,a,i)=>{const n=i.length>=2?ge(i.slice(1).map((e,t)=>Math.max(e-i[t],1))):6e4,r=Math.max(1.25*n,3e4),l="multi"===a?t.filter(e=>e.isAnomaly).map(e=>({start:e.bucketStart,end:Math.max(e.bucketEnd,e.time),center:e.time,severityLabel:e.severityLabel,severityScore:e.severityScore,selection:{kind:"event",time:e.time}})):e.flatMap(e=>e.allPoints.filter(e=>e.isAnomaly).map(t=>({start:t.bucketStart,end:Math.max(t.bucketEnd,t.time),center:t.time,severityLabel:t.severityLabel,severityScore:t.severityScore,selection:{kind:"point",seriesKey:e.key,time:t.time}})));if(0===l.length)return[];l.sort((e,t)=>e.start-t.start);const o=[];let s=[l[0]];const c=()=>{if(0===s.length)return;const e=s.reduce((e,t)=>De(e,t)===e?e:t,s[0]),t=Math.min(...s.map(e=>e.start)),a=Math.max(...s.map(e=>e.end));o.push({key:`ribbon-${t}-${a}-${o.length}`,start:t,end:a,center:e.center,count:s.length,label:1===s.length?"1 incident":`${s.length} incidents`,severityLabel:e.severityLabel,severityScore:e.severityScore,selection:e.selection}),s=[]};for(let e=1;e<l.length;e+=1){const t=l[e],a=s[s.length-1];t.start<=a.end+r?s.push(t):(c(),s=[t])}return c(),o})(Le,Be,V.detectionMode,oa),Wa=Oa?Math.max(54,Math.min(76,.2*Aa)):0,za=Oa?Na.top+Aa-Wa-10:Na.top+Aa,ja=Oa?za-8:Na.top+Aa,Ua=Le.length>8,Ha=Ua?[]:Le.length>4?[...Le].sort((e,t)=>t.maxSeverityScore-e.maxSeverityScore||t.anomalyCount-e.anomalyCount||e.label.localeCompare(t.label)).slice(0,4):Le,Qa=V.showInlineSeriesLabels&&!Ua?((e,t,a,i,n,r)=>{const l=e.map(e=>{const i=[...e.points].reverse().find(e=>Number.isFinite(e.value));if(!i)return null;const n=we(`${e.label} • ${ye(i.value)}`,28);return{key:e.key,label:n,color:e.color,targetY:a(i.value),labelY:a(i.value),anchorX:r,lastX:t(i.time),lastY:a(i.value),width:Math.max(84,Math.min(168,6.6*n.length+18)),value:i.value}}).filter(e=>null!==e).sort((e,t)=>e.targetY-t.targetY);if(0===l.length)return[];let o=i+14;for(const e of l)e.labelY=Math.max(e.targetY,o),o=e.labelY+20;o=n-12;for(let e=l.length-1;e>=0;e-=1){const t=l[e];t.labelY=Math.min(t.labelY,o),o=t.labelY-20}return l.map(e=>U(j({},e),{labelY:Math.max(i+14,Math.min(n-12,e.labelY))}))})(Ha,Ca,Ba,Na.top+12,ja-10,$a-Na.right-10):[],Ga=Ue(V.bucketSpan,te),Ya=((e,t)=>{const a=Ue(e.bucketSpan,t),i="custom"===e.effectiveMetricPreset?"Custom profile is active.":`${X[e.effectiveMetricPreset]} profile is active.`,n="level_shift"===e.algorithm?`It focuses on sustained baseline shifts over the last ${e.baselineWindow} buckets.`:"seasonal"===e.algorithm?`It compares each point with similar historical positions using ${le[e.seasonalRefinement].toLowerCase()} refinement and ${e.seasonalitySamples} seasonal samples.`:"ewma"===e.algorithm?`It keeps a moving baseline over ${e.baselineWindow} buckets and reacts when the live metric keeps pulling away from that baseline.`:"mad"===e.algorithm?`It uses a robust median-based spread over ${e.baselineWindow} buckets so noisy data does not create too many false alarms.`:`It compares each point with a rolling average over ${e.baselineWindow} buckets.`,r=t?`Dense data is first summarized into ${a} buckets so the panel stays fast.`:"Incoming samples are scored directly for maximum detail.",l="high_mean"===e.anomalyDirection?"Only values above the learned mean may become anomalies.":"low_mean"===e.anomalyDirection?"Only values below the learned mean may become anomalies.":"Both upward and downward deviations may become anomalies.",o=e.recoveryThreshold>0?e.recoveryThreshold:e.sensitivity;return`${i} ${n} ${l} ${e.persistenceBuckets} of the latest ${e.persistenceWindow} buckets open an incident. It closes after ${e.recoveryBuckets} consecutive buckets below ${o.toFixed(2)} and then waits ${e.cooldownBuckets} cooldown buckets. Current threshold is ${e.sensitivity.toFixed(2)}. ${r}`})(V,te),Ka=Rt?((e,t)=>{const a=de[e.confidenceLabel].replace("confidence","signal confidence"),i=ue[e.dataQualityLabel].toLowerCase();if("event"===e.kind)return`${e.activeSeries} metric agreed on this combined anomaly. Strongest reason: ${e.breakdown[0]?Te(e.breakdown[0].scoreDriver,t):"Cross-metric deviation"}. ${a}, data quality is ${i}.`;const n=Te(e.scoreDriver,t),r=null===e.deviation?"moved away from baseline":e.deviation>0?"moved above its baseline":e.deviation<0?"fell below its baseline":"stayed close to its baseline";return`${e.seriesLabel} ${r}. Main reason: ${n}. ${a}, data quality is ${i}.`})(Rt,V.algorithm):"",Ja=((e,t)=>JSON.stringify(e.map(e=>({time:e.time,text:e.title,tags:Xe(["anomaly-detector",e.severityLabel,e.confidenceLabel,e.dataQualityLabel,t]),detail:e.detail,raw_score:e.score,alarm_score_0_100:e.severityScore,alarm_severity:e.severityLabel,confidence_score:e.confidenceScore,confidence_label:e.confidenceLabel,data_quality:e.dataQualityLabel})),null,2))(Ve,Ga),Za=rt(Ie.registered),Xa=et(V.severityPreset),ei=(null==Y?void 0:Y.folderTitle)||Tt(),ti=(null==Y?void 0:Y.panelTitle)||q,ai=(null==Y?void 0:Y.dashboardTitle)||Dt()||"Grafana dashboard",ii=st(null!==(u=null===(S=Ie.registered[0])||void 0===S?void 0:S.target)&&void 0!==u?u:t.scoreFeedTarget),ni=((e,t,a)=>{const i=e.trim();let n=t.trim();return i&&n.toLowerCase().endsWith(` - ${i}`.toLowerCase())&&(n=n.slice(0,n.length-i.length-3).trim()),[i,n,a.trim()].filter((e,t,a)=>e.length>0&&a.findIndex(t=>t===e)===t).join(" - ")})(ei,ai,ti)||ti,ri=((e,t,a)=>({alert_family:"anomaly_detector",severity:"major",dashboard_uid:e||"unsaved_dashboard",panel_id:t>0?String(t):"unknown_panel",score_target:st(a)}))(z,null!=e?e:0,ii),li=(si={dashboardUid:z,folderTitle:ei,dashboardTitle:ai,panelId:null!=e?e:0,panelTitle:ti,ruleName:ni},{summary:(oi=Rt)?oi.title:si.ruleName,description:dt(oi,si.panelTitle),folder_title:null!==(ci=si.folderTitle)&&void 0!==ci?ci:"",dashboard_title:si.dashboardTitle,panel_title:si.panelTitle,__dashboardUid__:si.dashboardUid,__panelId__:si.panelId>0?String(si.panelId):""});var oi,si,ci;const di={dashboardUid:z,folderTitle:ei,dashboardTitle:ai,panelId:null!=e?e:0,panelTitle:ti,ruleName:ni,queryLanguage:Ht,alertQuery:Za,threshold:Xa,target:ii,labels:ri,annotations:li},mi=tt(ri),ui=((e,t,a,i,n)=>{var r;const l=et(t.severityPreset),o=rt(i),s=lt(i);return JSON.stringify({title:n.ruleName,folder_name:null!==(r=n.folderTitle)&&void 0!==r?r:"",dashboard_name:n.dashboardTitle,dashboard_uid:n.dashboardUid,panel_title:n.panelTitle,panel_id:n.panelId,score_feed_ready:i.length>0,paste_into:`Grafana Alerting query editor (${s})`,query_language:s,alert_query:o||"Sync anomaly score feed first to generate an alert-ready score query.",grafana_condition:o?`WHEN QUERY IS ABOVE ${l}`:"Sync anomaly score feed first",for:"10m",evaluate_every:"3m",no_data_state:"Alerting",exec_err_state:"Error",threshold:l,suggested_labels:n.labels,suggested_label_pairs:tt(n.labels),suggested_annotations:n.annotations,synced_rules:i.map(e=>{var t,a,i,n;return{rule:e.rule,target:null!==(t=e.target)&&void 0!==t?t:"prometheus",query_language:null!==(a=e.queryLanguage)&&void 0!==a?a:s,datasource_type:null!==(i=e.datasourceType)&&void 0!==i?i:"",query:e.query,per_series_query:e.perSeriesQuery,query_variants:null!==(n=e.queryVariants)&&void 0!==n?n:[]}}),rule_scope:i.length>1?"Combined max across synced panel rules":"Single synced panel rule",mode:t.detectionMode,algorithm:t.algorithm,bucket_span:a,history_window:t.baselineWindow,severity_preset:t.severityPreset,selected_severity:e?e.severityLabel:"normal",selected_score:e?e.score:0,selected_raw_score:e?e.score:0,selected_alarm_score_0_100:e?e.severityScore:0,selected_alarm_severity:e?e.severityLabel:"normal",score_scale_note:"Alert queries use the normalized 0-100 alarm score, not the raw detection score.",selected_confidence:e?e.confidenceLabel:"low",selected_confidence_score:e?e.confidenceScore:0,selected_data_quality:e?e.dataQualityLabel:"thin",guidance:e?Pe(e,t.severityPreset):"Select an anomaly to generate a focused alert draft."},null,2)})(Rt,V,Ga,Ie.registered,di),pi=ut(Rt,null!=e?e:0,z,Ga),hi=pi?JSON.stringify(pi,null,2):"",gi=Rt?Math.max(1,Ve.findIndex(e=>Ce(e.selection)===Ct)+1):0,yi="point"===(null==Rt?void 0:Rt.kind)?Rt.seriesLabel:"event"===(null==Rt?void 0:Rt.kind)?Rt.contributors.slice(0,2).join(", ")||`${Rt.activeSeries} active series`:null!==(f=null===(F=ee[0])||void 0===F?void 0:F.label)&&void 0!==f?f:"n/a",fi="point"===(null==Rt?void 0:Rt.kind)?ye(Rt.actual):"event"===(null==Rt?void 0:Rt.kind)?`${Rt.activeSeries} active`:"n/a",vi="point"===(null==Rt?void 0:Rt.kind)?ye(Rt.expected):"event"===(null==Rt?void 0:Rt.kind)?`${Rt.breakdown.length} contributors`:"n/a",bi="point"===(null==Rt?void 0:Rt.kind)?null!==Rt.deviationPercent?ve(Rt.deviationPercent):ye(Rt.deviation):"event"===(null==Rt?void 0:Rt.kind)?ye(Rt.score):"n/a",xi=Rt?ye(Rt.score):"n/a",wi=Rt?`${se[Rt.severityLabel]} ${Rt.severityScore}`:"n/a",Ei=Rt?de[Rt.confidenceLabel]:"n/a",ki=Rt?fe(Rt.confidenceScore):"n/a",Si=Rt?"healthy"===Rt.dataQualityLabel?"Good":ue[Rt.dataQualityLabel].replace(" data",""):"n/a",Fi=Rt?fe(Rt.confidenceScore):"n/a",$i=(null===($=Z[0])||void 0===$?void 0:$.datasourceType)?Z[0].datasourceType.charAt(0).toUpperCase()+Z[0].datasourceType.slice(1):vt[st(t.scoreFeedTarget)],Mi=pe.trim().toLocaleLowerCase(),Ni=[...ee].filter(e=>!Mi||e.label.toLocaleLowerCase().includes(Mi)).sort((e,t)=>{if("name"===ke)return e.label.localeCompare(t.label);if("score"===ke)return t.maxSeverityScore-e.maxSeverityScore||t.anomalyCount-e.anomalyCount;if("last"===ke){var a,i,n,r;const l=null!==(a=null===(n=e.allPoints[e.allPoints.length-1])||void 0===n?void 0:n.value)&&void 0!==a?a:Number.NEGATIVE_INFINITY;return(null!==(i=null===(r=t.allPoints[t.allPoints.length-1])||void 0===r?void 0:r.value)&&void 0!==i?i:Number.NEGATIVE_INFINITY)-l||e.label.localeCompare(t.label)}return t.anomalyCount-e.anomalyCount||t.maxSeverityScore-e.maxSeverityScore||e.label.localeCompare(t.label)}),Li=Rt?{x:Ca(Rt.bucketStart),height:Math.max(24,ja-Na.top),width:Rt.bucketEnd>Rt.bucketStart?Math.max(Ca(Rt.bucketEnd)-Ca(Rt.bucketStart),10):12}:null,Ai=Va.map(e=>{const t=Ca(e.bucketStart),a=(e.bucketEnd>e.bucketStart?Ca(e.bucketEnd):t)-t,i=Math.max(10,Math.min(La/80,20)),n=Math.max(10,Math.min(Number.isFinite(a)&&a>0?a:i,24)),r=a>0?t:Ca(e.time)-n/2,l=Math.max(Na.left+2,Math.min(r,$a-Na.right-n-2));return{event:e,x:l,width:n,centerX:l+n/2}}),Ci=`anomaly-plot-${null!=e?e:"panel"}-${V.detectionMode}`,Bi=N.isDark?"#CBD5E1":"#334155",Di=N.isDark?"#0B1628":"#F8FAFC",Ti=N.isDark?"#0F1C2D":"#FFFFFF",Pi=Wt?Ca(Wt.time):null,_i=null===Pi?0:Math.max(16,Math.min(Pi+18,$a-290)),Ri=null!==Pi&&Pi>.62*$a,Ii=null===Pi?void 0:{left:Ri?void 0:_i,right:Ri?Math.max(14,$a-Pi+14):void 0},Vi=h().createElement("aside",{className:L.inspectorCard,"aria-label":"Anomaly inspector"},h().createElement("div",{className:L.inspectorTop},h().createElement("div",{className:L.inspectorTitle},"Anomaly inspector"),h().createElement("button",{type:"button",className:L.inspectorClose,"aria-label":"Inspector is pinned in this panel"},"x")),Rt?h().createElement(h().Fragment,null,h().createElement("div",{className:L.inspectorTimestamp},h().createElement("span",null,Fe(Rt.time,pa,l)),h().createElement("span",{"aria-hidden":"true"},"•"),h().createElement("span",{style:{color:ce[Rt.severityLabel]}},se[Rt.severityLabel])),h().createElement("div",{className:L.inspectorRows},h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Series"),h().createElement("span",{className:L.inspectorRowValue},we(yi,34))),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Value"),h().createElement("span",{className:L.inspectorRowValue},fi)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Expected"),h().createElement("span",{className:L.inspectorRowValue},vi)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Deviation"),h().createElement("span",{className:L.inspectorRowValue},bi)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Raw detection score"),h().createElement("span",{className:L.inspectorRowValue},xi)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Alert score (0-100)"),h().createElement("span",{className:L.inspectorRowValue,style:{color:ce[Rt.severityLabel]}},wi)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Bucket"),h().createElement("span",{className:L.inspectorRowValue},Ga)),h().createElement("div",{className:L.inspectorRow},h().createElement("span",{className:L.inspectorRowLabel},"Incident"),h().createElement("span",{className:L.inspectorRowValue},gi," of ",Math.max(Ve.length,gi)))),h().createElement("div",null,h().createElement("div",{className:L.inspectorSectionTitle},"Why is this anomalous?"),h().createElement("div",{className:L.recommendationText,style:{marginTop:10}},Ka)),h().createElement("div",{className:L.inspectorRows},h().createElement("div",{className:L.inspectorHealthRow},h().createElement("span",{className:L.inspectorRowLabel},"Confidence"),h().createElement("span",null,h().createElement("span",{className:L.inspectorPill,style:{background:`${me[Rt.confidenceLabel]}33`,color:me[Rt.confidenceLabel]}},Ei),h().createElement("span",{className:L.inspectorRowValue,style:{marginLeft:10}},ki,"%"))),h().createElement("div",{className:L.inspectorHealthRow},h().createElement("span",{className:L.inspectorRowLabel},"Data quality"),h().createElement("span",null,h().createElement("span",{className:L.inspectorPill,style:{background:"rgba(34,197,94,0.24)",color:"#86EFAC"}},Si),h().createElement("span",{className:L.inspectorRowValue,style:{marginLeft:10}},Fi,"%")))),h().createElement("div",null,h().createElement("div",{className:L.inspectorSectionTitle},"Rule labels"),h().createElement("div",{className:L.labelChipGrid,style:{marginTop:10}},Object.entries(ri).map(([e,t])=>h().createElement("span",{key:e,className:L.labelChip,title:`${e}=${t}`},h().createElement("span",{className:L.labelChipKey},e),h().createElement("span",null,"="),h().createElement("span",{className:L.labelChipValue},t))))),h().createElement("div",{className:L.inspectorActionStack},h().createElement("button",{type:"button",className:`${L.actionButton} ${L.inspectorActionButton} ${L.inspectorActionButtonPrimary}`,disabled:!Za,onClick:()=>{if(!Za)return void yt({tone:"error",message:"Sync anomaly score feed first to generate the alert query."});const e=it(di);yt({tone:"success",message:e?"Opened Grafana alert rule builder. Copying the alert query to your clipboard.":"Copying the alert query. If the builder did not open, use Alerting > Alert rules > New alert rule."}),pt(Za).then(()=>yt({tone:"success",message:e?"Opened Grafana alert rule builder and copied the alert query.":"Copied the alert query. If the builder did not open, use Alerting > Alert rules > New alert rule."})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."}))}},"Open alert rule builder"),h().createElement("button",{type:"button",className:`${L.actionButtonSecondary} ${L.inspectorActionButton} ${L.inspectorActionButtonSecondary}`,disabled:!mi,onClick:()=>{pt(mi).then(()=>yt({tone:"success",message:"Copied suggested alert labels."})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to copy alert labels."}))}},"Copy rule labels"),h().createElement("button",{type:"button",className:`${L.actionButtonSecondary} ${L.inspectorActionButton} ${L.inspectorActionButtonSecondary}`,disabled:!pi||!z,onClick:()=>{pi?z?gt(pi).then(()=>yt({tone:"success",message:"Created a Grafana annotation for the selected anomaly."})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to create the Grafana annotation."})):yt({tone:"error",message:"Save the dashboard once before creating Grafana annotations from the panel."}):yt({tone:"error",message:"Select an anomaly first to create an annotation."})}},"Create annotation"),h().createElement("button",{type:"button",className:`${L.actionButtonSecondary} ${L.inspectorActionButton} ${L.inspectorActionButtonSecondary}`,disabled:!Za,onClick:()=>{Za?pt(Za).then(()=>yt({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):yt({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy alert query")),h().createElement("div",null,h().createElement("div",{className:L.inspectorSectionTitle},"Query preview"),h().createElement("pre",{className:L.queryPreview},Za||`Sync the score feed to generate ${Ht}.`))):h().createElement("div",{className:L.subtitle},"Select a detected incident to see why it was flagged, how strong the signal is, and whether it is ready for alerting."));return h().createElement("div",{className:L.wrapper},h().createElement("div",{className:L.operationalCanvas,style:{gridTemplateColumns:O.inspector?void 0:"minmax(0, 1fr)"}},h().createElement("main",{className:L.workspacePane},ba?h().createElement("div",{className:L.statusHeader,style:{gridTemplateColumns:O.initialLabels&&O.statistics?void 0:"minmax(0, 1fr)"}},O.initialLabels?h().createElement(h().Fragment,null,h().createElement("div",{className:L.statusRail,style:{background:va}}),h().createElement("div",{className:L.statusIcon,"aria-hidden":"true"},h().createElement("svg",{className:L.statusIconSvg,viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},h().createElement("path",{d:"M2.5 12h4.1l2.1-5.7 3.9 11.4 2.1-5.7h6.8",fill:"none",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"}),h().createElement("circle",{cx:"12",cy:"12",r:"10",fill:"none",stroke:"currentColor",strokeOpacity:"0.28",strokeWidth:"1.4"}))),h().createElement("div",{className:L.statusMain},h().createElement("div",{className:L.title,role:"heading","aria-level":2},"Anomaly Detector"),h().createElement("div",{className:L.headerMetaGrid},h().createElement("span",null,"Algorithm: ",h().createElement("span",{className:L.metaAccent},V.algorithm)),h().createElement("span",null,"Direction: ",h().createElement("span",{className:L.metaAccent},V.anomalyDirection.replaceAll("_"," "))),h().createElement("span",null,"Bucket: ",Ga),h().createElement("span",null,"Series: ",we(yi,34)),h().createElement("span",null,"Datasource: ",$i)),_?h().createElement("div",{className:L.staleBanner},"Showing the last good snapshot while Grafana refreshes the query result."):null)):null,O.statistics?h().createElement("div",{className:L.statusStats},h().createElement("div",{className:`${L.statCard} ${L.statCardPrimary}`,style:{borderColor:`${va}99`,background:`linear-gradient(145deg, ${va}E6 0%, ${va}88 100%)`}},h().createElement("div",{className:L.statLabel},"Severity"),h().createElement("div",{className:L.statValue},se[ra.severityLabel]),h().createElement("div",{className:L.statCaption},Rt?`Since ${Fe(Rt.time,pa,l)}`:`Peak ${fe(na)}`)),h().createElement("div",{className:L.statCard},h().createElement("div",{className:L.statLabel},"Confidence"),h().createElement("div",{className:L.statValue},ki,"%"),h().createElement("div",{className:L.statCaption},Ei)),h().createElement("div",{className:L.statCard,role:"status","aria-live":"polite","aria-atomic":"true"},h().createElement("div",{className:L.statLabel},"Anomalies"),h().createElement("div",{className:L.statValue},aa),h().createElement("div",{className:L.statCaption},"clustered")),h().createElement("div",{className:L.statCard},h().createElement("div",{className:L.statLabel},"Data quality"),h().createElement("div",{className:L.statValue,style:{color:"#4ADE80"}},Si),h().createElement("div",{className:L.statCaption},Fi,"%"))):null):null,O.initialLabels?h().createElement("div",{className:L.recommendationBanner},h().createElement("div",{className:L.recommendationBadge},V.recommendation.badge),h().createElement("div",{className:L.recommendationCopy},h().createElement("div",{className:L.recommendationTitle},V.recommendation.title),h().createElement("div",{className:L.recommendationText},V.recommendation.reason,V.recommendation.matchedNames.length>0?` Matched metrics: ${V.recommendation.matchedNames.slice(0,3).join(", ")}.`:""))):null,ht?h().createElement("div",{className:L.actionNotice},h().createElement("span",{className:L.recommendationBadge,style:{background:"success"===ht.tone?`${ce.low}22`:`${ce.critical}22`,color:"success"===ht.tone?ce.low:ce.critical}},"success"===ht.tone?"Action complete":"Action needed"),h().createElement("div",{className:L.recommendationCopy},h().createElement("div",{className:L.recommendationTitle},"success"===ht.tone?"Ready to continue":"Could not finish action"),h().createElement("div",{className:L.recommendationText},ht.message))):null,O.anomalyFeed?h().createElement(h().Fragment,null,h().createElement("div",{className:L.incidentHeader},h().createElement("div",{className:L.cardTitle,role:"heading","aria-level":3},"Detected incidents"),h().createElement("div",{className:L.severityLegend,"aria-label":"Incident severity legend"},["critical","high","medium","low"].map(e=>h().createElement("span",{key:e,className:L.severityLegendItem},h().createElement("span",{className:L.severityLegendSwatch,style:{background:ce[e]}}),se[e])))),qa.length>0?h().createElement("div",{className:L.incidentRibbonPanel,"aria-label":"Detected incident overview"},h().createElement("svg",{width:"100%",height:"34",viewBox:`0 0 ${$a} 34`,preserveAspectRatio:"none",role:"img","aria-label":"Detected incident overview"},h().createElement("rect",{x:Na.left,y:11,width:La,height:12,rx:6,fill:N.isDark?"#252C38":"#E2E8F0",opacity:.88}),qa.map(e=>{const t=Math.max(Na.left,Ca(e.start)),a=Math.min($a-Na.right,Ca(e.end)),i=Math.max(8,a-t),n=Ce(Lt)===Ce(e.selection),r=ce[e.severityLabel];return h().createElement("g",{key:`overview-${e.key}`,style:{cursor:"pointer"},onClick:()=>{qe(e.selection),mt(e.center),nt(e.center)}},h().createElement("title",null,`${e.label} | ${se[e.severityLabel]} ${e.severityScore} | ${Fe(e.center,pa,l)}`),h().createElement("rect",{x:t,y:11,width:i,height:12,rx:6,fill:r,fillOpacity:n?1:.82,stroke:n?N.isDark?"#F8FAFC":"#0F172A":"none",strokeWidth:n?1.2:0}),e.count>1&&i>=28?h().createElement("g",null,h().createElement("rect",{x:t+i/2-13,y:2,width:26,height:18,rx:8,fill:r,stroke:N.isDark?"#7F1D1D":"#FFFFFF",strokeWidth:1}),h().createElement("text",{x:t+i/2,y:15,textAnchor:"middle",fill:"#FFFFFF",fontSize:"10",fontWeight:"900",pointerEvents:"none"},"x",e.count)):null)}))):h().createElement("div",{className:L.incidentRibbonPanel,"aria-label":"Detected incident overview"},h().createElement("div",{className:L.incidentRibbonEmpty},"No clustered incidents in this time range."))):null,O.mainChart?h().createElement("div",{className:L.chartCard,style:ka?{minHeight:Math.max(n-20,220),height:"100%"}:void 0,ref:$t,tabIndex:0,onKeyDown:e=>{if((e=>e instanceof HTMLElement&&(["BUTTON","INPUT","TEXTAREA","SELECT","A"].includes(e.tagName)||e.isContentEditable))(e.target)||0===At.length)return;const t=At.findIndex(e=>Ce(e.selection)===Ct),a=t>=0?t:0;if("ArrowRight"===e.key||"ArrowDown"===e.key){e.preventDefault();const t=At[(a+1)%At.length];return void Pt(t)}if("ArrowLeft"===e.key||"ArrowUp"===e.key){e.preventDefault();const t=At[(a-1+At.length)%At.length];return void Pt(t)}if("Enter"===e.key||" "===e.key){const t=At[a];if(!t)return;return e.preventDefault(),mt(e=>e===t.time?null:t.time),void nt(t.time)}"Escape"===e.key&&(e.preventDefault(),mt(null),nt(null))},"aria-label":"Anomaly chart. Use left and right arrows to move between incidents, Enter to pin, and Escape to clear."},h().createElement("svg",{width:"100%",height:"100%",viewBox:`0 0 ${$a} ${Ma}`,preserveAspectRatio:"none",role:"img","aria-label":"Anomaly chart",onMouseMove:e=>{const t=e.currentTarget.getBoundingClientRect(),a=(e.clientX-t.left)/t.width*$a;if(a<Na.left||a>$a-Na.right)return void(null===ot&&nt(null));const i=(e=>{if(da===ca)return ca;const t=Math.max(0,Math.min(1,(e-Na.left)/La));return ca+t*(da-ca)})(a),n=Ye(oa,i);nt(n>=0?oa[n]:null)},onMouseLeave:()=>{null===ot&&nt(null)},onClick:()=>{Wt&&mt(e=>e===Wt.time?null:Wt.time)},style:{width:"100%",height:"100%",display:"block",cursor:"crosshair"}},h().createElement("defs",null,h().createElement("clipPath",{id:Ci},h().createElement("rect",{x:Na.left,y:Na.top,width:La,height:Aa,rx:12}))),h().createElement("rect",{x:0,y:0,width:$a,height:Ma,fill:N.isDark?"#08111F":"#FFFFFF"}),h().createElement("rect",{x:8,y:Na.top-8,width:Na.left-16,height:Aa+16,rx:16,fill:Di,opacity:.96}),h().createElement("text",{transform:`translate(22 ${Na.top+Aa/2}) rotate(-90)`,textAnchor:"middle",fill:Bi,fontSize:"11",fontWeight:"700",letterSpacing:"0.08em"},"VALUE"),h().createElement("text",{x:$a-Na.right,y:Ma-16,textAnchor:"end",fill:Bi,fontSize:"11",fontWeight:"700",letterSpacing:"0.08em"},"TIME (",fa,")"),_a.map((e,t)=>{const a=Ca(e),i=0===t?"start":t===_a.length-1?"end":"middle";return h().createElement("g",{key:`top-x-${t}`},h().createElement("text",{x:a,y:Na.top-10,textAnchor:i,fill:N.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},((e,t,a)=>t<=2592e5?(0,c.dateTimeFormat)(e,{format:"ddd DD/MM",timeZone:a}):(0,c.dateTimeFormat)(e,{format:"DD/MM/YYYY",timeZone:a}))(e,pa,l)))}),Li?h().createElement("rect",{x:Math.max(Na.left,Li.x),y:Na.top,width:Math.min(Li.width,La),height:Li.height,fill:N.isDark?"rgba(59,130,246,0.10)":"rgba(37,99,235,0.08)",stroke:N.isDark?"rgba(96,165,250,0.35)":"rgba(37,99,235,0.25)",rx:8}):null,h().createElement("rect",{x:Na.left,y:Na.top,width:La,height:Aa,rx:12,fill:N.isDark?"#06101E":"#FFFFFF",stroke:N.isDark?"#142033":"#E2E8F0"}),Ra.map((e,t)=>{const a=Ba(e);return h().createElement("g",{key:`y-${t}`},h().createElement("line",{x1:Na.left,y1:a,x2:$a-Na.right,y2:a,stroke:N.isDark?"#1E293B":"#E2E8F0",strokeOpacity:.78,strokeDasharray:"3 6"}),h().createElement("rect",{x:14,y:a-10,width:Na.left-28,height:20,rx:10,fill:Ti,opacity:N.isDark?.84:.96}),h().createElement("text",{x:Na.left-18,y:a+4,textAnchor:"end",fill:N.isDark?"#E2E8F0":"#0F172A",fontSize:"12",fontWeight:"700"},(e=>{if(!Number.isFinite(e))return"";const t=Math.abs(e);return t>=1e3?e.toLocaleString(void 0,{notation:"compact",maximumFractionDigits:1}):t>=100?e.toLocaleString(void 0,{maximumFractionDigits:0}):t>=10?e.toLocaleString(void 0,{maximumFractionDigits:1}):t>=1?e.toLocaleString(void 0,{maximumFractionDigits:2}):e.toLocaleString(void 0,{maximumFractionDigits:3})})(e)))}),Pa.map((e,t)=>{const a=Ca(e),i=0===t?"start":t===Pa.length-1?"end":"middle";return h().createElement("g",{key:`x-${t}`},t>0&&t<Pa.length-1?h().createElement("line",{x1:a,y1:Na.top,x2:a,y2:Ma-Na.bottom,stroke:N.isDark?"#162336":"#E2E8F0",strokeOpacity:.45}):null,h().createElement("text",{x:a,y:Ma-12,textAnchor:i,fill:N.isDark?"#94A3B8":"#64748B",fontSize:"11"},Se(e,pa,V.timeAxisDensity,l)))}),null!==Pi?h().createElement("g",{pointerEvents:"none"},h().createElement("line",{x1:Pi,y1:Na.top,x2:Pi,y2:ja,stroke:N.isDark?"#93C5FD":"#2563EB",strokeDasharray:"5 5",strokeOpacity:.72,strokeWidth:1.35}),h().createElement("rect",{x:Math.max(Na.left+6,Math.min(Pi-52,$a-Na.right-104)),y:Na.top+24,width:104,height:20,rx:10,fill:N.isDark?"#0F172A":"#FFFFFF",stroke:N.isDark?"#334155":"#CBD5E1"}),h().createElement("text",{x:Math.max(Na.left+58,Math.min(Pi,$a-Na.right-52)),y:Na.top+38,textAnchor:"middle",fill:N.isDark?"#E2E8F0":"#0F172A",fontSize:"11",fontWeight:"700"},Se(null!==(v=null==Wt?void 0:Wt.time)&&void 0!==v?v:ca,pa,"dense",l))):null,"multi"===V.detectionMode&&Ai.length>0?h().createElement("g",null,Ai.map(({event:e,x:t,width:a,centerX:i})=>{const n="event"===(null==Lt?void 0:Lt.kind)&&Lt.time===e.time,r=ce[e.severityLabel],l=$e(e.severityLabel,V.markerShapeMode),o="high"===e.confidenceLabel?.18:"medium"===e.confidenceLabel?.12:.08,s=Na.top+18;return h().createElement("g",{key:`event-${e.time}`,style:{cursor:"pointer"},onClick:()=>{qe({kind:"event",time:e.time}),mt(e.time)}},h().createElement("title",null,`Combined anomaly at ${be(e.time)} | Score ${ye(e.score)} | ${se[e.severityLabel]} | ${de[e.confidenceLabel]}`),h().createElement("rect",{x:t,y:Na.top+1,width:a,height:Aa-2,rx:n?10:8,fill:r,fillOpacity:n?.18:o}),h().createElement("rect",{x:t,y:Na.top+4,width:a,height:4,rx:2,fill:r,fillOpacity:n?.95:"high"===e.confidenceLabel?.8:.62}),h().createElement("rect",{x:t,y:Na.top+Aa-6,width:a,height:3,rx:1.5,fill:r,fillOpacity:n?.9:"high"===e.confidenceLabel?.72:.5}),h().createElement("line",{x1:i,y1:s+8,x2:i,y2:ja-8,stroke:r,strokeOpacity:n?.74:.38,strokeWidth:n?1.8:1.25,strokeDasharray:"4 5"}),Ne(l,i,s,n?7.5:6.2,N.isDark?"#08111F":"#FFFFFF",r,n?2.8:2.2),Ne(l,i,s,n?3:2.5,r))})):null,h().createElement("g",{clipPath:`url(#${Ci})`},Le.map(e=>{const a=!1===t.showBands?"":((e,t,a)=>{const i=e.filter(e=>null!==e.lower&&null!==e.upper);if(i.length<2)return"";const n=i.map(e=>`${t(e.time).toFixed(2)},${a(e.upper).toFixed(2)}`),r=[...i].reverse().map(e=>`${t(e.time).toFixed(2)},${a(e.lower).toFixed(2)}`);return`M${n.join(" L")} L${r.join(" L")} Z`})(e.points,Ca,Ba),i=He(e.points,Ca,Ba,e=>e.value),n=V.showExpectedLine?He(e.points,Ca,Ba,e=>e.expected):"",r="point"===(null==Lt?void 0:Lt.kind)&&Lt.seriesKey===e.key?Lt.time:null,l=V.markerShapeMode,o=Math.max(54,La/12),s=Math.max(12,La/44),c="multi"===V.detectionMode?[]:Ke(Ge(e.points.filter(e=>e.isAnomaly),Ca,Ua?o:s,r),Ua?2:8,r);return h().createElement("g",{key:e.key},a?h().createElement("path",{d:a,fill:e.color,opacity:Rt&&"point"===Rt.kind&&Rt.seriesKey===e.key?.14:.07}):null,n?h().createElement("path",{d:n,fill:"none",stroke:e.color,strokeOpacity:.32,strokeWidth:1.3,strokeDasharray:"6 6"}):null,h().createElement("path",{d:i,fill:"none",stroke:e.color,strokeWidth:2.6,strokeLinecap:"round",strokeLinejoin:"round"}),c.map(t=>{const a="point"===(null==Lt?void 0:Lt.kind)&&Lt.seriesKey===e.key&&Lt.time===t.time,i=Ca(t.time),n=Ba(t.value),r=$e(t.severityLabel,l),o=a?11:"high"===t.confidenceLabel?8.4:"medium"===t.confidenceLabel?7.4:6.2;return h().createElement("g",{key:`${e.key}-${t.time}`,style:{cursor:"pointer"},onClick:()=>{qe({kind:"point",seriesKey:e.key,time:t.time}),mt(t.time)}},h().createElement("title",null,`${e.label} | ${be(t.time)} | ${se[t.severityLabel]} | ${de[t.confidenceLabel]}`),h().createElement("line",{x1:i,y1:Na.top+18,x2:i,y2:Math.max(Na.top+26,n-10),stroke:ce[t.severityLabel],strokeOpacity:a?.72:.3,strokeWidth:a?1.7:1.2,strokeDasharray:"4 5"}),h().createElement("circle",{cx:i,cy:n,r:o,fill:me[t.confidenceLabel],opacity:a?.28:.18}),Ne(r,i,n,a?7.2:5.4,N.isDark?"#111827":"#FFFFFF",ce[t.severityLabel],a?2.8:2.4),Ne(r,i,n,a?3.2:2.6,ce[t.severityLabel],void 0,0,"high"===t.confidenceLabel?.96:.8),h().createElement("circle",{cx:i,cy:n,r:11,fill:"transparent"}))}))})),Qa.map(e=>{const t=Math.max(Na.left+8,e.anchorX-e.width),a=t-8;return h().createElement("g",{key:`inline-${e.key}`},h().createElement("line",{x1:e.lastX,y1:e.lastY,x2:a,y2:e.labelY,stroke:e.color,strokeOpacity:.78,strokeWidth:1.4}),h().createElement("rect",{x:t,y:e.labelY-11,width:e.width,height:22,rx:11,fill:N.isDark?"#0F172A":"#FFFFFF",stroke:e.color,strokeOpacity:.48}),h().createElement("circle",{cx:t+11,cy:e.labelY,r:3,fill:e.color}),h().createElement("text",{x:t+19,y:e.labelY+4,fill:N.isDark?"#E2E8F0":"#0F172A",fontSize:"11",fontWeight:"700"},e.label))}),Oa?(()=>{const e=Na.left+14,t=Math.max(La-28,48),a=za,i=Math.max(Wa-28,18),n=Oa.minValue,r=Oa.maxValue,o=Math.max(r-n,1e-6),s=a=>e+(a-Oa.startTime)/Math.max(Oa.endTime-Oa.startTime,1)*t,c=e=>a+18+i-(e-n)/o*i,d=s(Oa.bucketStart),m=s(Math.max(Oa.bucketEnd,Oa.selectedTime));return h().createElement("g",null,h().createElement("rect",{x:Na.left+6,y:a,width:La-12,height:Wa,rx:14,fill:N.isDark?"rgba(8,17,31,0.92)":"rgba(255,255,255,0.94)",stroke:N.isDark?"#1E293B":"#D7E3F4"}),h().createElement("text",{x:e,y:a+14,fill:N.isDark?"#CBD5E1":"#334155",fontSize:"10",fontWeight:"700",letterSpacing:"0.08em"},"FOCUSED ANOMALY WINDOW"),h().createElement("text",{x:$a-Na.right-8,y:a+14,textAnchor:"end",fill:N.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},Oa.title),h().createElement("rect",{x:Math.min(d,m),y:a+18,width:Math.max(Math.abs(m-d),8),height:i,rx:8,fill:N.isDark?"rgba(59,130,246,0.14)":"rgba(37,99,235,0.10)",stroke:N.isDark?"rgba(96,165,250,0.28)":"rgba(37,99,235,0.22)"}),Oa.series.map(e=>{const t=He(e.points,s,c,e=>e.value);return h().createElement("path",{key:`focus-${e.key}`,d:t,fill:"none",stroke:e.color,strokeWidth:1.8,strokeOpacity:"point"===(null==Lt?void 0:Lt.kind)&&Lt.seriesKey===e.key?1:.78,strokeLinecap:"round",strokeLinejoin:"round"})}),h().createElement("line",{x1:s(Oa.selectedTime),y1:a+18,x2:s(Oa.selectedTime),y2:a+18+i,stroke:N.isDark?"#93C5FD":"#2563EB",strokeDasharray:"4 4",strokeWidth:1.4}),h().createElement("text",{x:e,y:a+Wa-8,fill:N.isDark?"#94A3B8":"#64748B",fontSize:"10"},Se(Oa.startTime,Oa.endTime-Oa.startTime,"dense",l)),h().createElement("text",{x:s(Oa.selectedTime),y:a+Wa-8,textAnchor:"middle",fill:N.isDark?"#E2E8F0":"#0F172A",fontSize:"10",fontWeight:"700"},Se(Oa.selectedTime,Oa.endTime-Oa.startTime,"dense",l)),h().createElement("text",{x:$a-Na.right-8,y:a+Wa-8,textAnchor:"end",fill:N.isDark?"#94A3B8":"#64748B",fontSize:"10"},Se(Oa.endTime,Oa.endTime-Oa.startTime,"dense",l)))})():null,h().createElement("rect",{x:Na.left,y:Na.top,width:La,height:Aa,rx:12,fill:"none",stroke:N.isDark?"#22314A":"#D7E3F4"})),Wt?h().createElement("div",{style:U(j({position:"absolute",top:18},null!=Ii?Ii:{}),{width:272,pointerEvents:null!==ot?"auto":"none",borderRadius:16,border:"1px solid "+(N.isDark?"#334155":"#CBD5E1"),background:N.isDark?"rgba(8,17,31,0.96)":"rgba(255,255,255,0.96)",boxShadow:N.isDark?"0 18px 42px rgba(2,6,23,0.42)":"0 18px 42px rgba(15,23,42,0.12)",padding:"12px 14px",display:"flex",flexDirection:"column",gap:8,backdropFilter:"blur(8px)"})},h().createElement("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:8}},h().createElement("div",{style:{minWidth:0}},h().createElement("div",{style:{fontSize:12,fontWeight:800,color:N.isDark?"#F8FAFC":"#0F172A"}},Fe(Wt.time,pa,l)),h().createElement("div",{style:{fontSize:11,color:N.isDark?"#94A3B8":"#64748B"}},(null===(M=Wt.event)||void 0===M?void 0:M.isAnomaly)?`Cross-metric incident | ${Wt.event.activeSeries} aligned metric${1===Wt.event.activeSeries?"":"s"}`:Wt.anomalyCount>0?`${Wt.anomalyCount} flagged signal${1===Wt.anomalyCount?"":"s"} at this time`:"Live metric snapshot")),h().createElement("div",{style:{display:"flex",alignItems:"center",gap:8}},h().createElement("span",{style:{display:"inline-flex",alignItems:"center",borderRadius:999,padding:"4px 8px",fontSize:10,fontWeight:800,background:`${ce[Wt.severityLabel]}22`,color:ce[Wt.severityLabel]}},se[Wt.severityLabel]," ",Wt.severityScore),null!==ot?h().createElement("button",{type:"button",onClick:e=>{e.stopPropagation(),mt(null)},style:{border:"1px solid "+(N.isDark?"#334155":"#CBD5E1"),background:N.isDark?"#0F172A":"#F8FAFC",color:N.isDark?"#E2E8F0":"#334155",borderRadius:999,padding:"4px 8px",fontSize:10,fontWeight:700,cursor:"pointer"}},"Unpin"):null)),h().createElement("div",{style:{display:"flex",flexDirection:"column",gap:6,maxHeight:240,overflowY:"auto"}},Wt.series.map(e=>h().createElement("div",{key:`tooltip-${e.key}`,style:{display:"grid",gridTemplateColumns:"minmax(0,1fr) auto auto",gap:8,alignItems:"center",padding:"6px 8px",borderRadius:12,background:N.isDark?"rgba(15,23,42,0.72)":"#F8FAFC",border:"1px solid "+(N.isDark?"#1E293B":"#E2E8F0")}},h().createElement("div",{style:{minWidth:0,display:"flex",alignItems:"center",gap:8}},h().createElement("span",{style:{width:8,height:8,borderRadius:999,background:e.color,flex:"0 0 auto"}}),h().createElement("span",{style:{fontSize:11,fontWeight:700,color:N.isDark?"#E2E8F0":"#0F172A",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}},we(e.label,24))),h().createElement("span",{style:{fontSize:11,fontWeight:700,color:N.isDark?"#F8FAFC":"#0F172A"}},ye(e.actual)),h().createElement("span",{style:{fontSize:10,fontWeight:700,color:e.isAnomaly?ce[e.severityLabel]:N.isDark?"#94A3B8":"#64748B"}},e.isAnomaly?se[e.severityLabel]:"normal"))))):null):null,Ea?h().createElement("div",{className:L.bottomDock,style:{gridTemplateColumns:O.seriesSummary&&O.scoreFeed&&Xt?void 0:"minmax(0, 1fr)"}},O.seriesSummary?h().createElement("div",{className:L.legendTable,"aria-label":"Series anomaly summary",style:{maxHeight:390,overflowY:"auto"}},ta>8?h().createElement("div",{className:L.legendToolbar},h().createElement("input",{className:L.legendControl,type:"search",value:pe,onChange:e=>he(e.currentTarget.value),placeholder:`Search ${ta} series`,"aria-label":"Search series legend"}),h().createElement("select",{className:L.legendControl,value:ke,onChange:e=>Me(e.currentTarget.value),"aria-label":"Sort series legend"},h().createElement("option",{value:"flagged"},"Most flagged"),h().createElement("option",{value:"score"},"Highest alert score"),h().createElement("option",{value:"last"},"Highest last value"),h().createElement("option",{value:"name"},"Series name"))):null,h().createElement("div",{className:L.legendTableHeader},h().createElement("span",null,"Series (",ta,")"),h().createElement("span",null,"Flagged"),h().createElement("span",null,"Max"),h().createElement("span",null,"Last")),Ni.map(e=>{var t;const a=null!==(t=e.allPoints[e.allPoints.length-1])&&void 0!==t?t:null;return h().createElement("button",{key:e.key,type:"button",className:L.legendTableRow,"aria-pressed":ne===e.key,title:`${e.label} | click to isolate; Ctrl/Cmd+click toggles visibility | ${e.anomalyCount} flagged buckets | max ${fe(e.maxSeverityScore)}`,style:{opacity:ae.has(e.key)&&ne!==e.key?.42:1},onClick:t=>{if(t.ctrlKey||t.metaKey)return re(null),void ie(t=>{const a=new Set(t);return a.has(e.key)?a.delete(e.key):a.add(e.key),a});re(t=>t===e.key?null:e.key)}},h().createElement("span",{className:L.legendSeriesName},h().createElement("span",{className:L.legendSwatch,style:{background:e.color}}),h().createElement("span",{style:{minWidth:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}},e.label)),h().createElement("span",{className:L.legendValue,style:{color:e.anomalyCount>0?ce[e.maxSeverityLabel]:void 0}},e.anomalyCount),h().createElement("span",{className:L.legendValue},fe(e.maxSeverityScore)),h().createElement("span",{className:L.legendValue},a?ye(a.value):"n/a"))}),0===Ni.length?h().createElement("div",{className:L.incidentRibbonEmpty},"No series match this search."):null,h().createElement("div",{className:L.legendTableFooter},h().createElement("span",null,ne?"1 series isolated":`${Le.length} of ${ta} visible${Mi?` · ${Ni.length} matched`:""}`),h().createElement("span",{style:{display:"flex",gap:6}},h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{ie(new Set),re(null)}},"Show all"),h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{ie(new Set(ee.map(e=>e.key))),re(null)}},"Hide all")))):null,O.scoreFeed?Xt:null):null,wa?h().createElement("div",{className:L.secondaryDock,style:{gridTemplateColumns:O.anomalyFeed&&xa?void 0:"minmax(0, 1fr)"}},O.anomalyFeed?h().createElement(h().Fragment,null,h().createElement("div",{className:L.card},h().createElement("div",{className:L.cardTitle},"Detected incidents"),At.length>0?h().createElement("div",{className:L.summaryTimeline},h().createElement("div",{className:L.subtitle},"Incident timeline"),h().createElement("svg",{width:"100%",height:"56",viewBox:"0 0 320 56",role:"img","aria-label":"Incident timeline overview"},h().createElement("line",{x1:18,y1:28,x2:302,y2:28,stroke:N.isDark?"#22314A":"#CBD5E1",strokeWidth:4,strokeLinecap:"round"}),At.map((e,t)=>{const a=da===ca?160:18+(e.time-ca)/Math.max(da-ca,1)*284,i=Ce(e.selection)===Ct,n=$e(e.severityLabel,V.markerShapeMode);return h().createElement("g",{key:`summary-timeline-${e.key}`,style:{cursor:"pointer"},onClick:()=>Pt(e)},h().createElement("title",null,`${e.title} | ${Fe(e.time,pa,l)}`),h().createElement("line",{x1:a,y1:16,x2:a,y2:40,stroke:ce[e.severityLabel],strokeOpacity:i?.85:.4,strokeWidth:i?2:1.3}),Ne(n,a,28,i?7:5.4,N.isDark?"#08111F":"#FFFFFF",ce[e.severityLabel],i?2.5:2),i?h().createElement("circle",{cx:a,cy:28,r:10.5,fill:"none",stroke:N.isDark?"#E2E8F0":"#0F172A",strokeOpacity:.4,strokeWidth:1.3}):null,0===t?h().createElement("text",{x:a,y:50,textAnchor:"start",fill:N.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},Se(e.time,pa,"compact",l)):t===At.length-1?h().createElement("text",{x:a,y:50,textAnchor:"end",fill:N.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},Se(e.time,pa,"compact",l)):null)}))):null,h().createElement("div",{className:L.summaryList},0===Ve.length?h().createElement("div",{className:L.subtitle},"No operationally relevant incidents crossed the active threshold in the selected time range."):Ve.map(e=>h().createElement("button",{key:e.key,type:"button","aria-label":`Detected incident ${e.title}`,className:`${L.summaryRow} ${Ct===Ce(e.selection)?L.summaryRowSelected:""}`,onClick:()=>Pt(e),style:{textAlign:"left",color:"inherit"}},h().createElement("div",{className:L.summaryMeta},h().createElement("span",{className:L.summaryTitle,title:e.title},e.title),h().createElement("span",{className:L.severityBadge,style:{background:`${ce[e.severityLabel]}22`,color:ce[e.severityLabel]}},se[e.severityLabel]," ",e.severityScore)),h().createElement("div",{className:L.subtitle},e.subtitle),h().createElement("div",{className:L.recommendationText},e.detail))))),h().createElement("div",{className:`${L.card} ${L.inlineInspectorLegacy}`},h().createElement("div",{className:L.cardTitle},"Legacy inspector details"),Rt?h().createElement(h().Fragment,null,h().createElement("div",{className:L.recommendationText},Rt.title),h().createElement("div",{className:L.subtitle},Rt.subtitle),h().createElement("div",{className:L.recommendationText},Ka),h().createElement("div",{className:L.actionRow},h().createElement("button",{type:"button",className:L.actionButton,disabled:!pi||!z,onClick:()=>{pi?z?gt(pi).then(()=>yt({tone:"success",message:"Created a Grafana annotation for the selected anomaly."})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to create the Grafana annotation."})):yt({tone:"error",message:"Save the dashboard once before creating Grafana annotations from the panel."}):yt({tone:"error",message:"Select an anomaly first to create an annotation."})}},"Create annotation"),h().createElement("button",{type:"button",className:L.actionButtonSecondary,disabled:!Za,onClick:()=>{Za?pt(Za).then(()=>yt({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):yt({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy alert query"),h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{hi?pt(hi).then(()=>yt({tone:"success",message:"Copied the selected anomaly annotation JSON."})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the annotation JSON."})):yt({tone:"error",message:"Select an anomaly first to copy its annotation JSON."})}},"Copy annotation JSON")),z?null:h().createElement("div",{className:L.subtitle},"Save the dashboard once so Grafana knows which dashboard the new annotation belongs to."),h().createElement("div",{className:L.detailGrid},h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Raw detection score"),h().createElement("div",{className:L.detailValue},ye(Rt.score))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Alert score (0-100)"),h().createElement("div",{className:L.detailValue,style:{color:ce[Rt.severityLabel]}},se[Rt.severityLabel]," ",Rt.severityScore)),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Confidence"),h().createElement("div",{className:L.detailValue,style:{color:me[Rt.confidenceLabel]}},de[Rt.confidenceLabel])),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Data quality"),h().createElement("div",{className:L.detailValue},ue[Rt.dataQualityLabel])),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Bucket span"),h().createElement("div",{className:L.detailValue},xe(Rt.bucketStart,Rt.bucketEnd))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Recommended action"),h().createElement("div",{className:L.detailValue},Pe(Rt,V.severityPreset)))),"point"===Rt.kind?h().createElement("div",{className:L.detailGrid},h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Current value"),h().createElement("div",{className:L.detailValue},ye(Rt.actual))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Expected value"),h().createElement("div",{className:L.detailValue},ye(Rt.expected))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Change"),h().createElement("div",{className:L.detailValue},ye(Rt.deviation))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Change %"),h().createElement("div",{className:L.detailValue},ve(Rt.deviationPercent))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Expected range"),h().createElement("div",{className:L.detailValue},(Oi=Rt.rangeLower,qi=Rt.rangeUpper,null===Oi||null===qi?"n/a":`${ye(Oi)} - ${ye(qi)}`))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Samples in bucket"),h().createElement("div",{className:L.detailValue},Rt.sampleCount)),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Instant signal"),h().createElement("div",{className:L.detailValue},ye(Rt.pointScore))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Sustained signal"),h().createElement("div",{className:L.detailValue},ye(Rt.windowScore))),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Main reason"),h().createElement("div",{className:L.detailValue},Te(Rt.scoreDriver,V.algorithm)))):h().createElement("div",{className:L.metricBreakdownList},h().createElement("div",{className:L.subtitle},"Metric breakdown"),Rt.breakdown.map(e=>h().createElement("div",{key:e.label,className:L.metricBreakdownCard,style:{borderColor:N.isDark?`${e.color}55`:`${e.color}66`}},h().createElement("div",{className:L.metricBreakdownHeader},h().createElement("div",null,h().createElement("div",{className:L.metricBreakdownTitle,style:{color:e.color}},e.label),h().createElement("div",{className:L.metricBreakdownReason},Te(e.scoreDriver,V.algorithm)," | ",de[e.confidenceLabel])),h().createElement("span",{className:L.severityBadge,style:{background:`${ce[e.severityLabel]}22`,color:ce[e.severityLabel]}},se[e.severityLabel]," ",e.severityScore)),h().createElement("div",{className:L.metricBreakdownGrid},h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Current"),h().createElement("div",{className:L.metricBreakdownStatValue},ye(e.actual))),h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Expected"),h().createElement("div",{className:L.metricBreakdownStatValue},ye(e.expected))),h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Change"),h().createElement("div",{className:L.metricBreakdownStatValue},ye(e.deviation))),h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Main reason"),h().createElement("div",{className:L.metricBreakdownStatValue},Te(e.scoreDriver,V.algorithm))),h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Confidence"),h().createElement("div",{className:L.metricBreakdownStatValue,style:{color:me[e.confidenceLabel]}},de[e.confidenceLabel])),h().createElement("div",{className:L.metricBreakdownStat},h().createElement("div",{className:L.metricBreakdownStatLabel},"Strength"),h().createElement("div",{className:L.metricBreakdownStatValue,style:{color:ce[e.severityLabel]}},ye(e.score)))))))):h().createElement("div",{className:L.subtitle},"Select a detected incident to see why it was flagged, how strong the signal is, and whether it is ready for alerting."))):null,xa?h().createElement("div",{className:L.sideUtilityStack},O.detectionProfile?h().createElement("div",{className:`${L.card} ${L.profileCard}`},h().createElement("div",{className:L.cardTitle},"Active detection profile"),h().createElement("div",{className:`${L.recommendationText} ${L.profileSummary}`},Ya),h().createElement("div",{className:L.profileDetailGrid},h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Setup mode"),h().createElement("div",{className:L.detailValue},J[V.setupMode])),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Metric preset"),h().createElement("div",{className:L.detailValue},X[V.metricPreset])),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Effective preset"),h().createElement("div",{className:L.detailValue},"custom"===V.effectiveMetricPreset?"Custom":X[V.effectiveMetricPreset])),h().createElement("div",{className:L.detailStat},h().createElement("div",{className:L.detailLabel},"Severity preset"),h().createElement("div",{className:L.detailValue},oe[V.severityPreset])))):null,O.exports?h().createElement("div",{className:`${L.card} ${L.handoffCard}`},h().createElement("div",{className:L.handoffHeader},h().createElement("div",{style:{minWidth:0,flex:"1 1 220px"}},h().createElement("div",{className:L.cardTitle},"Alerting & automation"),h().createElement("div",{className:L.subtitle},"Optional handoff only. Daily alert setup should use the inspector buttons; expand this when you need raw JSON.")),h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>Ft(e=>!e)},St?"Hide exports":"Show exports")),St?h().createElement(h().Fragment,null,h().createElement("div",{className:L.feedRuleCard},h().createElement("div",{className:L.handoffHeader},h().createElement("div",{className:L.cardTitle},"Annotation export"),h().createElement("button",{type:"button",className:L.actionButtonSecondary,onClick:()=>{pt(Ja).then(()=>yt({tone:"success",message:"Copied the annotation export JSON."})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the annotation export JSON."}))}},"Copy JSON")),h().createElement("div",{className:L.subtitle},"Use this JSON as a ready annotation or incident handoff payload."),h().createElement("pre",{className:L.monoBlock},Ja)),h().createElement("div",{className:L.feedRuleCard},h().createElement("div",{className:L.handoffHeader},h().createElement("div",{style:{minWidth:0,flex:"1 1 220px"}},h().createElement("div",{className:L.cardTitle},"Alert rule export"),h().createElement("div",{className:L.subtitle},Za?`Paste this ${Ht} into Grafana Alerting, then set WHEN QUERY IS ABOVE ${Xa} FOR 10m and evaluate every 3m.`:"Sync anomaly score feed first to generate an alert-ready anomaly score query.")),h().createElement("button",{type:"button",className:L.actionButtonSecondary,disabled:!Za,onClick:()=>{Za?pt(Za).then(()=>yt({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>yt({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):yt({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy query")),h().createElement("div",null,h().createElement("div",{className:L.subtitle},"Suggested labels"),h().createElement("div",{className:L.labelChipGrid,style:{marginTop:8}},Object.entries(ri).map(([e,t])=>h().createElement("span",{key:e,className:L.labelChip,title:`${e}=${t}`},h().createElement("span",{className:L.labelChipKey},e),h().createElement("span",null,"="),h().createElement("span",{className:L.labelChipValue},t))))),h().createElement("div",{className:L.codeLine},Za||"Sync anomaly score feed first to generate an alert-ready query."),h().createElement("pre",{className:L.monoBlock},ui))):null):null):null):null),O.inspector?h().createElement("aside",{className:L.inspectorRail},Vi):null));var Oi,qi}).setPanelOptions(e=>e.addTextInput({path:"title",name:"Panel title",description:"Short label shown above the anomaly chart.",defaultValue:"Anomaly detector",category:Ht}).addRadio({path:"setupMode",name:"Setup mode",description:"Recommended mode keeps the UI simple. Advanced mode unlocks manual algorithm controls.",defaultValue:"recommended",settings:{options:Zt},category:Ht}).addSelect({path:"metricPreset",name:"Metric type",description:"Start with Auto unless you already know the metric family.",defaultValue:"auto",settings:{options:ia},category:Ht,showIf:e=>"advanced"!==e.setupMode&&"custom"!==e.metricPreset}).addRadio({path:"detectionMode",name:"Detection mode",description:"Single metric scores each series independently. Multi metric combines same-timestamp signals into one event score.",defaultValue:"single",settings:{options:Xt},category:Ht}).addSelect({path:"scoreFeedMode",name:"Score feed mode",description:"Publish the anomaly scores detected by this plugin panel to Prometheus metrics or an exporter sink.",defaultValue:"auto",settings:{options:ta},category:Qt}).addSelect({path:"scoreFeedTarget",name:"Score feed target",description:"Choose where the plugin-computed anomaly score snapshot is published.",defaultValue:"prometheus",settings:{options:aa},category:Qt,showIf:e=>"off"!==e.scoreFeedMode}).addTextInput({path:"scoreFeedEndpoint",name:"Exporter endpoint",description:"Browser-side endpoint for the anomaly exporter. The plugin posts detected score snapshots here.",defaultValue:"http://127.0.0.1:9110",category:Qt,showIf:e=>"off"!==e.scoreFeedMode}).addTextInput({path:"scoreFeedRuleNamePrefix",name:"Rule name prefix",description:"Optional short prefix used when naming the published anomaly score feed for this panel.",defaultValue:"",category:Qt,showIf:e=>"off"!==e.scoreFeedMode}).addSelect({path:"bucketSpan",name:"Bucket span",description:"Optional pre-aggregation before anomaly scoring. Auto keeps the panel responsive on large or live queries.",defaultValue:"auto",settings:{options:na},category:Gt}).addSelect({path:"algorithm",name:"Algorithm",description:"Visible in Advanced mode when you want to pick the scoring strategy yourself.",defaultValue:"zscore",settings:{options:ra},category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addSelect({path:"anomalyDirection",name:"Anomaly direction",description:"Elastic-style mean direction policy. Choose whether high, low, or both deviations may become anomalies.",defaultValue:"high_or_low",settings:{options:ea},category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"minimumAbsoluteDeviation",name:"Minimum absolute deviation",description:"Ignore statistically unusual changes smaller than this metric-unit difference. Use 0 to disable the floor.",defaultValue:0,category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"minimumRelativeDeviation",name:"Minimum relative deviation",description:"Minimum proportional change from the baseline; 0.10 means 10%. Use 0 to disable the floor.",defaultValue:0,category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"minimumActivity",name:"Minimum activity",description:"Suppress anomaly decisions while both the current value and baseline are below this activity floor.",defaultValue:0,category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"persistenceBuckets",name:"Required anomaly buckets",description:"Number of anomalous evaluations required inside the persistence window. Recommended: 3 of 4.",defaultValue:3,category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"persistenceWindow",name:"Persistence window",description:"Evaluation bucket window used by the N-of-M anomaly decision. Must be at least the required bucket count.",defaultValue:4,category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"recoveryThreshold",name:"Recovery threshold",description:"Keep an open incident active until its raw score falls below this lower threshold. Use 0 to close at the anomaly threshold.",defaultValue:3,category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"recoveryBuckets",name:"Recovery buckets",description:"Consecutive recovered evaluations required before an open incident closes.",defaultValue:2,category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"cooldownBuckets",name:"Cooldown buckets",description:"Evaluations to suppress reopening after recovery. Use 0 to disable cooldown.",defaultValue:2,category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addBooleanSwitch({path:"dataQualityGate",name:"Block degraded data",description:"Prevent thin, flatline, or irregular data from becoming an anomaly until data quality is healthy.",defaultValue:!0,category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addSliderInput({path:"sensitivity",name:"Anomaly threshold",description:"Move left to catch subtler changes (more alerts), or right to suppress noise (fewer alerts). Balanced 4.0 is the recommended starting point.",defaultValue:4,settings:{min:.2,max:10,step:.1,marks:{[d]:"Sensitive",[u]:"Balanced",[m]:"Strict"},ariaLabelForHandle:"Anomaly threshold: lower is more sensitive, higher is stricter"},category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"baselineWindow",name:"History & warm-up window",description:"Baseline bucket count. Detection waits for this history at the start of a selected range, reducing premature false positives; larger values are steadier but react more slowly.",defaultValue:12,category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"seasonalitySamples",name:"Season length (samples)",description:"Used by cycle-based seasonal mode. Example: 24 for an hourly pattern or 288 for a daily pattern in 5-minute data.",defaultValue:24,category:Yt,showIf:e=>("advanced"===e.setupMode||"custom"===e.metricPreset)&&"seasonal"===e.algorithm}).addSelect({path:"seasonalRefinement",name:"Seasonal refinement",description:"Choose whether seasonal matching is based on fixed cycles, hour-of-day, or weekday plus hour.",defaultValue:"cycle",settings:{options:la},category:Yt,showIf:e=>("advanced"===e.setupMode||"custom"===e.metricPreset)&&"seasonal"===e.algorithm}).addSelect({path:"severityPreset",name:"Severity preset",description:"Controls how severity scores are translated into warning, high, and critical style labels.",defaultValue:"balanced",settings:{options:oa},category:Yt,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"maxAnomalies",name:"Max anomalies in summary",description:"Limits the number of highest scoring anomalies listed below the chart.",defaultValue:8,category:Kt}).addBooleanSwitch({path:"showBands",name:"Show expected band",defaultValue:!0,category:Kt}).addBooleanSwitch({path:"showExpectedLine",name:"Show expected line",defaultValue:!0,category:Kt}).addBooleanSwitch({path:"showInitialLabels",name:"Initial labels",description:"Show the panel title, algorithm, bucket, selected series, and datasource context.",defaultValue:!0,category:Jt}).addBooleanSwitch({path:"showStatistics",name:"Statistics",description:"Show severity, confidence, anomaly count, and data quality cards.",defaultValue:!0,category:Jt}).addBooleanSwitch({path:"showAnomalyFeed",name:"Anomaly feed",description:"Show the incident overview ribbon, timeline, and incident list.",defaultValue:!0,category:Jt}).addBooleanSwitch({path:"showMainChart",name:"Main chart",defaultValue:!0,category:Jt}).addBooleanSwitch({path:"showSeriesSummary",name:"Series summary",defaultValue:!0,category:Jt}).addBooleanSwitch({path:"showInspector",name:"Anomaly inspector",defaultValue:!0,category:Jt}).addBooleanSwitch({path:"showScoreFeed",name:"Score feed status",description:"Show the selected score target and its synchronization status. Publishing remains controlled by Score feed mode.",defaultValue:!0,category:Jt}).addBooleanSwitch({path:"showDetectionProfile",name:"Detection profile",defaultValue:!0,category:Jt}).addBooleanSwitch({path:"showInlineSeriesLabels",name:"Show inline series labels",description:"Show each series name at the right edge of the chart so the line identity stays visible without scanning the legend.",defaultValue:!0,category:Kt}).addBooleanSwitch({path:"showFocusBand",name:"Show anomaly focus band",description:"Render a zoomed local band around the selected anomaly for faster incident review.",defaultValue:!1,category:Kt}).addSelect({path:"timeAxisDensity",name:"Time axis density",description:"Control how many time labels are shown on the chart.",defaultValue:"auto",settings:{options:sa},category:Kt}).addSelect({path:"timeAxisPlacement",name:"Time axis placement",description:"Choose whether time labels are shown only at the bottom or on both top and bottom edges.",defaultValue:"top_and_bottom",settings:{options:ca},category:Kt}).addSelect({path:"markerShapeMode",name:"Anomaly marker style",description:"Choose whether severity is communicated with different marker shapes or with classic circular markers.",defaultValue:"severity",settings:{options:da},category:Kt}).addBooleanSwitch({path:"showExports",name:"Show export blocks",defaultValue:!1,category:Jt}));return s})());
//# sourceMappingURL=module.js.map